# Databricks notebook source
# Pharmacy Increased Normalized Claims Functions

# COMMAND ----------

# function methods _(underscore) seperated: kevin_huan
# Global Variable All caps: KEVIN_HUANG
# camel case is variable: claimsFactLine
# Class definition is Capital: KevinHuang

# COMMAND ----------

# def create_pharmacy_features_dataframe():
    
#   l = create_LIEI_npi_list()
    
#   person_df = (spark.read.parquet(adls_source_path + PERSON_TBL))

#   w = Window.partitionBy('sdr_person_id').orderBy(desc("action_timestamp"))
#   person_df = person_df.withColumn("rn",row_number().over(w)).filter(col("rn") ==1).select([col('sdr_person_id'),
#                                                                                             col('sex_cd').alias('mem_sex_cd'),
#                                                                                             col('birth_date')])
  
   
  
#   claims_fact_line = spark.read.parquet(adls_source_path + CLAIMS_LINE_FACTS_URL)\
#     .select(['document_key','phar_nabp_id','sdr_person_id', 'service_date','ndc_id','net_paid_amt'])\
#     .filter( (col('rx_count') == 1) & (col('service_date') >= BEGIN_DATE))

#   claims_process_line = spark.read.parquet(adls_source_path + CLAIMS_PROCESS_LINE_URL)\
#     .select([col('document_key'),
#              col('phys_npi_id'),
#              col('sex_cd').alias('clm_sex_cd'),
#              col('mbr_age'),
#              col('claim_generic_ind'),
#              col('daw_cd')])\
#     .filter(col('service_date') >= BEGIN_DATE)

#   claims_merged_df = (claims_fact_line
#       .join(claims_process_line, ["document_key"])
#       .join(person_df, ["sdr_person_id"]))

  
#   claims_merged_df = claims_merged_df.withColumn('birth_year',f.year(f.to_timestamp('birth_date', 'dd/MM/yyyy')))\
#                                      .withColumn('service_year',f.year(f.to_timestamp('service_date', 'dd/MM/yyyy')))\
#                                      .withColumn('computed_age', (col('service_year') - col('birth_year')))\
#                                      .withColumn('age_discrepancy', F.when( F.abs(col('computed_age') - col('mbr_age')) > 1, 1).otherwise(0)) \
#                                      .withColumn('sex_discrepancy', F.when(col('clm_sex_cd') != col('mem_sex_cd'), 1).otherwise(0)) \
#                                      .withColumn('in_leie', F.when(col('phys_npi_id').isin(l),1).otherwise(0)) \
#                                      .withColumn('is_male', F.when(col('mem_sex_cd') == 'M', 1).otherwise(0)) \
#                                      .withColumn('is_male_between_18_40', F.when((col('mem_sex_cd') == 'M') &
#                                                                                  (col('mbr_age') >= 18) &
#                                                                                  (col('mbr_age') <= 40), 1).otherwise(0)) \
#                                      .withColumn('DERMATALOGY_net_paid', udf(lambda ndc_id, net_paid_amt:\
#                                                     net_paid_amt if ndc_id in dic_ndc_id_to_drug_class and \
#                                                                              dic_ndc_id_to_drug_class[ndc_id] == 'DERMATOLOGY' \
#                                                                              else float(0),
#                                                                              FloatType())(col('ndc_id'),
#                                                                                           col('net_paid_amt')))\
#                                      .withColumn('ANTI-INFECTIVES_net_paid', udf(lambda ndc_id, net_paid_amt:\
#                                                     net_paid_amt if ndc_id in dic_ndc_id_to_drug_class and \
#                                                                              dic_ndc_id_to_drug_class[ndc_id] == 'ANTI-INFECTIVES' \
#                                                                              else float(0),
#                                                                              FloatType())(col('ndc_id'),
#                                                                                           col('net_paid_amt')))
                                     
  
#   res1 = claims_merged_df.groupBy('phar_nabp_id')\
#                  .agg(F.countDistinct(col('sdr_person_id')).alias('members_count'),
#                       F.countDistinct(col('phys_npi_id')).alias('prescribers_count'),
#                       (F.sum('net_paid_amt') / F.count(col('document_key'))).alias('normalized_net_paid'),
#                       (sum_cond(col('ndc_id').isin(suspect_drugs_list),
#                                 col('net_paid_amt')) / F.count(col('sdr_person_id'))).alias('normalized_susp_med_net_paid'),
#                       (100 * cnt_cond(col('claim_generic_ind') == 'Y') / F.count('*')).alias('branded_y_perc'),
#                       (100 * cnt_cond(col('claim_generic_ind') == 'N') / F.count('*')).alias('branded_n_perc'),
#                       (100 * cnt_cond(col('claim_generic_ind') == 'U') / F.count('*')).alias('branded_u_perc'),
#                       (100 * cnt_cond(col('daw_cd') == '0') / F.count('*')).alias('daw_cd_0'),
#                       (100 * cnt_cond(col('daw_cd') == '1') / F.count('*')).alias('daw_cd_1'),
#                       (100 * cnt_cond(col('daw_cd') == '2') / F.count('*')).alias('daw_cd_2'),
#                       (100 * cnt_cond(col('daw_cd') == '3') / F.count('*')).alias('daw_cd_3'),
#                       (100 * cnt_cond(col('daw_cd') == '4') / F.count('*')).alias('daw_cd_4'),
#                       (100 * cnt_cond(col('daw_cd') == '5') / F.count('*')).alias('daw_cd_5'),
#                       (100 * cnt_cond(col('daw_cd') == '6') / F.count('*')).alias('daw_cd_6'),
#                       (100 * cnt_cond(col('daw_cd') == '7') / F.count('*')).alias('daw_cd_7'),
#                       (100 * cnt_cond(col('daw_cd') == '8') / F.count('*')).alias('daw_cd_8'),
#                       (100 * cnt_cond(col('daw_cd') == '9') / F.count('*')).alias('daw_cd_9'),
#                       (100 * cnt_cond((col('daw_cd') == '0') &
#                                       (col('claim_generic_ind') == 'N')) / F.count('*')).alias('daw_0_brand_disp_perc'),
#                       F.count(col('document_key')).alias('claims_count')).cache()
  
# # 0	NO PRODUCT SELECTION INDICATED
# # 1	SUBSTITUTION NOT ALLOWED BY PRESCRIBER.
# # 2	SUBSTITUTION ALLOWED, PATIENT REQUESTED PRODUCT DISPENSED.
# # 3	SUBSTITUTION ALLOWED, PHARMACIST SELECTED DISPENSED
# # 4	SUBSTITUTION ALLOWED, GENERIC DRUG NOT IN STOCK
# # 5	SUBSTITUTION ALLOWED, GENERIC DRUG DISPENSED AS A GENERIC
# # 6	OVERRIDE
# # 7	SUBSTITUTION NOT ALLOWED, BRAND DRUG MANDATED BY LAW
# # 8	SUBSTITUTION ALLOWED, GENERIC DRUG NOT AVAILABLE IN MARKETPLACE
# # 9	OTHER
  
#   res2 = claims_merged_df.groupBy('phar_nabp_id')\
#                    .agg(F.sum(col('in_leie')).alias('in_leie_cnt'),
#                         (100 * F.sum('age_discrepancy') / F.count(col('document_key'))).alias('age_discrepancy_cnt'),
#                         (100 * F.sum('sex_discrepancy') / F.count(col('document_key'))).alias('sex_discrepancy_cnt'),
#                         (F.sum(col('DERMATALOGY_net_paid')) / F.count(col('document_key'))).alias('DERMATALOGY_net_paid_normalized'),
#                         (F.sum(col('ANTI-INFECTIVES_net_paid'))/ F.count(col('document_key'))).alias('ANTI-INFECTIVES_net_paid_normalized')
#                        ).cache() 
  
#   res3 = claims_merged_df.select(['phar_nabp_id',
#                                   'sdr_person_id',
#                                   'mbr_age',
#                                   'is_male',
#                                   'is_male_between_18_40']).distinct()\
#                   .groupBy('phar_nabp_id')\
#                   .agg((100 * F.sum('is_male') / F.count('sdr_person_id')).alias('male_female_ratio'),
#                        (100 * F.sum('is_male_between_18_40') / F.count('sdr_person_id')).alias('male_18_40_ratio'),
#                        F.mean(col('mbr_age')).alias('avg_member_age')).cache()
  
#   res4 = claims_fact_line_reversed_df = (spark.read.parquet(adls_source_path + CLAIMS_LINE_FACTS_URL)\
#                                                .select(['phar_nabp_id','rx_count'])\
#                                                .filter((col('service_date') >= BEGIN_DATE))).groupBy('phar_nabp_id')\
#                                                   .agg((100 * cnt_cond(col('rx_count')==-1) / F.count('*')).alias('reversal_perc'))
  
  
                                               
  
#   res = res1.join(res2,['phar_nabp_id'])
#   res = res.join(res3, ['phar_nabp_id'])
#   res = res.join(res4, ['phar_nabp_id'])
#   res = res.withColumn('per_member_prescriptions', (col('claims_count')/col('members_count')))
#   res = res.withColumn('per_physician_prescriptions', (col('claims_count')/col('prescribers_count')))
#   res = res.withColumn('per_physician_members', (col('members_count')/col('prescribers_count')))
  
#   return res



# def create_prescribers_features_dataframe():
    
#   l = create_LIEI_npi_list()
    
#   person_df = (spark.read.parquet(adls_source_path + PERSON_TBL))

#   w = Window.partitionBy('sdr_person_id').orderBy(desc("action_timestamp"))
#   person_df = person_df.withColumn("rn",row_number().over(w)).filter(col("rn") ==1).select([col('sdr_person_id'),
#                                                                                             col('sex_cd').alias('mem_sex_cd'),
#                                                                                             col('birth_date')])
  
   
  
#   claims_fact_line = spark.read.parquet(adls_source_path + CLAIMS_LINE_FACTS_URL)\
#     .select(['document_key','phar_nabp_id','sdr_person_id', 'service_date','ndc_id','net_paid_amt'])\
#     .filter( (col('rx_count') == 1) & (col('service_date') >= BEGIN_DATE))

#   claims_process_line = spark.read.parquet(adls_source_path + CLAIMS_PROCESS_LINE_URL)\
#     .select([col('document_key'),
#              col('phys_npi_id'),
#              col('sex_cd').alias('clm_sex_cd'),
#              col('mbr_age'),
#              col('claim_generic_ind'),
#              col('daw_cd')])\
#     .filter(col('service_date') >= BEGIN_DATE)

#   claims_merged_df = (claims_fact_line
#       .join(claims_process_line, ["document_key"])
#       .join(person_df, ["sdr_person_id"]))

  
#   claims_merged_df = claims_merged_df.withColumn('birth_year',f.year(f.to_timestamp('birth_date', 'dd/MM/yyyy')))\
#                                      .withColumn('service_year',f.year(f.to_timestamp('service_date', 'dd/MM/yyyy')))\
#                                      .withColumn('computed_age', (col('service_year') - col('birth_year')))\
#                                      .withColumn('age_discrepancy', F.when( F.abs(col('computed_age') - col('mbr_age')) > 1, 1).otherwise(0)) \
#                                      .withColumn('sex_discrepancy', F.when(col('clm_sex_cd') != col('mem_sex_cd'), 1).otherwise(0)) \
#                                      .withColumn('in_leie', F.when(col('phys_npi_id').isin(l),1).otherwise(0)) \
#                                      .withColumn('is_male', F.when(col('mem_sex_cd') == 'M', 1).otherwise(0)) \
#                                      .withColumn('is_male_between_18_40', F.when((col('mem_sex_cd') == 'M') &
#                                                                                  (col('mbr_age') >= 18) &
#                                                                                  (col('mbr_age') <= 40), 1).otherwise(0)) \
#                                      .withColumn('DERMATALOGY_net_paid', udf(lambda ndc_id, net_paid_amt:\
#                                                     net_paid_amt if ndc_id in dic_ndc_id_to_drug_class and \
#                                                                              dic_ndc_id_to_drug_class[ndc_id] == 'DERMATOLOGY' \
#                                                                              else float(0),
#                                                                              FloatType())(col('ndc_id'),
#                                                                                           col('net_paid_amt')))\
#                                      .withColumn('ANTI-INFECTIVES_net_paid', udf(lambda ndc_id, net_paid_amt:\
#                                                     net_paid_amt if ndc_id in dic_ndc_id_to_drug_class and \
#                                                                              dic_ndc_id_to_drug_class[ndc_id] == 'ANTI-INFECTIVES' \
#                                                                              else float(0),
#                                                                              FloatType())(col('ndc_id'),
#                                                                                           col('net_paid_amt')))
                                     
  
#   res1 = claims_merged_df.groupBy('phys_npi_id')\
#                  .agg(F.countDistinct(col('sdr_person_id')).alias('members_count'),
#                       F.countDistinct(col('phar_nabp_id')).alias('pharmacys_count'),
#                       (F.sum('net_paid_amt') / F.count(col('document_key'))).alias('normalized_net_paid'),
#                       (sum_cond(col('ndc_id').isin(suspect_drugs_list),
#                                 col('net_paid_amt')) / F.count(col('sdr_person_id'))).alias('normalized_susp_med_net_paid'),
#                       (100 * cnt_cond(col('claim_generic_ind') == 'Y') / F.count('*')).alias('branded_y_perc'),
#                       (100 * cnt_cond(col('claim_generic_ind') == 'N') / F.count('*')).alias('branded_n_perc'),
#                       (100 * cnt_cond(col('claim_generic_ind') == 'U') / F.count('*')).alias('branded_u_perc'),
#                       (100 * cnt_cond(col('daw_cd') == '0') / F.count('*')).alias('daw_cd_0'),
#                       (100 * cnt_cond(col('daw_cd') == '1') / F.count('*')).alias('daw_cd_1'),
#                       (100 * cnt_cond(col('daw_cd') == '2') / F.count('*')).alias('daw_cd_2'),
#                       (100 * cnt_cond(col('daw_cd') == '3') / F.count('*')).alias('daw_cd_3'),
#                       (100 * cnt_cond(col('daw_cd') == '4') / F.count('*')).alias('daw_cd_4'),
#                       (100 * cnt_cond(col('daw_cd') == '5') / F.count('*')).alias('daw_cd_5'),
#                       (100 * cnt_cond(col('daw_cd') == '6') / F.count('*')).alias('daw_cd_6'),
#                       (100 * cnt_cond(col('daw_cd') == '7') / F.count('*')).alias('daw_cd_7'),
#                       (100 * cnt_cond(col('daw_cd') == '8') / F.count('*')).alias('daw_cd_8'),
#                       (100 * cnt_cond(col('daw_cd') == '9') / F.count('*')).alias('daw_cd_9'),
#                       (100 * cnt_cond((col('daw_cd') == '0') &
#                                       (col('claim_generic_ind') == 'N')) / F.count('*')).alias('daw_0_brand_disp_perc'),
#                       F.count(col('document_key')).alias('claims_count')).cache()
  
# # 0	NO PRODUCT SELECTION INDICATED
# # 1	SUBSTITUTION NOT ALLOWED BY PRESCRIBER.
# # 2	SUBSTITUTION ALLOWED, PATIENT REQUESTED PRODUCT DISPENSED.
# # 3	SUBSTITUTION ALLOWED, PHARMACIST SELECTED DISPENSED
# # 4	SUBSTITUTION ALLOWED, GENERIC DRUG NOT IN STOCK
# # 5	SUBSTITUTION ALLOWED, GENERIC DRUG DISPENSED AS A GENERIC
# # 6	OVERRIDE
# # 7	SUBSTITUTION NOT ALLOWED, BRAND DRUG MANDATED BY LAW
# # 8	SUBSTITUTION ALLOWED, GENERIC DRUG NOT AVAILABLE IN MARKETPLACE
# # 9	OTHER
  
#   res2 = claims_merged_df.groupBy('phys_npi_id')\
#                    .agg(F.sum(col('in_leie')).alias('in_leie_cnt'),
#                         (100 * F.sum('age_discrepancy') / F.count(col('document_key'))).alias('age_discrepancy_cnt'),
#                         (100 * F.sum('sex_discrepancy') / F.count(col('document_key'))).alias('sex_discrepancy_cnt'),
#                         (F.sum(col('DERMATALOGY_net_paid')) / F.count(col('document_key'))).alias('DERMATALOGY_net_paid_normalized'),
#                         (F.sum(col('ANTI-INFECTIVES_net_paid'))/ F.count(col('document_key'))).alias('ANTI-INFECTIVES_net_paid_normalized')
#                        ).cache() 
  
#   res3 = claims_merged_df.select(['phys_npi_id',
#                                   'sdr_person_id',
#                                   'mbr_age',
#                                   'is_male',
#                                   'is_male_between_18_40']).distinct()\
#                   .groupBy('phys_npi_id')\
#                   .agg((100 * F.sum('is_male') / F.count('sdr_person_id')).alias('male_female_ratio'),
#                        (100 * F.sum('is_male_between_18_40') / F.count('sdr_person_id')).alias('male_18_40_ratio'),
#                        F.mean(col('mbr_age')).alias('avg_member_age')).cache()
  

                                               
  
#   res = res1.join(res2,['phys_npi_id'])
#   res = res.join(res3, ['phys_npi_id'])
#   res = res.withColumn('per_member_prescriptions', (col('claims_count')/col('members_count')))
#   res = res.withColumn('per_pharmacy_prescriptions', (col('claims_count')/col('pharmacys_count')))
#   res = res.withColumn('per_pharmacy_members', (col('members_count')/col('pharmacys_count')))
  
#   return res

# COMMAND ----------

#######################
# Datasets
#######################

# COMMAND ----------

# Table containing each US zipcode and its respective latitude and longitude, used to compute the distance between any pair of zip codes
ZIP_CODE_LAT_LONG_URL = '/lvl1/models/fwa_dataset/us_zip_code_latitude_and_longitude'

# Refer to the EDW metadata go/marketplace for the following pharmacy tables
CLAIMS_LINE_FACTS_URL = '/lvl1/rxclm_line_fact_new'
CLAIMS_PROCESS_LINE_URL = '/lvl1/rxclm_process_line_new'

# Data for one pharmacy (only for faster debugging)
#CLAIMS_LINE_FACTS_URL = '/lvl1/models/fwa_dataset/rxclm_line_fact_new_one_pharmacy'

# Table contains pharmacy zipcode 
PHARMACY_URL = '/clinical/lu_pharmacy'

# Table contains members zipcode, gender, age etc.
PERSON_TBL = '/lvl1/src_person'

# Table contains drug info. such as DEA Schedule
DRUG_TBL_URL = '/clinical/v_drug'

# Table contains zipcode of providers
PROVIDER_TBL_URL = '/lvl1/src_provider_dly'

CMS_LEIE_TBL_URL = '/lvl1/models/fwa_dataset/cms_leie' # WHAT IS THIS TABLE - Has list of excluded invidiuals and entities - Not needed in this notebook - Banned by office of inspetor genreal

# COMMAND ----------

# Tables
PHARMACY_URL = '/clinical/lu_pharmacy'
CLAIMS_FACTS_URL = '/lvl1/models/fwa_dataset/rxclm_line_fact_new' # CLAIMS_FACTS_URL = '/lvl1/rxclm_line_fact_new'

# COMMAND ----------

#######################
# Pharmacy Distance Functions
#######################

# COMMAND ----------

# zip pairs by position, dict creates dictionary by position
zip_df = (spark.read.parquet(adls_xformed_path + ZIP_CODE_LAT_LONG_URL)).select(['zip', 'latitude', 'longitude'])
zip_df = zip_df.withColumn('coordinate_pair', udf(lambda lat,long: [float(lat), float(long)], ArrayType(FloatType()))(col('Latitude'), col('Longitude'))).drop('Latitude').drop('Longitude').toPandas()
dic_zip_to_coordinates = dict(zip(zip_df.zip, zip_df.coordinate_pair))

# COMMAND ----------

def shortest_distance_from_zip(zip_lst, zip2):
  """ 
  Given multiple zipcodes, returns the shortest distance from the zipcodes
  
    Parameters -
    
  Note:
  
  """
  if zip2 not in dic_zip_to_coordinates:
    return float(0)
  distance_list = []
  lat2 = dic_zip_to_coordinates[zip2][0]
  long2 = dic_zip_to_coordinates[zip2][1]  

  for zip1 in zip_lst:
    if zip1 not in dic_zip_to_coordinates:
      continue
    lat1 = dic_zip_to_coordinates[zip1][0]
    long1 = dic_zip_to_coordinates[zip1][1]
    distance_list.append(geodesic((lat1, long1),(lat2, long2)).mi)
  if len(distance_list) == 0:
    return float(0)
  return float(min(distance_list))

# COMMAND ----------

def distance_between_zip_codes(zip1, zip2):
  """ 
  Returns the distance between zip codes using lat,longs and geopy
  
    Parameters -
    
  Note: geopy must be installed
  
  """
  if zip1 not in dic_zip_to_coordinates or zip2 not in dic_zip_to_coordinates:
    return float(0)

  lat1 = dic_zip_to_coordinates[zip1][0]
  long1 = dic_zip_to_coordinates[zip1][1]
  lat2 = dic_zip_to_coordinates[zip2][0]
  long2 = dic_zip_to_coordinates[zip2][1]  
  return float(geodesic((lat1, long1),(lat2, long2)).mi)

# COMMAND ----------

def get_provider_zip_codes():
  """ 
  Returns the physican id and zipcode in a list
  
    Parameters -
    
  Note: 
  
  """
  provider_df = (spark.read.parquet(adls_source_path + PROVIDER_TBL_URL)
                 .select([col('prov_npi_id').alias('phys_npi_id'), col('serv_zip_cd').alias('provider_zip')])\
                 .filter((col('serv_zip_cd').isNotNull())&(col('prov_npi_id').isNotNull())))
  
  provider_df = provider_df.groupBy('phys_npi_id').agg(F.collect_set(col('provider_zip')).alias('all_provider_zip'))
  return provider_df


# COMMAND ----------

def get_person_zip_codes():
  """ 
  Returns the sdr_person_id and latest zipcode
  
    Parameters -
    
  Note: 
  
  """
  person_df = (spark.read.parquet(adls_source_path + PERSON_TBL).select([col('action_timestamp'),
                                                                         col("sdr_person_id"),
                                                                         col("zip_cd").alias('member_zip')]))
  
  w = Window.partitionBy('sdr_person_id').orderBy(desc("action_timestamp"))
  person_df = person_df.withColumn("rn",row_number().over(w)).filter(col("rn") ==1).drop("rn")
  
  return person_df
  

# COMMAND ----------

def get_pharmacy_zip_codes():
  """ 
  Returns the phar_nabp_id and latest zipcode
  
    Parameters -
    
  Note: We exclude mail-order, LTC, Specialty, humana owned and Instituitional pharmacies from this analysis. Distance does not make sense
  in mail-order pharmacies, long distances in LTC is expected, we don't investigate humana owned pharmacies and so on
  
  """
  pharmacy_df = (spark.read.parquet(adls_ref_path + PHARMACY_URL)
                  .filter((col('mail_order_phar_ind') == 'N') & # could remove but helps reduce false positive
                          (col('ltc_phar_ind') =='N') &
                          (col('mil_phar_ind') == 'N') & 
                          (col('inst_phar_ind') == 'N') & 
                          (col('hum_own_ind') == 'N') & 
                          (col('hit_phar_ind') == 'N') & 
                          (col('phar_specialty') == 'N') &
                          (((col('disp_class_cd') == '1') | (col('disp_class_cd') == '01')) & ((col('disp_type_cd') == '1') | (col('disp_type_cd') == '01')))
                         )
                  .select([col('phar_nabp_id'), 
                          col('zip_cd').alias('phar_zip')]))
  return pharmacy_df

# COMMAND ----------

# # One liner
# def create_pharmacy_distance_dataset():
#   provider_df = (spark.read.parquet(adls_source_path + PROVIDER_TBL_URL)
#                  .select([col('prov_npi_id').alias('phys_npi_id'), col('serv_zip_cd').alias('provider_zip')])\
#                  .filter((col('serv_zip_cd').isNotNull())&(col('prov_npi_id').isNotNull())))
  
#   provider_df = provider_df.groupBy('phys_npi_id').agg(F.collect_set(col('provider_zip')).alias('all_provider_zip'))
  
#   person_df = (spark.read.parquet(adls_source_path + PERSON_TBL).select([col('action_timestamp'),
#                                                                          col("sdr_person_id"),
#                                                                          col("zip_cd").alias('member_zip')]))
  
#   w = Window.partitionBy('sdr_person_id').orderBy(desc("action_timestamp"))
#   person_df = person_df.withColumn("rn",row_number().over(w)).filter(col("rn") ==1).drop("rn")
  
#   # We exclude mail-order, LTC, Specialty, humana owned and Instituitional pharmacies from this analysis. Distance does not make sense
#   # in mail-order pharmacies, long distances in LTC is expected, we don't investigate humana owned pharmacies and so on
#   pharmacy_df = (spark.read.parquet(adls_ref_path + PHARMACY_URL)
#                   .filter((col('mail_order_phar_ind') == 'N') & # could remove but helps reduce false positive
#                           (col('ltc_phar_ind') =='N') &
#                           (col('mil_phar_ind') == 'N') & 
#                           (col('inst_phar_ind') == 'N') & 
#                           (col('hum_own_ind') == 'N') & 
#                           (col('hit_phar_ind') == 'N') & 
#                           (col('phar_specialty') == 'N') &
#                           (((col('disp_class_cd') == '1') | (col('disp_class_cd') == '01')) & ((col('disp_type_cd') == '1') | (col('disp_type_cd') == '01')))
#                          )
#                   .select([col('phar_nabp_id'), 
#                           col('zip_cd').alias('phar_zip')]))
  
  
#   claims_fact_line = spark.read.parquet(adls_source_path + CLAIMS_LINE_FACTS_URL)\
#   .select(['document_key','phar_nabp_id','sdr_person_id','rx_count','ndc_id','net_paid_amt','rx_cost'])\
#   .filter((col('rx_count') == 1) & (col('service_date') >= BEGIN_DATE) & (col('service_date') < END_DATE))

#   claims_process_line = spark.read.parquet(adls_source_path + CLAIMS_PROCESS_LINE_URL)\
#   .select(['document_key','mail_order_ind','sex_cd','mbr_age','phys_npi_id'])\
#   .filter((col('mail_order_ind') == 'N') & (col('service_date') >= BEGIN_DATE) & (col('service_date') < END_DATE))
  
   
  
#   drug_df = (spark.read.parquet(adls_ref_path + DRUG_TBL_URL).select([col('ndc_id'), col('dea_sch_ind'), col('hum_drug_class_desc')]))
#   drug_df = drug_df.withColumn('drug_class',udf(lambda hum_class: humana_class_to_merged_class[hum_class],StringType())(col('hum_drug_class_desc'))).select(['ndc_id', 'dea_sch_ind', 'drug_class'])


#   claims_merged_df = (claims_fact_line
#     .join(claims_process_line, ["document_key"])
#     .join(person_df, ["sdr_person_id"])
#     .join(drug_df, ['ndc_id'])                  
#     .join(provider_df, ['phys_npi_id'])                  
#     .join(pharmacy_df, ["phar_nabp_id"]))
  
#   claims_merged_df = claims_merged_df\
#                                .withColumn('phar_mem_distance', udf(lambda phar_zip, mem_zip: 
#                                                                     distance_between_zip_codes(phar_zip, mem_zip),
#                                                                     FloatType())(col('phar_zip'),col('member_zip')))\
#                                .withColumn('phar_phys_distance', udf(lambda lst_prov_zip, phar_zip:
#                                                                      shortest_distance_from_zip(lst_prov_zip, phar_zip),
#                                                                      FloatType())(col('all_provider_zip'),col('phar_zip')))\
#                                .withColumn('mem_phys_distance', udf(lambda lst_prov_zip, mem_zip:
#                                                                      shortest_distance_from_zip(lst_prov_zip, mem_zip),
#                                                                      FloatType())(col('all_provider_zip'),col('member_zip')))
 
#   return claims_merged_df  



# COMMAND ----------

#######################
# Pharmacy Features Functions
#######################

# COMMAND ----------

def create_LIEI_npi_list():
  provider_df = (spark.read.parquet(adls_source_path + PROVIDER_TBL_URL)).select([F.upper('prov_first_name').alias('prov_first_name'),
                                                                                F.upper('prov_last_name').alias('prov_last_name'),
                                                                                'serv_zip_cd',
                                                                                'serv_state_cd',
                                                                                'prov_npi_id'])
  leie_df = (spark.read.parquet(adls_xformed_path + CMS_LEIE_TBL_URL)).select(['FIRSTNAME','LASTNAME','NPI','STATE','ZIP'])
  merged_df = provider_df.join(leie_df, (leie_df['FIRSTNAME'] == provider_df['prov_first_name']) &
                                      (leie_df['LASTNAME'] == provider_df['prov_last_name']) &
                                      (leie_df['STATE'] == provider_df['serv_state_cd']) #&
                                      #(leie_df['ZIP'] == provider_df['serv_zip_cd'])
                              )
  merged_df = merged_df.withColumn('distance', udf(lambda zip1, zip2: distance_between_zip_codes(zip1, zip2),
                                                                    FloatType())(col('serv_zip_cd'),col('ZIP'))).cache()
  return list(merged_df.filter((col('distance') < 30) & (col('prov_npi_id').isNotNull())).select('prov_npi_id').toPandas()['prov_npi_id'])
################
# returns a list of npi adding in our own provider list and if they match within a certain mile range and criteria (name/state)
################

# COMMAND ----------

def ks_test(a1,a2,a3,a4,b1,b2,b3,b4):
  x1 = np.array([a1,a2,a3,a4])
  x2 = np.array([b1,b2,b3,b4])
  try:
    return float(stats.ks_2samp(x1,x2).statistic)
  except:
    return float(0)

# COMMAND ----------

#######################
# Increased Normalized Trends Functions
#######################

# COMMAND ----------

def load_claims_facts():
  """ 
  Reads in the rxclm_line_fact_new snapshot table
  Note: Data table needs to be updated when you want new data

  """
#   claims_fact_line = spark.read.parquet(adls_xformed_path + CLAIMS_FACTS_URL) # if using farhad table
  claims_fact_line = spark.read.parquet(adls_source_path + CLAIMS_LINE_FACTS_URL) #live table
  claims_fact_line = claims_fact_line.filter((claims_fact_line.service_date >= BEGIN_DATE) & 
                                              (claims_fact_line.service_date < END_DATE)
                                              ).select(['PHAR_NABP_ID', 'service_date', 'DOCUMENT_KEY', 'sdr_person_id','rx_count','ndc_id','rx_cost','net_paid_amt','mbr_respons_amt'])

  vdrug_df = spark.read.parquet(adls_ref_path + "/clinical/v_drug").select(['ndc_id', 'fdb_generic_name','hum_drug_class_desc'])
  vdrug_df = vdrug_df.filter(col('status_desc') == 'ACTIVE')
  
  claims_fact_line = (claims_fact_line.join(vdrug_df,["ndc_id"],'left_outer'))
  
  process_line_new = spark.read.parquet(adls_source_path + '/lvl1/rxclm_process_line_new')
  process_line_new = process_line_new.filter((col('service_date') >= BEGIN_DATE) & 
                                             (col('service_date') < END_DATE)
                                            ).select(['DOCUMENT_KEY','reversal_ind'])
  
  claims_fact_line = (claims_fact_line.join(process_line_new,["document_key"],'left_outer'))
  
  return claims_fact_line

# COMMAND ----------

def date_map2list(dic_date_to_cnt):
  """ 
  When given a mapped structured list, it will map in order the date to the value
  Must comprises of following conditions
  1. F.map_from_entries
  2. F.collect_list
  3. F.struct
  4. lambda funtion
  
    Parameters -
    BEGIN_DATE: Date for the begin service_date filter
    END_DATE: Date for the end service_date filter 
    
  Note:
  
  """
  temp_dic = {}
  for key in dic_date_to_cnt.keys():
    temp_dic[str(key)] = dic_date_to_cnt[key]
  d = datetime.datetime.strptime(BEGIN_DATE,'%Y-%m-%d').date()
  end_date = datetime.datetime.strptime(END_DATE,'%Y-%m-%d').date()
  output_list = []
  #while d <= date.today():
  while d <= end_date:
    if str(d) in temp_dic:
      output_list.append(temp_dic[str(d)])
    else:
      output_list.append(0)
    d = d + timedelta(days=1)
  return output_list

##########################################################################
# Functions below are the same as above, but for some reason I have to create
# a different name for these functions for the code to work
##########################################################################

def create_total_cost_vector(dic_date_to_total_cost):
  temp_dic = {}
  for key in dic_date_to_total_cost.keys():
    temp_dic[str(key)] = dic_date_to_total_cost[key]
  d = datetime.datetime.strptime(BEGIN_DATE,'%Y-%m-%d').date()
  end_date = datetime.datetime.strptime(END_DATE,'%Y-%m-%d').date()
  output_list = []
  #while d <= date.today():
  while d <= end_date:
    if str(d) in temp_dic:
      output_list.append(temp_dic[str(d)])
    else:
      output_list.append(0)
    d = d + timedelta(days=1)
  return output_list

def create_awp_vector(dic_date_to_awp):
  temp_dic = {}
  for key in dic_date_to_awp.keys():
    temp_dic[str(key)] = dic_date_to_awp[key]
  d = datetime.datetime.strptime(BEGIN_DATE,'%Y-%m-%d').date()
  end_date = datetime.datetime.strptime(END_DATE,'%Y-%m-%d').date()
  output_list = []
  #while d <= date.today():
  while d <= end_date:
    if str(d) in temp_dic:
      output_list.append(temp_dic[str(d)])
    else:
      output_list.append(0)
    d = d + timedelta(days=1)
  return output_list

def create_member_cost_vector(dic_date_to_member_cost):
  temp_dic = {}
  for key in dic_date_to_member_cost.keys():
    temp_dic[str(key)] = dic_date_to_member_cost[key]
  d = datetime.datetime.strptime(BEGIN_DATE,'%Y-%m-%d').date()
  end_date = datetime.datetime.strptime(END_DATE,'%Y-%m-%d').date()
  output_list = []
  #while d <= date.today():
  while d <= end_date:
    if str(d) in temp_dic:
      output_list.append(temp_dic[str(d)])
    else:
      output_list.append(0)
    d = d + timedelta(days=1)
  return output_list

# COMMAND ----------

def create_begin_end_map_dates(starter_date = BEGIN_DATE,ender_date = END_DATE):
  """ 
  Creates a vector that begins at BEGIN_DATE and ends at END_DATE
  Used to create the date_vector
  Must comprises of following conditions
  1. Vector
  
    Parameters -
    
  Note:
  
  """
  df1 = spark.createDataFrame([(1, 2)], ('C1', 'C2'))
  df1 = df1 \
    .withColumn('starter_date', lit(starter_date).cast('date')) \
    .withColumn('ender_date', lit(ender_date).cast('date'))

  df1 = df1.withColumn('txnDt', F.explode(F.expr('sequence(starter_date, ender_date, interval 1 day)')))

  df1 = df1\
    .groupBy('C1')\
    .agg((F.collect_list((F.date_format(col('txnDt'),"yyyy-MM-dd"))).alias('dates_vector')))
  
  claims_fact_line_pharm = spark.read.parquet(adls_xformed_path + CLAIMS_FACTS_URL) # if using farhad table
  #   claims_fact_line = spark.read.parquet(adls_source_path + CLAIMS_LINE_FACTS_URL) #live table
  claims_fact_line_pharm = claims_fact_line_pharm.select('PHAR_NABP_ID').distinct()
  claims_fact_line_pharm = claims_fact_line_pharm.withColumn('C1', lit(1))
  claims_fact_line_pharm = claims_fact_line_pharm.join(df1, ['C1'], 'left_outer').select(['PHAR_NABP_ID', 'dates_vector'])
  return claims_fact_line_pharm

# COMMAND ----------

def create_begin_end_map_dates_2(starter_date = BEGIN_DATE,ender_date = END_DATE):
  """ 
  Creates a vector that begins at BEGIN_DATE and ends at END_DATE
  Used to create the date_vector
  Must comprises of following conditions
  1. Vector
  
    Parameters -
    
  Note:
  
  """
  df1 = spark.createDataFrame([(1, 2)], ('C1', 'C2'))
  df1 = df1 \
    .withColumn('starter_date', lit(starter_date).cast('date')) \
    .withColumn('ender_date', lit(ender_date).cast('date'))

  df1 = df1.withColumn('txnDt', F.explode(F.expr('sequence(starter_date, ender_date, interval 1 day)')))

  df1 = df1\
    .groupBy('C1')\
    .agg((F.collect_list((F.date_format(col('txnDt'),"yyyy-MM-dd"))).alias('dates_vector')))
  
  claims_fact_line_pharm = spark.read.parquet(adls_source_path + CLAIMS_PROCESS_LINE_URL) # if using farhad table
  #   claims_fact_line = spark.read.parquet(adls_source_path + CLAIMS_LINE_FACTS_URL) #live table
  claims_fact_line_pharm = claims_fact_line_pharm.select('phys_npi_id').distinct()
  claims_fact_line_pharm = claims_fact_line_pharm.withColumn('C1', lit(1))
  claims_fact_line_pharm = claims_fact_line_pharm.join(df1, ['C1'], 'left_outer').select(['phys_npi_id', 'dates_vector'])
  return claims_fact_line_pharm

# COMMAND ----------

def trim_lead_trail_zero(data, trimv=0):
  """ 
  Used in the compute_normalization_sum() function, this will trim the leading and traling zero of
  a given vector
  Must comprises of following conditions
  1. musts be a list or vector

    Parameters -
    
  Note:
  
  """
  leftLen = rightLen = 0
  if trimv is not None:
    _data = []
    for idx,d in enumerate(data):
      if len(_data):
        _data.append(d)
      elif d!= trimv:
        _data.append(d)
      else:
        leftLen +=1
    data = _data
    _data = []
    for idx,d in enumerate(reversed(data)):
      if len(_data):
        _data.insert(0, d)
      elif d!=trimv:
        _data.insert(0,d)
      else:
        rightLen += 1
    data = _data
  # return
  return  data

# COMMAND ----------

def compute_rolling_sum(data, size=ROLLING_WINDOW_SIZE, trimv=0):
  """ 
  Used in the compute_normalization_sum() function to get the rolling window of a vector
  Keeps the first and last digit 
  Must comprises of following conditions
  1. F.Vector
  
    Parameters -
    size: number of rolling days
    trimv: What values to trim 
    
  Note:
  
  """
  assert size>=3,  "size must be >=3"
  assert size%2, "size must be odd"
  leftLen = rightLen = 0
  if trimv is not None:
    _data = []
    for idx,d in enumerate(data):
      if len(_data):
        _data.append(d)
      elif d!= trimv:
        _data.append(d)
      else:
        leftLen +=1
    data = _data
    _data = []
    for idx,d in enumerate(reversed(data)):
      if len(_data):
        _data.insert(0, d)
      elif d!=trimv:
        _data.insert(0,d)
      else:
        rightLen += 1
    data = _data
  #print(data)
  halfSize = int(float(size-1)/2.)
  rolling = [-1 for _ in data]
  for idx in range(len(data)):
    w = min(idx, len(data)-idx-1, halfSize)   
    result = data[idx-w:idx+w+1]
    rolling[idx] = sum(data[idx-w:idx+w+1])/(2*w+1)
  # return
  return [trimv]*leftLen + rolling + [trimv]*rightLen



def compute_rolling_sum_old(vec):
  """ 
  OLD
  Used to get the npe
  Must comprises of following conditions
  1. F.Vector
  
    Parameters -
    
  Note:
  
  """
  avg_vec = sum(vec)/len(vec)
  res = pd.Series(vec).rolling(ROLLING_WINDOW_SIZE,min_periods=ROLLING_MIN_PERIOD,center=True).mean().tolist()
#   res = res[(ROLLING_WINDOW_SIZE // 2):] + [np.nan] * (ROLLING_WINDOW_SIZE // 2)
  if avg_vec > 0:
    res = [x / avg_vec for x in res]
  res = [float(-1) if np.isnan(x) else x for x in res]
  return res

# COMMAND ----------

def compute_normalization_sum(vec):
  """ 
  Get the NPE for a vector of claims, used with compute_rolling_sum() & trim_lead_trail_zero() function
  Must comprises of following conditions
  1. Vector
  
    Parameters -
    
  Note:
  
  """
  vec_trim = trim_lead_trail_zero(vec)
  avg_vec = sum(vec)/len(vec_trim)
#   res = pd.Series(vec).rolling(ROLLING_WINDOW_SIZE,min_periods=ROLLING_MIN_PERIOD,center=True).mean().tolist()
  res = compute_rolling_sum(vec)
#   res = res[(ROLLING_WINDOW_SIZE // 2):] + [np.nan] * (ROLLING_WINDOW_SIZE // 2)
  if avg_vec > 0:
    res = [x / avg_vec for x in res]
  res = [float(-1) if np.isnan(x) else x for x in res]
  return res



##########################################################################
# Functions below are the same as above, but for some reason I have to create
# a different name for these functions for the code to work
##########################################################################
def compute_normalization_sum2(vec):
  vec_trim = trim_lead_trail_zero(vec)
  avg_vec = sum(vec)/len(vec_trim)
#   res = pd.Series(vec).rolling(ROLLING_WINDOW_SIZE,min_periods=ROLLING_MIN_PERIOD,center=True).mean().tolist()
  res = compute_rolling_sum(vec)
  if avg_vec > 0:
    res = [x / avg_vec for x in res]
  res = [float(-1) if np.isnan(x) else x for x in res]
  return res


# COMMAND ----------

def compute_normalization_sum3(vec):
  """ 
  Get the NPE for a vector of cost, used with compute_rolling_sum() & trim_lead_trail_zero() function
  Must comprises of following conditions
  1. Vector
  
    Parameters -
    
  Note:
  
  """
  vec_trim = trim_lead_trail_zero(vec)
  avg_vec = sum(vec)/len(vec_trim)
#   res = pd.Series(vec).rolling(ROLLING_WINDOW_SIZE,min_periods=ROLLING_MIN_PERIOD,center=True).mean().tolist()
  res = compute_rolling_sum(vec)
  res = [float(-1) if np.isnan(x) else x for x in res]
  return res

# COMMAND ----------

#############################################
def compute_normalization_members(vec):
  """ 
  Gets the normalization of members for a window 
  1. Vector
  
    Parameters -
    
  Note:
  
  """
  res = compute_rolling_sum(vec,size=ROLLING_WINDOW_SIZE_MEM,trimv=0)
  res = [float(-1) if np.isnan(x) else x for x in res]
  return res

###############################################
# def compute_npe_vector(vec):
#   func_create_rolling_sum_vectors = udf(lambda vec: compute_normalization_sum(vec), ArrayType(FloatType()))
#   return func_create_rolling_sum_vectors
###############################################

# COMMAND ----------

def mean_subtraction(a, avrg):
  """ 
  Subtracts the avrg from every element in the vector

  """
  return [element - avrg for element in a]

def z_score_calc(a, avrg, strdev):
  """ 
  Calculates z-score

  """
  if strdev == 0:
    return [(element - avrg)/(strdev-.0001) for element in a] 
  else:
    return [(element - avrg)/strdev for element in a] 

def array_trim_lead_zero(x):
  """ 
  Trims leading and trailing zeros

  """
  return np.trim_zeros(x, 'fb')

def array_ratio_claim_noclaim(vec):
  """ 
  Ratio of claims to total days

  """
  ratio_vec = array_trim_lead_zero(vec)
  if len(ratio_vec) == 0:
    ratio_of_claims = 0
  else:
    claim_vec = [i for i in ratio_vec if i != 0]
    ratio_of_claims = len(claim_vec)/len(ratio_vec)
#   ratio_of_claims = len(claim_vec)/len(noclaim_vec)
  return ratio_of_claims # claim : noclaim

def array_replace_nan(vec):
  """ 
  Replace nan in claims vector

  """
  return np.nan_to_num(vec)

# COMMAND ----------

#######################
# Need to do documentation
#######################

# COMMAND ----------

## Define functions
def get_normal_filter(vector, z=2, ps=0.15):
    #. z (integer): z score to create the maximum filter width
    #. ps (float): percent size in number of data points
    assert isinstance(z, int)
    assert z>0
    assert ps>0
    assert ps<0.8
    # compute normal filter
    if np.std(vector) == 0:
      sigma = np.std(vector)-.00001
    else:
      sigma = np.std(vector)
    size  = vector.shape[0]
    dx = 2*z*sigma/(ps*size)
    gx = np.arange(-z*sigma, z*sigma, dx)
    return np.exp(-(gx/sigma)**2/2).astype(vector.dtype)

def auto_adjusting_convolution(vector, filter):
    # filter computed using get_normal_filter
    if not filter.shape[0]%2:
        filter = (filter[1:]+filter[:-1])/2
    total = np.sum(filter)
    wca   = int( (filter.shape[0]-1)/2 )
    lda   = vector.shape[0]
    res   = []
    # compute sums
    sums = np.array( [np.sum(filter[wca-i:wca+i+1]) for i in range(wca+1)] )
    for i in range(lda):
        w = min(i,wca,lda-i-1)
        if w == 0:
            d = vector[i]
        elif w == wca:
            d = np.sum(vector[i-w:i+w+1]*filter) / sums[w]
        else:
            d = np.sum(vector[i-w:i+w+1] * filter[wca-w:wca+w+1]) / sums[w]
        res.append(d)
    return np.array(res, dtype=vector.dtype)

# COMMAND ----------

#######################
# Extra (Not currently Used)
#######################

# COMMAND ----------

def create_agg_awp_days_count(npe_vec, claims_vec, awp_vec):
  
  temp_dic = {}
  for index, val in enumerate(claims_vec):
    if val > 0 and npe_vec[index] > 0:
      if awp_vec[index] not in temp_dic:
        temp_dic[awp_vec[index]] = 0        
      temp_dic[awp_vec[index]] += ( val / npe_vec[index])
  l1,l2 = [],[]
  #for key in sorted(list(temp_dic.keys())):
  for key in sorted(temp_dic):
    if key == 0 and float(math.ceil(temp_dic[key])) == 0:
      continue
    l1.append(key)
    l2.append(float(math.ceil(temp_dic[key])))
    
  return [l1,l2] 
def contingency_test(obs_vec):
  if len(obs_vec[0]) < 2:
    return float(1)
  chi2, p = stats.chisquare(obs_vec[1])
  return float(p)

# COMMAND ----------

##########################################################################
# Old code that has been broken up in the v2 notebook. 
# This is for v1
##########################################################################

# def create_per_pharmacy_daily_claims_members(claims_df):
#   func_create_count_vectors = udf(lambda dic_date_to_cnt: date_map2list(dic_date_to_cnt), ArrayType(IntegerType()))
#   func_create_rolling_sum_vectors_old = udf(lambda vec: compute_rolling_sum_old(vec), ArrayType(FloatType()))
#   func_create_rolling_sum_vectors = udf(lambda vec: compute_normalization_sum(vec), ArrayType(FloatType()))
#   claims_original_df = claims_df.filter((claims_df.service_date >= BEGIN_DATE) & (claims_df.service_date < END_DATE) & (claims_df.rx_count == 1)).select(['PHAR_NABP_ID', 'service_date', 'DOCUMENT_KEY', 'sdr_person_id'])
#   date_dic_df = claims_original_df.groupby(['PHAR_NABP_ID', 'service_date']).agg(F.count('DOCUMENT_KEY').alias('claim_count'),F.countDistinct('sdr_person_id').alias('member_count') )
#   date_dic_df = date_dic_df\
#   .groupBy('PHAR_NABP_ID')\
#   .agg(F.map_from_entries(F.collect_list(F.struct(F.date_format(col('service_date'),"yyyy-MM-dd"),'claim_count'))).alias('map_claim_count'),
#        F.map_from_entries(F.collect_list(F.struct(F.date_format(col('service_date'),"yyyy-MM-dd"), 'member_count'))).alias('map_member_count'))

#   results = date_dic_df \
#     .withColumn('claims_vector',func_create_count_vectors(col('map_claim_count'))) \
#     .withColumn('members_vector',func_create_count_vectors(col('map_member_count'))) \
#     .withColumn('npe_old',func_create_rolling_sum_vectors_old(col('claims_vector'))) \
#     .withColumn('npe',func_create_rolling_sum_vectors(col('claims_vector'))) \
  
#   results = results.select(['phar_nabp_id', 'claims_vector', 'members_vector','npe_old','npe' ])
# #   results = results.select(['phar_nabp_id','npe_old','npe']) 

#   return results




# def create_per_pharmacy_daily_costs_members(claims_df):
#   func_create_count_vectors = udf(lambda dic_date_to_cnt: date_map2list(dic_date_to_cnt), ArrayType(IntegerType()))
#   func_create_rolling_sum_vectors_old = udf(lambda vec: compute_rolling_sum_old(vec), ArrayType(FloatType()))
#   func_create_rolling_sum_vectors = udf(lambda vec: compute_normalization_sum(vec), ArrayType(FloatType()))
#   func_create_total_cost_vectors = udf(lambda vec: create_total_cost_vector(vec), ArrayType(FloatType()))
#   func_create_awp_vectors = udf(lambda vec: create_awp_vector(vec), ArrayType(FloatType()))
#   func_create_member_cost_vectors = udf(lambda vec: create_member_cost_vector(vec), ArrayType(FloatType()))
# #   func_agg_awp_days_count = udf(lambda vec_npe, vec_clm, vec_awp: create_agg_awp_days_count(vec_npe, vec_clm, vec_awp),ArrayType(ArrayType(FloatType())))
#   claims_original_df = claims_df.filter((claims_df.service_date >= BEGIN_DATE) & (claims_df.service_date < END_DATE) & (claims_df.rx_count == 1)).select(['PHAR_NABP_ID', 'service_date', 'DOCUMENT_KEY', 'sdr_person_id',
#                                                                                                                                                           'rx_cost','net_paid_amt','mbr_respons_amt'])
#   date_dic_df = claims_original_df.groupby(['PHAR_NABP_ID', 'service_date']).agg(F.count('DOCUMENT_KEY').alias('claim_count'),F.countDistinct('sdr_person_id').alias('member_count'),
#                                                                                  F.sum('rx_cost').alias('total_cost'),F.sum('net_paid_amt').alias('humana_cost'),F.sum('mbr_respons_amt').alias('mbr_cost'))
#   date_dic_df = date_dic_df\
#   .groupBy('PHAR_NABP_ID')\
#   .agg(F.map_from_entries(F.collect_list(F.struct(F.date_format(col('service_date'),"yyyy-MM-dd"),'claim_count'))).alias('map_claim_count'),
#        F.map_from_entries(F.collect_list(F.struct(F.date_format(col('service_date'),"yyyy-MM-dd"),'member_count'))).alias('map_member_count'),
#        F.map_from_entries(F.collect_list(F.struct(F.date_format(col('service_date'),"yyyy-MM-dd"),'total_cost'))).alias('map_total_cost'),
#        F.map_from_entries(F.collect_list(F.struct(F.date_format(col('service_date'),"yyyy-MM-dd"),'humana_cost'))).alias('map_humana_cost'),
#        F.map_from_entries(F.collect_list(F.struct(F.date_format(col('service_date'),"yyyy-MM-dd"),'mbr_cost'))).alias('map_mbr_cost'))

#   results = date_dic_df \
#     .withColumn('claims_vector',func_create_count_vectors(col('map_claim_count'))) \
#     .withColumn('members_vector',func_create_count_vectors(col('map_member_count'))) \
#     .withColumn('npe_old',func_create_rolling_sum_vectors_old(col('claims_vector'))) \
#     .withColumn('npe',func_create_rolling_sum_vectors(col('claims_vector'))) \
#     .withColumn('total_cost_vector',func_create_awp_vectors(col('map_total_cost'))) \
#     .withColumn('humana_cost_vector',func_create_awp_vectors(col('map_humana_cost'))) \
#     .withColumn('member_cost_vector',func_create_member_cost_vectors(col('map_mbr_cost'))) \
# #     .withColumn('humana_npe',func_create_rolling_sum_vectors(col('map_humana_cost'))) \
# #     .withColumn('mbr_npe',func_create_rolling_sum_vectors(col('map_mbr_cost'))) \

  
#   results = results.select(['phar_nabp_id', 'claims_vector', 'members_vector','npe_old','npe','total_cost_vector','humana_cost_vector','member_cost_vector'])
# #   results = results.select(['phar_nabp_id','npe_old','npe']) 

#   return results
