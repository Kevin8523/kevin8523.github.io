# Databricks notebook source
# MAGIC %md ##### Install Packages that are needed

# COMMAND ----------

dbutils.library.installPyPI("azureml_sdk", extras="databricks") # dbutils.library.installPyPI("azureml_sdk", version="1.0.83", extras="databricks")
dbutils.library.installPyPI("mlflow", version="1.7.2")
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md ##### Set Parameters

# COMMAND ----------

# MAGIC %run "../../../shared/parameters_poc"

# COMMAND ----------

## DEFINE GLOBALS
PLOT    = False
PS      = {'spline':0.6, 'shift':0.05}

# COMMAND ----------

# MAGIC %md ##### Setup Environment

# COMMAND ----------

from pyspark.sql.types import ArrayType
from scipy import stats
from datetime import date, timedelta
from pyspark.sql import SQLContext
import dateutil
import datetime
from pyspark.sql import functions as F
from pyspark.sql import Window
from pyspark.sql.functions import max as max_
from pyspark.sql.functions import min as min_
# Loads Basic Packages
import pyspark
from pyspark.sql import HiveContext
from pyspark.sql.types import *
from pyspark.sql.functions import udf
from pyspark.sql.functions import col, concat_ws, lit
from pyspark.sql import functions as f
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from collections import Counter
import math
import ast, random

import azureml.core
from azureml.core import Workspace
from azureml.core.run import Run
from azureml.core.experiment import Experiment
from azureml.core.authentication import ServicePrincipalAuthentication
from azureml.core.model import Model

import mlflow

from pyspark.ml import Pipeline
from pyspark.ml.feature import OneHotEncoder # OneHotEncoderEstimator
from pyspark.ml.feature import StringIndexer
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.feature import Imputer
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.classification import GBTClassifier
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.tuning import ParamGridBuilder
from pyspark.ml.tuning import CrossValidator

import pandas as pd #; print(pd.__version__)
import numpy as np #; print(np.__version__)
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib.patches as mpatches

from sklearn.decomposition import PCA
from sklearn.ensemble import IsolationForest

from pyspark.sql.types import FloatType
from pyspark.sql.functions import expr
from pyspark.sql.functions import slice


# from itertools import chain

# Check core SDK version number
print("SDK version:", azureml.core.VERSION)
print("MLFlow version: ", mlflow.version.VERSION)

# Lists names of secret scopes and keys within them that are active for this Databricks Workspace
print("Secret Scopes:")
for x in dbutils.secrets.listScopes():
  print(x.name)
  print ("    Keys Available:")
  for y in dbutils.secrets.list(x.name):
    print ("    " + y.key)
    
# Required config settings to enable proper use of Credential PassThrough to connect to storage account
spark.conf.set("fs.azure.account.auth.type", "CustomAccessToken")
spark.conf.set("fs.azure.account.custom.token.provider.class", spark.conf.get("spark.databricks.passthrough.adls.gen2.tokenProviderClassName"))

# Key constants to define
storage_acct_name = "dha0mlp0prod"
random_seed_val = 13486

# Computed constants
adls_source_path = "abfss://tempdata@" + storage_acct_name + ".dfs.core.windows.net"
adls_raw_path = "abfss://raw@" + storage_acct_name + ".dfs.core.windows.net"
adls_ref_path = "abfss://reference@" + storage_acct_name + ".dfs.core.windows.net"
adls_xformed_path = "abfss://transformed@" + storage_acct_name + ".dfs.core.windows.net"
adls_results_path = "abfss://results@" + storage_acct_name + ".dfs.core.windows.net"

# COMMAND ----------

# MAGIC %md ##### Import Increased Normalized Trends Functions

# COMMAND ----------

claims_agg_day = (spark.read.parquet(adls_xformed_path + '/lvl1/cons-ds/kgh2848/increasing_normalized_trend_prod' + VERSION_SAVE))

# COMMAND ----------

df = claims_agg_day.toPandas() # Spark to Pandas | # df_sp = spark_session.createDataFrame(df_pd) # Pandas to Spark

# COMMAND ----------

# MAGIC %md ##### Increased Normalized Trends Threshold

# COMMAND ----------

## READ ALL DATA
DATA  = df
DATA['npe'] = DATA['npe'].apply( lambda v:v[v!=-1] )
NPE = DATA['npe'].to_list()
NPE_2 = DATA['npe_trim'].to_list()
ACN = DATA['claims_vector'].to_list()
PID = DATA['phar_nabp_id'].to_list()

# COMMAND ----------

## Define functions
def get_normal_filter(vector, z=2, ps=0.15):
    #. z (integer): z score to create the maximum filter width
    #. ps (float): percent size in number of data points
    assert isinstance(z, int)
    assert z>0
    assert ps>0
    assert ps<0.8
    # compute normal filter
#     sigma = np.std(vector) # Have to do if then because of the division of 0
    if np.std(vector) == 0:
      sigma = np.std(vector)-.00001
    else:
      sigma = np.std(vector)
    size  = vector.shape[0]
    dx = 2*z*sigma/(ps*size)
    gx = np.arange(-z*sigma, z*sigma, dx)
    return np.exp(-(gx/sigma)**2/2).astype(vector.dtype)
  
def auto_adjusting_convolution(vector, filter):
    # filter computed using get_normal_filter
    if not filter.shape[0]%2:
        filter = (filter[1:]+filter[:-1])/2
    total = np.sum(filter)
    wca   = int( (filter.shape[0]-1)/2 )
    lda   = vector.shape[0]
    res   = []
    # compute sums
#     sums = np.array( [np.sum(filter[wca-i:wca+i+1]) for i in range(wca+1)] )
    for i in range(lda):
#         w = min(i,wca,lda-i-1)
        lw=min(i,wca)
        rw=min(wca,lda-i-1)
#         if w == 0:
#             d = vector[i]
#         elif w == wca:
#             d = np.sum(vector[i-w:i+w+1]*filter) / sums[w]
#         else:
#             d = np.sum(vector[i-w:i+w+1] * filter[wca-w:wca+w+1]) / sums[w]
        fil=filter[wca-lw:wca+rw+1]
        d = np.sum(vector[i-lw:i+rw+1] * fil) / np.sum(fil)
        res.append(d)
    return np.array(res, dtype=vector.dtype)

# COMMAND ----------

range_pharm = len(NPE)
len(NPE)

# COMMAND ----------

  ## Run analysis
diffs   = {}
peaks   = {}
stats   = {}
trends  = {}
shifts  = {}
splines = {}
rels = {}

diffs_2   = {}
peaks_2   = {}
stats_2   = {}
trends_2  = {}
shifts_2  = {}
splines_2 = {}
rels_2    = {}



PLOT = False
#
for index in range(range_pharm):
    v   = NPE[index]
    pid = PID[index]
    splineFilter = get_normal_filter(vector=v, ps=PS['spline'])
    spline = auto_adjusting_convolution(vector=v, filter=splineFilter)
    filter = get_normal_filter(vector=v, ps=PS['shift'])
    shift = auto_adjusting_convolution(vector=v, filter=filter)
    d = shift-spline
    
    v_2 = NPE_2[index]
    splineFilter_2 = get_normal_filter(vector=v_2, ps=PS['spline'])
    spline_2 = auto_adjusting_convolution(vector=v_2, filter=splineFilter_2)
    filter_2 = get_normal_filter(vector=v_2, ps=PS['shift'])
    shift_2 = auto_adjusting_convolution(vector=v_2, filter=filter_2)
    d_2 = shift_2-spline_2
    
    # compute trend
    idx = int(len(filter)/2.)
    y  = v[idx:-idx]
    x  = range(len(y))
    x = []
    x.append(range(len(y)))                # Time variable
    x.append([1 for ele in range(len(y))]) # This adds the intercept
    y = np.matrix(y).T
    x = np.matrix(x).T
    betas = ((x.T*x).I*x.T*y)
    a, b  = float(betas[0]), float(betas[1]) # a is slope and b intercept
    trend = a*np.arange(len(v))+b
    # append values
    diffs[pid]   = d
    q1  = np.percentile(d,25)
    q2  = np.median(d)
    q3  = np.percentile(d,75)
    iqr = q3-q1
    diffs_2[pid]   = d_2
    q1_2  = np.percentile(d_2,25)
    q2_2  = np.median(d_2)
    q3_2  = np.percentile(d_2,75)
    iqr_2 = q3_2-q1_2
    stats[pid]   = {'std':np.std(d), 'avg':np.mean(d), '25%':q1,'50%':q2,'75%':q3, 'interquartile':iqr, 'lower_bound_whisker':q1-1.5*iqr, 'upper_bound_whisker':q3+1.5*iqr}
    stats_2[pid]   = {'std_2':np.std(d_2), 'avg_2':np.mean(d_2), '25%_2':q1_2,'50%_2':q2_2,'75%_2':q3_2, 'interquartile_2':iqr_2, 'lower_bound_whisker_2':q1_2-1.5*iqr_2, 'upper_bound_whisker_2':q3_2+1.5*iqr_2}
    trends[pid]  = (float(betas[0]), float(betas[1]))
    shifts[pid]  = shift
    splines[pid] = spline
    peaks[pid]   = {'crossing_indexes':[], 'relative_diff_ratio':None}
    d_ubw = d-stats[pid]['upper_bound_whisker']
    d_ubw_max = np.max(d_ubw)
    d_ubw_2 = d_2-stats_2[pid]['upper_bound_whisker_2']
    d_ubw_max_2 = np.max(d_ubw_2)
#     if d_ubw_max>0:
    if d_ubw_max_2>0:
      peaks[pid]['relative_diff_ratio'] = d_ubw_max_2/stats_2[pid]['upper_bound_whisker_2']
    peaks[pid]['crossing_indexes'] = np.where(np.diff(np.signbit(d_ubw)))[0]
    # plot
    if PLOT:
        _ = plt.figure()
        _ = plt.plot(NPE[index], label='idx (%s) id (%s)'%(index, pid))
        _ = plt.plot(spline, label='spline')
        _ = plt.plot(shift, label='shift')
        _ = plt.plot(d, label='diff')
        _ = plt.hlines(stats[pid]['std'],xmin=0, xmax=len(d), linestyle='--', color='k',label='std')
        _ = plt.hlines(stats[pid]['lower_bound_whisker'],xmin=0, xmax=len(d), linestyle='--', color='y',label='lower whisker')
        _ = plt.hlines(stats[pid]['upper_bound_whisker'],xmin=0, xmax=len(d), linestyle='--', color='c',label='upper whisker')
        _ = plt.plot(trend, label='trend: %.5f, %.2f'%(a,b))
        # find where crossing upper whisker
        _,_, ymin,ymax = plt.axis()
#         d_ubw = d-stats[pid]['upper_bound_whisker']
#         d_ubw_max = np.max(d_ubw)
#         if d_ubw_max>0:
#             peaks[pid]['relative_diff_ratio'] = d_ubw_max/stats[pid]['upper_bound_whisker']
#         peaks[pid]['crossing_indexes'] = np.where(np.diff(np.signbit(d_ubw)))[0]
        for i in peaks[pid]['crossing_indexes']:
            _ = plt.vlines(i,ymin=ymin, ymax=ymax, linestyle='dotted', color='k')
        # set axis title
#         rels[pid]   = 'NaN' if peaks[pid]['relative_diff_ratio'] is None else '%.3f'%peaks[pid]['relative_diff_ratio'] # Dont need - already included in peaks
        rel   = 'NaN' if peaks[pid]['relative_diff_ratio'] is None else '%.3f'%peaks[pid]['relative_diff_ratio']
        title = '%i crossings | %s max relative peak'%(len(peaks[pid]['crossing_indexes']), rel)
        _=plt.gca().set_title(title)
        # show legend
        _ = plt.legend(frameon=False, ncol=2)
#         ax2 = plt.gca().twinx()
#         ax2.plot(ACN[index],"--",color = "cyan",zorder=-5)
#         ax2.set_ylabel("actual_claims")
####

if PLOT:
    plt.show()
####


diffMin  = np.min([np.min(diffs[pid]) for pid in diffs])
diffMax  = np.max([np.max(diffs[pid]) for pid in diffs])
bins     = np.linspace(diffMin,diffMax,20)
edges    = 0.5*(bins[:-1]+bins[1:])
diffFig  = plt.figure()
hists    = {None:0}
for pid in diffs:
    hists[pid]   = np.histogram(diffs[pid], bins=bins)[0]
    hists[None] += hists[pid]
#     diffFig.gca().scatter(edges,hists[pid]/np.sum(hists[pid]), label=pid)
# ####

# diffFig.gca().plot(edges,hists[None]/np.sum(hists[None]), label='all')
# diffFig.gca().legend(ncol=4, frameon=False, loc='upper left')
# plt.show()

# COMMAND ----------

diffs_df = pd.DataFrame(list(diffs.items()),columns = ['phar_nabp_id','diffs'])

peaks_df = pd.DataFrame(list(peaks.items()),columns = ['phar_nabp_id','peaks'])
peaks_df = peaks_df.join(pd.json_normalize(peaks_df['peaks']))
peaks_df = peaks_df.drop(columns=['peaks'])
peaks_df['cross_indexes_ct'] = peaks_df.crossing_indexes.str.len()

stats_df = pd.DataFrame(list(stats.items()),columns = ['phar_nabp_id','stats'])
stats_df = stats_df.join(pd.json_normalize(stats_df['stats']))
stats_df = stats_df.drop(columns=['stats'])

trends_df = pd.DataFrame(list(trends.items()),columns = ['phar_nabp_id','trends'])
trends_df['trends'] = [list(i) for i in trends_df.trends]

shifts_df = pd.DataFrame(list(shifts.items()),columns = ['phar_nabp_id','shifts'])

splines_df = pd.DataFrame(list(splines.items()),columns = ['phar_nabp_id','splines'])


# COMMAND ----------

df = pd.merge(df, diffs_df, on='phar_nabp_id', how='left')
df = pd.merge(df, peaks_df, on='phar_nabp_id', how='left')
df = pd.merge(df, stats_df, on='phar_nabp_id', how='left')
df = pd.merge(df, trends_df, on='phar_nabp_id', how='left')
df = pd.merge(df, shifts_df, on='phar_nabp_id', how='left')
df = pd.merge(df, splines_df, on='phar_nabp_id', how='left')

# COMMAND ----------

df = spark.createDataFrame(df) # Pandas to Spark
# df = (spark.read.parquet(adls_xformed_path + '/lvl1/models/fwa_dataset/inc_threshold_dataset_prep_prod' + VERSION_SAVE))

# COMMAND ----------

# Flags for npe_trim 
df = df.withColumn("flag_inc_opt_1",F.when((df.relative_diff_ratio > df.upper_bound_whisker) & (df.max_claims_vector >= 125) & 
                                                 (df.relative_diff_ratio >= 4.89), F.lit(1)).otherwise(F.lit(0)))

# Flags for npe_trim
df = df.withColumn("flag_inc_opt_2",F.when((df.relative_diff_ratio > df.upper_bound_whisker) & (df.filter_max_claims == 1) & 
                                                 (df.relative_diff_ratio >= 3.9) & 
                                                 (df.claims_vector_ratio >= .18), F.lit(1)).otherwise(F.lit(0)))
###################################################################

df = df.withColumn("flag_inc_opt",F.when((df.flag_inc_opt_1 == 1) | (df.flag_inc_opt_2 == 1), F.lit(1)).otherwise(F.lit(0)))

# COMMAND ----------

# Filter to columns
inc_features =  ['phar_nabp_id',
                 'dates_vector','claims_vector','members_vector','npe','npe_trim',
                 'max_claims_vector','filter_max_claims','claims_vector_ratio',
                 'diffs','crossing_indexes','relative_diff_ratio','cross_indexes_ct',
                 'std_y','avg','25%','50%','75%','interquartile','lower_bound_whisker','upper_bound_whisker',
                 'trends','shifts','splines',
                 'flag_inc_opt','flag_inc_opt_1','flag_inc_opt_2']

#Filters your initial dataframe down to important columns
df = df.select(inc_features)

# COMMAND ----------

# display(df.filter(col('flag_inc_opt') == 1))

# COMMAND ----------

# Write file join to disk
(df
 .write
 .mode("overwrite")
 .option("header", "true")
 .format("parquet")
 .save(adls_xformed_path + '/lvl1/models/fraud_datasets/inc_threshold_dataset_prep_prod' + VERSION_SAVE))

# COMMAND ----------


