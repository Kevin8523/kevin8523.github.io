# Databricks notebook source
# What does this Hypothesis do? (1-2 sentences)
# Looks at the distribution of drug classes at Humana and compares it to each and every pharmacy calculating a loss function for each pharmacy

# COMMAND ----------

# MAGIC %md ##### Install Packages that are needed

# COMMAND ----------

dbutils.library.installPyPI("azureml_sdk", extras="databricks")
dbutils.library.installPyPI("mlflow", version="1.7.2")
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md ##### Set Parameters

# COMMAND ----------

# # USING process_date as the date filter 
# BEGIN_DATE = '2018-01-01'
# END_DATE = '2021-07-11'

# ROLLING_WINDOW_SIZE = 41 # Has to be odd
# ROLLING_MIN_PERIOD = 5
# ROLLING_WINDOW_SIZE_MEM = 41 # Has to be odd
# MIN_CLAIMS_THRESHOLD_INC = 50

# COMMAND ----------

# MAGIC %run "../../../shared/parameters_poc"

# COMMAND ----------

# MAGIC %md ##### Setup Environment

# COMMAND ----------

from pyspark.sql.types import ArrayType
from scipy import stats
from datetime import date, timedelta
from pyspark.sql import SQLContext
import dateutil
import datetime
from pyspark.sql import functions as F
from pyspark.sql import Window
from pyspark.sql.functions import max as max_
from pyspark.sql.functions import min as min_
# Loads Basic Packages
import pyspark
from pyspark.sql import HiveContext
from pyspark.sql.types import *
from pyspark.sql.functions import udf
from pyspark.sql.functions import col, concat_ws, lit
from pyspark.sql import functions as f
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from collections import Counter
import math

import azureml.core
from azureml.core import Workspace
from azureml.core.run import Run
from azureml.core.experiment import Experiment
from azureml.core.authentication import ServicePrincipalAuthentication
from azureml.core.model import Model

import mlflow

from pyspark.ml import Pipeline
from pyspark.ml.feature import OneHotEncoder # OneHotEncoderEstimator
from pyspark.ml.feature import StringIndexer
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.feature import Imputer
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.classification import GBTClassifier
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.tuning import ParamGridBuilder
from pyspark.ml.tuning import CrossValidator

import pandas as pd #; print(pd.__version__)
import numpy as np #; print(np.__version__)
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib.patches as mpatches

from pyspark.sql.types import FloatType
from pyspark.sql.functions import expr
from pyspark.sql.functions import slice


# from itertools import chain

# Check core SDK version number
print("SDK version:", azureml.core.VERSION)
print("MLFlow version: ", mlflow.version.VERSION)

# Lists names of secret scopes and keys within them that are active for this Databricks Workspace
print("Secret Scopes:")
for x in dbutils.secrets.listScopes():
  print(x.name)
  print ("    Keys Available:")
  for y in dbutils.secrets.list(x.name):
    print ("    " + y.key)
    
# Required config settings to enable proper use of Credential PassThrough to connect to storage account
spark.conf.set("fs.azure.account.auth.type", "CustomAccessToken")
spark.conf.set("fs.azure.account.custom.token.provider.class", spark.conf.get("spark.databricks.passthrough.adls.gen2.tokenProviderClassName"))

# Key constants to define
storage_acct_name = "dha0mlp0prod"
random_seed_val = 13486

# Computed constants
adls_source_path = "abfss://tempdata@" + storage_acct_name + ".dfs.core.windows.net"
adls_raw_path = "abfss://raw@" + storage_acct_name + ".dfs.core.windows.net"
adls_ref_path = "abfss://reference@" + storage_acct_name + ".dfs.core.windows.net"
adls_xformed_path = "abfss://transformed@" + storage_acct_name + ".dfs.core.windows.net"
adls_results_path = "abfss://results@" + storage_acct_name + ".dfs.core.windows.net"

# COMMAND ----------

# MAGIC %md ##### Import Increased Normalized Trends Functions

# COMMAND ----------

# MAGIC %run "../../../shared/pharmacy_increased_normalized_trend_functions_v2"

# COMMAND ----------

# MAGIC %run "../../../shared/pharmacy_term_list"

# COMMAND ----------

# MAGIC %run "../../../shared/hum_drug_class_bucket_features"

# COMMAND ----------

# MAGIC %md ##### Increased Normalized Trends

# COMMAND ----------

# Pharmacy behavior - irregular mix of drug classes - compared to similar pharmacies 
# Pharmacies that don't fill the top X drugs / common drugs make up a small % of scripts filled

# COMMAND ----------

#######################
# Reads in the data using the load_claims_facts() from the pharmacy_increased_normalized_trend_functions_v2 shared function.
# This command is creating the base tables that we will be using
#######################
claims_fact_line = load_claims_facts()
claims_fact_line.select('phar_nabp_id','document_key',
                         'service_date',
                         'sdr_person_id','ndc_id','rx_cost','mbr_respons_amt','net_paid_amt','rx_count',
                         'fdb_generic_name','hum_drug_class_desc'
                       ).filter((col('service_date') >= BEGIN_DATE) & (col('service_date') < END_DATE) &
                                (claims_fact_line.rx_count == 1) & (claims_fact_line.reversal_ind != 'Y'))

claims_fact_line = claims_fact_line.withColumn('pharmacy_terminated', f.when(col('phar_nabp_id').isin(term_list),1).otherwise(0))

drug_class_df = (spark.read.parquet(adls_ref_path + DRUG_TBL_URL).select([col('ndc_id'), col('dea_sch_ind'), col('hum_drug_class_desc')]))
drug_class_df = drug_class_df.withColumn('drug_class',udf(lambda hum_class: humana_class_to_merged_class[hum_class],StringType())(col('hum_drug_class_desc'))).select(['ndc_id', 'drug_class'])

claims_fact_line = claims_fact_line.join(drug_class_df,["ndc_id"],'left_outer').select('phar_nabp_id','document_key','sdr_person_id',
                                                                                       'service_date',
                                                                                       'ndc_id',
                                                                                       'drug_class','fdb_generic_name','hum_drug_class_desc',
                                                                                       'rx_cost','mbr_respons_amt','net_paid_amt','rx_count',
                                                                                       'pharmacy_terminated') # 'spcl_drug_ind'


# display(claims_fact_line)

# COMMAND ----------

#######################
# Applies filters so the pharmacies that are compared are apples to apples
#######################
pharmacy_df = spark.read.parquet(adls_ref_path + "/clinical/lu_pharmacy"
                                ).filter((col('mail_order_phar_ind') == 'N') & # could remove but helps reduce false positive
                                         (col('ltc_phar_ind') =='N') &
                                         (col('mil_phar_ind') == 'N') & 
                                         (col('inst_phar_ind') == 'N') & 
                                         (col('hum_own_ind') == 'N') & 
                                         (col('hit_phar_ind') == 'N') & 
                                         (col('phar_specialty') == 'N') &
                                         (((col('disp_class_cd') == '1') | (col('disp_class_cd') == '01')) & ((col('disp_type_cd') == '1') | (col('disp_type_cd') == '01')))
                                         ).select('phar_nabp_id','phar_independent_ind','dme_phar_ind','clin_phar_ind','rtl_phar_ind','cmpnd_phar_ind','mail_order_phar_ind','phar_specialty')

pharmacy_df = pharmacy_df.withColumn('triage_filter',f.lit(1))
# display(pharmacy_df)

# COMMAND ----------

claims_fact_line = claims_fact_line.join(pharmacy_df,["phar_nabp_id"],'left_outer')
claims_fact_line = claims_fact_line.filter(col('triage_filter') == 1)
claims_fact_line = claims_fact_line.filter(col('drug_class').isNotNull())

# COMMAND ----------

#######################
# Creates the global distribution of Humana pharmacies by drug class. This will be used to compare with each and 
# every pharmacy to determine an abnormal pharmacy and to calculate the loss function
#######################
drugclass_mix = claims_fact_line.groupBy(['drug_class']) \
                        .agg(f.count(col('document_key')).alias('drugclass_count'),
                            (f.count(col('document_key')) / claims_fact_line.count()).alias('drugclass_pct')) \
                        .orderBy(col("drugclass_pct"),ascending=False)

drugclass_mix = drugclass_mix.withColumn('_',f.lit(1))
w = Window.partitionBy('_').orderBy(f.desc("drugclass_pct"))
drugclass_mix = drugclass_mix.withColumn("rank",f.row_number().over(w))
                                 
# display(drugclass_mix)

# COMMAND ----------

#######################
# This is just for knowledge purposes, here we are looking at the distirbution of drug classes for the terminated pharamcies 
#######################
drugclass_mix_1 = claims_fact_line.filter(col('pharmacy_terminated') == 1).groupBy(['drug_class']) \
                        .agg(f.count(col('document_key')).alias('drugclass_count'),
                            (f.count(col('document_key')) / (claims_fact_line.filter(col('pharmacy_terminated') == 1).count())).alias('drugclass_pct'))

drugclass_mix_1 = drugclass_mix_1.join(drugclass_mix.select(['drug_class','rank']),["drug_class"],'left_outer').orderBy(col("rank"),ascending=True)
                     
# display(drugclass_mix_1)

# COMMAND ----------

#######################
# This is just for knowledge purposes, here we are looking at the distirbution of drug classes for the Non-terminated pharamcies 
#######################
drugclass_mix_0 = claims_fact_line.filter(col('pharmacy_terminated') == 0).groupBy(['drug_class']) \
                        .agg(f.count(col('document_key')).alias('drugclass_count'),
                            (f.count(col('document_key')) / (claims_fact_line.filter(col('pharmacy_terminated') == 0).count())).alias('drugclass_pct'))

drugclass_mix_0 = drugclass_mix_0.join(drugclass_mix.select(['drug_class','rank']),["drug_class"],'left_outer').orderBy(col("rank"),ascending=True)

# display(drugclass_mix_0)

# COMMAND ----------

#######################
# Creates a dataframe that has the global distribution of drugclass pct (above code) and the distribution of drugclass for each pharmacy (individually their drugclass breakout).
# Also calculates the standard deviation for each drugclass (global distn) and manually does the first step in some of the loss functions (We sum up the values in another command)
# NOTE: If the standard deviation is greater than or equal to the difference of the global & pharmacy distn, it will include that value in the loss function
#######################
drugclass_pharmacy_mix = claims_fact_line.groupBy(['phar_nabp_id','drug_class']) \
                        .agg(f.count(col('document_key')).alias('drugclass_count'),
                             f.max('pharmacy_terminated').alias('pharmacy_terminated'))

drugclass_pharmacy_mix = drugclass_pharmacy_mix.withColumn('drugclass_by_pharm_pct',col('drugclass_count')/f.sum(col('drugclass_count')).over(Window.partitionBy('phar_nabp_id')))


drugclass_pharmacy_mix = drugclass_pharmacy_mix.join(drugclass_mix.select(['drug_class','drugclass_pct','rank']),["drug_class"],'left_outer')

drugclass_pharmacy_mix = drugclass_pharmacy_mix.withColumn('drugclass_abs_diff',f.abs(col('drugclass_by_pharm_pct') - col('drugclass_pct')))

drugclass_pharmacy_mix = drugclass_pharmacy_mix.withColumn('std_drugclass_pharm', f.stddev(col('drugclass_by_pharm_pct')).over(Window.partitionBy('drug_class')))
drugclass_pharmacy_mix = drugclass_pharmacy_mix.withColumn('drugclass_abs_diff_updated', f.when(col('drugclass_abs_diff') <= col('std_drugclass_pharm'),0).otherwise(col('drugclass_abs_diff')))

drugclass_pharmacy_mix = drugclass_pharmacy_mix.withColumn('l2_drugclass',f.pow((col('drugclass_abs_diff_updated')),2))

drugclass_pharmacy_mix = drugclass_pharmacy_mix.withColumn('drugclass_diff_welsch_cauchy_pct',(col('drugclass_abs_diff_updated'))*100)

# display(drugclass_pharmacy_mix)

# COMMAND ----------

#######################
# Calculates Welsch & Cauchy Loss functions
#######################
c = 3
drugclass_pharmacy_mix = drugclass_pharmacy_mix.withColumn('welsch_diff',1-f.exp(-0.5 * f.pow((col('drugclass_abs_diff_updated'))/c,2)))
drugclass_pharmacy_mix = drugclass_pharmacy_mix.withColumn('cauchy_diff',f.log(1 + 0.5 * f.pow(col('drugclass_diff_welsch_cauchy_pct')/c,2)))

# COMMAND ----------

#######################
# Sums up the values by pharmacy to complete the different loss functions 
#######################
l1_norm = drugclass_pharmacy_mix.groupBy(['phar_nabp_id']) \
                        .agg(f.sum(col('drugclass_abs_diff_updated')).alias('l1'),
                             (f.sum(col('drugclass_abs_diff_updated'))*100).alias('l1_pct'),
                             f.sum(col('welsch_diff')).alias('welsch'),
                             (f.sum(col('welsch_diff'))*100).alias('welsch_pct'),
                             (f.sum(col('cauchy_diff'))/100).alias('cauchy'),
                             f.sum(col('cauchy_diff')).alias('cauchy_pct'),
                             f.sum(col('l2_drugclass')).alias('l2_sum'),
                             f.sum(col('drugclass_count')).alias('ct_drugs'),
                             f.max('pharmacy_terminated').alias('pharmacy_terminated'))

l1_norm = l1_norm.withColumn('l2',f.sqrt('l2_sum'))
l1_norm = l1_norm.withColumn('l2_pct',col('l2')*100)
l1_norm = l1_norm.drop(col('l2_sum'))
# display(l1_norm)

# COMMAND ----------

#######################
# Converts to Pandas and filters on pharmacy with more than 100 drug counts to get a bigger samplesize
#######################
pandas_df = l1_norm.filter(col('ct_drugs') > 100).toPandas() # used because we want a bigger sample of members to not skew the statistics


# COMMAND ----------

pandas_df[['phar_nabp_id','l1_pct','l2_pct','welsch_pct','cauchy_pct','ct_drugs','pharmacy_terminated']].head()

# COMMAND ----------

max(pandas_df.l1_pct)

# COMMAND ----------

#######################
# Plots the true positive (terminated pharm / total pharmacies flagged) against the percetage in the loss function
# This visual allows us to select a threshold that optmizies on True Positive - typically look for a Consequent increase 
#######################
# distance 100 - 29/101 - 95%
ratio = []
percentage = []
for perc in range(1,201):
  l = pandas_df[pandas_df.l1_pct > perc]['phar_nabp_id'].tolist()
  if len(l) == 0:
    continue
  intersect_list = [x for x in l if x in term_list]
  percentage.append(perc)
  ratio.append(len(intersect_list)/len(l))
tmp_df = pd.DataFrame()
tmp_df['x']= pd.Series(percentage)
tmp_df['y']= pd.Series(ratio)
max_index = np.argmax(ratio)
plt.plot(tmp_df['x'], tmp_df['y'])
print(percentage[max_index])

# COMMAND ----------

print(percentage[max_index])

# COMMAND ----------

#######################
# Selects the threshold cutoff and creates the flags for the pharmacies
# We are trying to simplify it so we only use one threshold cutoff
#######################
pickedup_pharmacies = pandas_df[(pandas_df.l1_pct > 160)]['phar_nabp_id'].tolist()
intersect_list = [x for x in pickedup_pharmacies if x in term_list]
print('Total = ', len(pickedup_pharmacies))
print('TP = ',len(intersect_list))
print(intersect_list)

pandas_df['flag_irregular_drug_class_l1_opt'] = pandas_df.isin(pickedup_pharmacies).any(1).astype(int)

# COMMAND ----------

max(pandas_df.l2_pct)

# COMMAND ----------

#######################
# Same as the above code (except this is for a different loss function - l2)
# Plots the true positive (terminated pharm / total pharmacies flagged) against the percetage in the loss function
# This visual allows us to select a threshold that optmizies on True Positive - typically look for a Consequent increase 
#######################
# distance 100 - 29/101 - 95%
ratio = []
percentage = []
for perc in range(1,105):
  l = pandas_df[pandas_df.l2_pct > perc]['phar_nabp_id'].tolist()
  if len(l) == 0:
    continue
  intersect_list = [x for x in l if x in term_list]
  percentage.append(perc)
  ratio.append(len(intersect_list)/len(l))
tmp_df = pd.DataFrame()
tmp_df['x']= pd.Series(percentage)
tmp_df['y']= pd.Series(ratio)
max_index = np.argmax(ratio)
plt.plot(tmp_df['x'], tmp_df['y'])
print(percentage[max_index])

# COMMAND ----------

print(percentage[max_index])

# COMMAND ----------

#######################
# Selects the threshold cutoff and creates the flags for the pharmacies
# We are trying to simplify it so we only use one threshold cutoff
#######################
pickedup_pharmacies = pandas_df[(pandas_df.l2_pct > 90)]['phar_nabp_id'].tolist()
intersect_list = [x for x in pickedup_pharmacies if x in term_list]
print('Total = ', len(pickedup_pharmacies))
print('TP = ',len(intersect_list))
print(intersect_list)

pandas_df['flag_irregular_drug_class_l2_opt'] = pandas_df.isin(pickedup_pharmacies).any(1).astype(int)

# COMMAND ----------

max(pandas_df.welsch_pct)

# COMMAND ----------

# distance 100 - 29/101 - 95%
ratio = []
percentage = []
for perc in range(1,50):
  l = pandas_df[pandas_df.welsch_pct > perc]['phar_nabp_id'].tolist()
  if len(l) == 0:
    continue
  intersect_list = [x for x in l if x in term_list]
  percentage.append(perc)
  ratio.append(len(intersect_list)/len(l))
tmp_df = pd.DataFrame()
tmp_df['x']= pd.Series(percentage)
tmp_df['y']= pd.Series(ratio)
max_index = np.argmax(ratio)
plt.plot(tmp_df['x'], tmp_df['y'])
print(percentage[max_index])

# COMMAND ----------

print(percentage[max_index])

# COMMAND ----------

#######################
# Selects the threshold cutoff and creates the flags for the pharmacies
# We are trying to simplify it so we only use one threshold cutoff
#######################
pickedup_pharmacies = pandas_df[(pandas_df.welsch_pct > 4)]['phar_nabp_id'].tolist()
intersect_list = [x for x in pickedup_pharmacies if x in term_list]
print('Total = ', len(pickedup_pharmacies))
print('TP = ',len(intersect_list))
print(intersect_list)

pandas_df['flag_irregular_drug_class_welsch_opt'] = pandas_df.isin(pickedup_pharmacies).any(1).astype(int)

# COMMAND ----------

max(pandas_df.cauchy_pct)

# COMMAND ----------

# distance 100 - 29/101 - 95%
ratio = []
percentage = []
for perc in range(1,50):
  l = pandas_df[pandas_df.cauchy_pct > perc]['phar_nabp_id'].tolist()
  if len(l) == 0:
    continue
  intersect_list = [x for x in l if x in term_list]
  percentage.append(perc)
  ratio.append(len(intersect_list)/len(l))
tmp_df = pd.DataFrame()
tmp_df['x']= pd.Series(percentage)
tmp_df['y']= pd.Series(ratio)
max_index = np.argmax(ratio)
plt.plot(tmp_df['x'], tmp_df['y'])
print(percentage[max_index])

# COMMAND ----------

print(percentage[max_index])

# COMMAND ----------

#######################
# Selects the threshold cutoff and creates the flags for the pharmacies
# We are trying to simplify it so we only use one threshold cutoff
#######################
pickedup_pharmacies = pandas_df[(pandas_df.cauchy_pct > 15)]['phar_nabp_id'].tolist()
intersect_list = [x for x in pickedup_pharmacies if x in term_list]
print('Total = ', len(pickedup_pharmacies))
print('TP = ',len(intersect_list))
print(intersect_list)

pandas_df['flag_irregular_drug_class_cauchy_opt'] = pandas_df.isin(pickedup_pharmacies).any(1).astype(int)

# COMMAND ----------

#######################
# Select the features to save and converts to spark to save the dataframe
#######################
flag_irr_drug_df = pandas_df[['phar_nabp_id',
                              'l1_pct','l2_pct','welsch_pct','cauchy_pct','ct_drugs',
                              'flag_irregular_drug_class_l1_opt','flag_irregular_drug_class_l2_opt',
                              'flag_irregular_drug_class_welsch_opt','flag_irregular_drug_class_cauchy_opt']]

flag_irr_drug_df_spark = spark.createDataFrame(flag_irr_drug_df) # Pandas to Spark
# display(flag_irr_drug_df_spark)

# COMMAND ----------

# Save file
(flag_irr_drug_df_spark
.write
.mode("overwrite")
.option("header", "true")
.format("parquet")
.save(adls_xformed_path + '/lvl1/models/fwa_dataset/irregular_mix_drugclass_flag_prod' + VERSION_SAVE))

# COMMAND ----------

#
