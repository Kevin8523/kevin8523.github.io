import ast, random
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.ensemble import IsolationForest

from bidules import cls

## DEFINE GLOBALS
PLOT    = True
PS      = {'spline':0.6, 'shift':0.05}

## READ ALL DATA
DATA  = pd.read_csv("increased_normalized_claims_rand.csv")
DATA['npe'] = DATA['npe'].apply( lambda v:np.array(ast.literal_eval(v), dtype=float) )
DATA['npe'] = DATA['npe'].apply( lambda v:v[v!=-1] )
NPE = DATA['npe'].to_list()
PID = DATA['phar_nabp_id'].to_list()



## Define functions
def get_normal_filter(vector, z=2, ps=0.15):
    #. z (integer): z score to create the maximum filter width
    #. ps (float): percent size in number of data points
    assert isinstance(z, int)
    assert z>0
    assert ps>0
    assert ps<0.8
    # compute normal filter
    sigma = np.std(vector)
    size  = vector.shape[0]
    dx = 2*z*sigma/(ps*size)
    gx = np.arange(-z*sigma, z*sigma, dx)
    return np.exp(-(gx/sigma)**2/2).astype(vector.dtype)

def auto_adjusting_convolution(vector, filter):
    # filter computed using get_normal_filter
    if not filter.shape[0]%2:
        filter = (filter[1:]+filter[:-1])/2
    total = np.sum(filter)
    wca   = int( (filter.shape[0]-1)/2 )
    lda   = vector.shape[0]
    res   = []
    # compute sums
    sums = np.array( [np.sum(filter[wca-i:wca+i+1]) for i in range(wca+1)] )
    for i in range(lda):
        w = min(i,wca,lda-i-1)
        if w == 0:
            d = vector[i]
        elif w == wca:
            d = np.sum(vector[i-w:i+w+1]*filter) / sums[w]
        else:
            d = np.sum(vector[i-w:i+w+1] * filter[wca-w:wca+w+1]) / sums[w]
        res.append(d)
    return np.array(res, dtype=vector.dtype)


## Run analysis
diffs   = {}
peaks   = {}
stats   = {}
trends  = {}
shifts  = {}
splines = {}
#
for index in [random.randrange(len(NPE)) for _ in range(10)]:  #range(len(NPE)):
    v   = NPE[index]
    pid = PID[index]
    splineFilter = get_normal_filter(vector=v, ps=PS['spline'])
    spline = auto_adjusting_convolution(vector=v, filter=splineFilter)
    filter = get_normal_filter(vector=v, ps=PS['shift'])
    shift = auto_adjusting_convolution(vector=v, filter=filter)
    d = shift-spline
    # compute trend
    idx = int(len(filter)/2.)
    y  = v[idx:-idx]
    x  = range(len(y))
    x = []
    x.append(range(len(y)))                # Time variable
    x.append([1 for ele in range(len(y))]) # This adds the intercept
    y = np.matrix(y).T
    x = np.matrix(x).T
    betas = ((x.T*x).I*x.T*y)
    a, b  = float(betas[0]), float(betas[1]) # a is slope and b intercept
    trend = a*np.arange(len(v))+b
    # append values
    diffs[pid]   = d
    q1  = np.percentile(d,25)
    q2  = np.median(d)
    q3  = np.percentile(d,75)
    iqr = q3-q1
    stats[pid]   = {'std':np.std(d), 'avg':np.mean(d), '25%':q1,'50%':q2,'75%':q3, 'interquartile':iqr, 'lower_bound_whisker':q1-1.5*iqr, 'upper_bound_whisker':q3+1.5*iqr}
    trends[pid]  = (float(betas[0]), float(betas[1]))
    shifts[pid]  = shift
    splines[pid] = spline
    peaks[pid]   = {'crossing_indexes':[], 'relative_diff_ratio':None}
    # plot
    if PLOT:
        _ = plt.figure()
        _ = plt.plot(NPE[index], label='idx (%s) id (%s)'%(index, pid))
        _ = plt.plot(spline, label='spline')
        _ = plt.plot(shift, label='shift')
        _ = plt.plot(d, label='diff')
        _ = plt.hlines(stats[pid]['std'],xmin=0, xmax=len(d), linestyle='--', color='k',label='std')
        _ = plt.hlines(stats[pid]['lower_bound_whisker'],xmin=0, xmax=len(d), linestyle='--', color='y',label='lower whisker')
        _ = plt.hlines(stats[pid]['upper_bound_whisker'],xmin=0, xmax=len(d), linestyle='--', color='c',label='upper whisker')
        _ = plt.plot(trend, label='trend: %.5f, %.2f'%(a,b))
        # find where crossing upper whisker
        _,_, ymin,ymax = plt.axis()
        d_ubw = d-stats[pid]['upper_bound_whisker']
        d_ubw_max = np.max(d_ubw)
        if d_ubw_max>0:
            peaks[pid]['relative_diff_ratio'] = d_ubw_max/stats[pid]['upper_bound_whisker']
        peaks[pid]['crossing_indexes'] = np.where(np.diff(np.signbit(d_ubw)))[0]
        for i in peaks[pid]['crossing_indexes']:
            _ = plt.vlines(i,ymin=ymin, ymax=ymax, linestyle='dotted', color='k')
        # set axis title
        rel   = 'NaN' if peaks[pid]['relative_diff_ratio'] is None else '%.3f'%peaks[pid]['relative_diff_ratio']
        title = '%i crossings | %s max relative peak'%(len(peaks[pid]['crossing_indexes']), rel)
        _=plt.gca().set_title(title)
        # show legend
        _ = plt.legend(frameon=False, ncol=2)
####

if PLOT:
    plt.show()
####


diffMin  = np.min([np.min(diffs[pid]) for pid in diffs])
diffMax  = np.max([np.max(diffs[pid]) for pid in diffs])
bins     = np.linspace(diffMin,diffMax,20)
edges    = 0.5*(bins[:-1]+bins[1:])
diffFig  = plt.figure()
hists    = {None:0}
for pid in diffs:
    hists[pid]   = np.histogram(diffs[pid], bins=bins)[0]
    hists[None] += hists[pid]
    diffFig.gca().scatter(edges,hists[pid]/np.sum(hists[pid]), label=pid)
####

diffFig.gca().plot(edges,hists[None]/np.sum(hists[None]), label='all')
diffFig.gca().legend(ncol=4, frameon=False, loc='upper left')
plt.show()
