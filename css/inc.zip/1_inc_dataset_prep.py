# Databricks notebook source
dbutils.library.installPyPI("azureml_sdk", extras="databricks")
dbutils.library.installPyPI("mlflow", version="1.7.2")
dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md ##### Set Parameters

# COMMAND ----------

# # USING process_date as the date filter 
# BEGIN_DATE = '2018-01-01' # '2018-12-01'
# END_DATE = '2021-07-11' # '2020-10-20'

# ROLLING_WINDOW_SIZE = 41 # Has to be odd
# ROLLING_MIN_PERIOD = 5
# ROLLING_WINDOW_SIZE_MEM = 41 # Has to be odd
# MIN_CLAIMS_THRESHOLD_INC = 50

# COMMAND ----------

# MAGIC %run "../../../shared/parameters_poc"

# COMMAND ----------

# MAGIC %md ##### Setup Environment

# COMMAND ----------

from pyspark.sql.types import ArrayType
from scipy import stats
from datetime import date, timedelta
from pyspark.sql import SQLContext
import dateutil
import datetime
from pyspark.sql import functions as F
from pyspark.sql import Window
from pyspark.sql.functions import max as max_
from pyspark.sql.functions import min as min_
# Loads Basic Packages
import pyspark
from pyspark.sql import HiveContext
from pyspark.sql.types import *
from pyspark.sql.functions import udf
from pyspark.sql.functions import col, concat_ws, lit
from pyspark.sql import functions as f
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from collections import Counter
import math

import azureml.core
from azureml.core import Workspace
from azureml.core.run import Run
from azureml.core.experiment import Experiment
from azureml.core.authentication import ServicePrincipalAuthentication
from azureml.core.model import Model

import mlflow

from pyspark.ml import Pipeline
from pyspark.ml.feature import OneHotEncoder # OneHotEncoderEstimator
from pyspark.ml.feature import StringIndexer
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.feature import Imputer
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.classification import GBTClassifier
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.tuning import ParamGridBuilder
from pyspark.ml.tuning import CrossValidator

import pandas as pd #; print(pd.__version__)
import numpy as np #; print(np.__version__)
import matplotlib.pyplot as plt
import seaborn as sns
import matplotlib.patches as mpatches

from pyspark.sql.types import FloatType
from pyspark.sql.functions import expr
from pyspark.sql.functions import slice


# from itertools import chain

# Check core SDK version number
print("SDK version:", azureml.core.VERSION)
print("MLFlow version: ", mlflow.version.VERSION)

# Lists names of secret scopes and keys within them that are active for this Databricks Workspace
print("Secret Scopes:")
for x in dbutils.secrets.listScopes():
  print(x.name)
  print ("    Keys Available:")
  for y in dbutils.secrets.list(x.name):
    print ("    " + y.key)
    
# Required config settings to enable proper use of Credential PassThrough to connect to storage account
spark.conf.set("fs.azure.account.auth.type", "CustomAccessToken")
spark.conf.set("fs.azure.account.custom.token.provider.class", spark.conf.get("spark.databricks.passthrough.adls.gen2.tokenProviderClassName"))

# Key constants to define
storage_acct_name = "dha0mlp0prod"
random_seed_val = 13486

# Computed constants
adls_source_path = "abfss://tempdata@" + storage_acct_name + ".dfs.core.windows.net"
adls_raw_path = "abfss://raw@" + storage_acct_name + ".dfs.core.windows.net"
adls_ref_path = "abfss://reference@" + storage_acct_name + ".dfs.core.windows.net"
adls_xformed_path = "abfss://transformed@" + storage_acct_name + ".dfs.core.windows.net"
adls_results_path = "abfss://results@" + storage_acct_name + ".dfs.core.windows.net"

# COMMAND ----------

# MAGIC %md ##### Import Increased Normalized Trends Functions

# COMMAND ----------

# MAGIC %run "../../../shared/pharmacy_increased_normalized_trend_functions_v2"

# COMMAND ----------

# MAGIC 
# MAGIC %md ##### Increased Normalized Trends

# COMMAND ----------

#######################
# Reads in the data using the load_claims_facts() from the pharmacy_increased_normalized_trend_functions_v2 shared function.
# This command is creating the base tables that we will be using
#######################
# Reads the data
claims_fact_line = load_claims_facts()
# display(claims_fact_line)

# COMMAND ----------

#######################
# Creates functions that will be used to normalize the data
# NOTE: These functions uses other function within the INC FUnction shared notebook
#######################
# Functions 
func_create_count_vectors = f.udf(lambda dic_date_to_cnt: date_map2list(dic_date_to_cnt), ArrayType(IntegerType()))
func_create_rolling_sum_vectors_old = f.udf(lambda vec: compute_rolling_sum_old(vec), ArrayType(FloatType()))
func_create_rolling_sum_vectors = f.udf(lambda vec: compute_normalization_sum(vec), ArrayType(FloatType()))

func_create_rolling_normalization_members = f.udf(lambda vec: compute_normalization_members(vec), ArrayType(FloatType()))

# COMMAND ----------

#######################
# Applies filters so we are looking at the correct specified dates & removes reversals
#######################
claims_fact_line = claims_fact_line.filter((claims_fact_line.service_date >= BEGIN_DATE) & 
                                           (claims_fact_line.service_date < END_DATE) & 
                                           (claims_fact_line.rx_count == 1) &
                                           (claims_fact_line.reversal_ind != 'Y')
                                          ).select(['PHAR_NABP_ID', 'service_date', 'DOCUMENT_KEY', 'sdr_person_id'])
# display(claims_fact_line)

# COMMAND ----------

#######################
# Gets the claims and members for each day for each pharmacy - Data to be used for the Increased Normalized Claims filters so the pharmacies that are compared are apples to apples
#######################
claims_agg_day = claims_fact_line.groupby(['PHAR_NABP_ID', 'service_date']).agg(F.count('DOCUMENT_KEY').alias('claim_count'),F.countDistinct('sdr_person_id').alias('member_count'))

claims_agg_day = claims_agg_day\
  .groupBy('PHAR_NABP_ID')\
  .agg(F.map_from_entries(F.collect_list(F.struct(F.date_format(col('service_date'),"yyyy-MM-dd"),'claim_count'))).alias('map_claim_count'),
       F.map_from_entries(F.collect_list(F.struct(F.date_format(col('service_date'),"yyyy-MM-dd"), 'member_count'))).alias('map_member_count'))

# display(claims_agg_day)

# COMMAND ----------

# Creates an array of the dates from BEGIN_DATE - END_DATE
dates_vector_df = create_begin_end_map_dates()

# COMMAND ----------

#######################
# Vectorizes the data so each row will have all of the data for each and every pharmacy 
#######################
claims_agg_day = claims_agg_day \
  .withColumn('claims_vector',func_create_count_vectors(col('map_claim_count'))) \
  .withColumn('members_vector',func_create_count_vectors(col('map_member_count'))) \
  .withColumn('normalized_members_vector',func_create_rolling_normalization_members(col('members_vector'))) \
  .withColumn('npe',func_create_rolling_sum_vectors(col('claims_vector')))

claims_agg_day = claims_agg_day.join(dates_vector_df, ['PHAR_NABP_ID'], 'left_outer')

claims_agg_day = claims_agg_day.select(['phar_nabp_id','dates_vector', 'claims_vector', 'members_vector','normalized_members_vector','npe' ])

# print((claims_agg_day.count(), len(claims_agg_day.columns)))
# display(claims_agg_day)

# COMMAND ----------

# Functions
array_mean = udf(lambda x: float(np.mean(x)), FloatType())
array_std = udf(lambda x: float(np.std(x)), FloatType())
array_var = udf(lambda x: float(np.var(x)), FloatType())
array_find_max = udf(lambda x: float(np.max(x)), FloatType())
array_find_min = udf(lambda x: float(np.min(x)), FloatType())
array_abs = udf(lambda x: float(np.abs(x)), FloatType())


# COMMAND ----------

#######################
# Feature Engineering 
#######################
# Calculations
df = claims_agg_day.select("phar_nabp_id","dates_vector","claims_vector","members_vector","npe") # .limit(2)
df = df.withColumn("claims_vector_no_zeros",expr("filter(claims_vector, x -> x > 0)")) # Filters the -1
df = df.withColumn("avg_claims_if_claims",array_mean("claims_vector_no_zeros"))
df = df.withColumn('npe_trim', F.udf(array_trim_lead_zero, ArrayType(FloatType()))(df['npe']))

df = df.withColumn("mean",array_mean("npe")) # df = df.withColumn("mean",array_mean("npe_calc").alias("avg"))
df = df.withColumn("std",array_std("npe"))
df = df.withColumn("var",array_var("npe"))
df = df.withColumn('mean_diff', F.udf(mean_subtraction, ArrayType(FloatType()))(df['npe'], df['mean']))
df = df.withColumn('z_score', F.udf(z_score_calc, ArrayType(FloatType()))(df['npe'], df['mean'], df['std']))
df = df.withColumn('m_m', F.udf(mean_subtraction, ArrayType(FloatType()))(df['z_score'], df['mean']))
df = df.withColumn("big_m",array_find_max("m_m"))
df = df.withColumn("little_m",array_find_min("m_m"))
df = df.withColumn("max_npe",array_find_max("npe"))
df = df.withColumn("activity",df.big_m-df.little_m)
df = df.withColumn("skewness",array_abs(df.big_m/df.little_m))
df = df.withColumn("max_claims_vector",array_find_max("claims_vector")) # maximum number of claim in a vector array_find_max
df = df.withColumn("filter_max_claims",F.when((df.max_claims_vector >= MIN_CLAIMS_THRESHOLD_INC),F.lit(1)).otherwise(F.lit(0)))
# display(df) # display(df.filter(col('phar_nabp_id') == '5926398'))


# COMMAND ----------

df_pd = df.toPandas() # Spark to Pandas
df_pd['claims_vector_ratio'] = df_pd['claims_vector'].map(array_ratio_claim_noclaim)
df_sp = spark.createDataFrame(df_pd) # Pandas to Spark
# display(df_sp)

# COMMAND ----------

# display(df_sp)

# COMMAND ----------

# Variables
target_adls_fs = adls_xformed_path
target_folder_path = "/lvl1/cons-ds/kgh2848"  # Do NOT include a trailing / here
save_file_name = '/increasing_normalized_trend_prod' # Save file name

# Write file join to disk
(df_sp
 .write
 .mode("overwrite")
 .option("header", "true")
 .format("parquet")
 .save(target_adls_fs + target_folder_path + save_file_name + VERSION_SAVE))

# COMMAND ----------


