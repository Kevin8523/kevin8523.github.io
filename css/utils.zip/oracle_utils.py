import csv
import random
import sys
import cx_Oracle as cxo
from getpass import getpass
# -----------------------------------------------------------------------------------------
# Basic Tools
# -----------------------------------------------------------------------------------------

# proportion should be a number from 0 to 1.
# each row has that percent chance of making it into the output
# running this multiple times may yield slightly differing numbers of
# rows in output!
def samplefile(inputpath, proportion, outputpath=None):
    if outputpath == None:
        outputpath = inputpath + ".sample.csv"
    with open(inputpath, newline='', mode='r') as inp:
        with open(outputpath, newline='', mode="w") as outp:
            header = inp.readline()
            outp.write(header)

            line = inp.readline()
            while line:
                if random.random() <= proportion:
                    outp.write(line)
                line = inp.readline()
    return

# this takes an array of paths to csv files
# and puts all the lines from each of them
# into the same file, except that the first line (the header line)
# only makes it in from the first file
# it's up to you to be sure all the files have the same number of columns
def concatcsvs(patharr, outputpath):
    first = patharr[0]
    rest = patharr[1:]
    outp = open(outputpath, newline='', mode="w")
    curfile = open(first, newline='', mode="r")
    line = curfile.readline()
    while line:
        outp.write(line)
        line = curfile.readline()
    curfile.close()

    for path in rest:
        curfile = open(path, newline='', mode="r")
        header = curfile.readline()
        line = curfile.readline()
        while line:
            outp.write(line)
            line = curfile.readline()
        curfile.close()

    outp.close()
    return

# if you have a list of lists or list of dicts
# this grabs a certain part of those things
# and puts them into a flat array
def indexgrabber(itembox, loc):
    return [item[loc] for item in itembox]

# takes a list of strings, and puts the 'quote' string
# around both sides of each string, and the 'delim' string
# between each token (but not at the end)
# returns the result as one big string
# this is useful for writing SQL queries that involve a lot of string literals
def stringquoter(tokenarr, quote="'", delim=", "):
    ret = ""
    for tok in tokenarr:
        ret = ret + quote + str(tok) + quote + delim
    choplen = len(delim)
    ret = ret[0:-1 * choplen]
    return ret


# -----------------------------------------------------------------------------------------
# Basic DB Actions & Functions
# -----------------------------------------------------------------------------------------

# call this to be prompted for your username and password
# you'll get a connection to oracle in return
def candevconnect():
    user = input("username: ")
    passw = getpass("password: ")
    dsn = cxo.makedsn("isbcan02.humana.com", "1526", "CANDEV")
    con = cxo.connect(user=user, password=passw, dsn=dsn)
    return con

def edwconnect():
    user = input("username: ")
    passw = getpass("password: ")
    dsn = cxo.makedsn("EDWPRO", "1521", service_name="EDW_FR_ANALYTICS")
    con = cxo.connect(user=user, password=passw, dsn=dsn)
    return con


# ignore this - it's for the next function
def makeDictFactory(cursor):
    columnNames = [d[0] for d in cursor.description]

    def createRow(*args):
        return dict(zip(columnNames, args))

    return createRow

# if you get a cursor from a connection object
# and you want the cursor to return results as dicts
# instead of lists. you can pass your cursor to this function.
# It'll alter the cursor's behavior.
# this does make getting results a tiny bit slower though
# WARNING: some of the functions in this file need cursors passed into them
# to do useful things like create tables. They don't care if the cursor they
# get returns lists or dicts.
# Some however, like exclusionarycolumnselector or rankcutter, get results back
# from queries. They need the cursor you give them to return lists.
def transformToDictCursor(cursor):
    cursor.rowfactory = makeDictFactory(cursor)
    return

# if you've executed a query, you can get the column names that
# are going to be in the results as an array of strings with this function
# this works for cursors that return dictionaries, or lists
def resultColumnNames(cursor):
    return [d[0] for d in cursor.description]

# instead of calling cursor.execute and having to
# worry about error, use this.
# takeaction is for things that don't return results
# like creating or dropping tables
def takeaction(cursor, action, doexit=True):
    try:
        res = cursor.execute(action)
    except Exception as ex:
        print("action error")
        print(action)
        print(ex)
        if doexit == True:
            sys.exit()

    return

# similar to takeaction, but this one returns results
# use it to execute things like select statements
def doquery(cursor, query, doexit=True):
    try:
        res = cursor.execute(query)
        res = cursor.fetchall()
        return res
    except Exception as ex:
        print("query error")
        print(query)
        print(ex)
        if doexit == True:
            sys.exit()
        return


# this grabs the username of whoever is logged in and doing
# queries using the connection object the cursor was made from (you)
def currentuser(cursor):
    q = """
    select sys_context('USERENV', 'SESSION_USER') FROM dual
    """
    tup = doquery(cursor, q)
    return tup[0][0]


# -----------------------------------------------------------------------------------------
# Reusable SQL patterns
# -----------------------------------------------------------------------------------------

# takes any subquery and counts the rows returned
def getcount(anyquery):
    res = """
        SELECT COUNT(*) FROM (
        
            """ + anyquery + """ 
        )
    """
    return res

# takes any list of tables or subqueries and (or mix of the two)
# and unions them. ORACLE DOES NOT UNION BASED ON COLUMN NAMES.
# you need to make sure the tables/subqueries in your list
# have the same number of columns, and that the columns are in the right order
# because oracle unions columns from left to right. It'll only error if the types don't match up.
# (i.e. you can't stack a column of integers onto a column of varchars)
def unioner(tablearr):
    unionstr = ""
    if len(tablearr) > 1:
        unionstr = "UNION"
    if len(tablearr) == 0:
        return ""
    res = tablearr[0] + " \n" + unionstr + " \n" + unioner(tablearr[1::])

    return res

# Oracle has meta tables available that contain info about existing tables.
# this query gets names of all the columns in the table. Here 'table' must be
# an actual table (a real candev table, or a temp table).
# this is most useful for getting temp table column lists. The owner of temp tables
# is the creator, so 'owner' defaults to the user's name.
# you could set owner to be 'CA_PROD' or something like that though.
# the gettypes option lets you get more info about what's actually in each column
def gettablecolumns(table, owner="sys_context('USERENV', 'SESSION_USER')", gettypes=False):

    typestr = ""
    if gettypes == True:
        typestr = ", DATA_TYPE, DATA_LENGTH "

    query = """
        SELECT column_name""" + typestr + """ 
        FROM   all_tab_cols
        WHERE  table_name = '""" + table + """'
        AND owner = '""" + owner + "'"

    return query

# this function is mostly useful for deduplicating query results.
# you need to write your own partition/order by clause.
# the 'top' result of the ordering is kept. so make sure you're sure
# on whether or not you want to order ascending or descending.
# example: you have a table/query containing pgk's and appointment dates
#   you, you have dupes because peopple have more than 1 appointment
#   you only want the row with the most recent appointment though
#   you could do 'partitionAndOrdering= "PARTITION BY MBR_PERS_GEN_KEY ORDER BY APPT_DATE DESC"
# note: this function adds a column to your results named 'TEMP_DEDUP_INDICATOR'
#   there's a better, but more involved, version of this function coming later
#   that immediately drops the temp column automaticall. This is surprisingly hard.
def rankEliminator(query, partitionAndOrdering, chosenrank="1",
                additionalwhereclauses="", tempcolname="TEMP_DEDUP_INDICATOR"):

    distinguishedrows = """
    SELECT *
    FROM (
        SELECT TABLE_ALIAS.*, ROW_NUMBER() over (""" + partitionAndOrdering + """) """ + tempcolname + """ 
        FROM ( """ + query + """ ) TABLE_ALIAS 
    )
    WHERE """ + tempcolname + """ = """ + chosenrank + """ 
    """ + additionalwhereclauses + """ 
    """

    return distinguishedrows

# If you have a fully valid query, you can feed this function
# a tablename, and the query string. It'll create a temp table with that name
# containing the columns and results from that query.
# This is useful for storing intermediate results for reuse.
def temptablefromquery(tablename, query, modifier=None):
    action = """
    CREATE GLOBAL TEMPORARY TABLE 
    """ + tablename + """
    ON COMMIT PRESERVE ROWS
    AS
    select * FROM ( 
    """ + query + """
    )
    """

    # setting modifier = 0 makes it so only column information is copied into this table.
    # seems silly but this can be useful for certain tasks
    if modifier == 0:
        action = action + """
        WHERE 1=0
        """

    # getting exactly 1 row in your table can also be nifty. both of these cases should
    # be a little rare though.
    if modifier == 1:
        action = action + """
        offset 0 rows fetch next row only
        """
    return action

# this function makes creating a temp table a little easier
# if you want to make one from scratch. you just need a list of (column_name, column_type) pairs
# example: temptablefromschema("STATES_ABREVS", [("STATE_NAME", "VARCHAR(30)" ), ("STATE_ABREV", "VARCHAR(2)")])
def temptablefromschema(tablename, coltuparr):
    schem = ""
    for pair in coltuparr:
        schem = schem + pair[0] + " " + pair[1] + ", \n"
    schem = schem[0:-3] # this chops off the last unnecessary comma

    action = """
    create global temporary table 
    """ + tablename + """(
        """ + schem + """
    ) 
    on commit preserve rows
    """

    return action

# this is just a string you can run as a query
# it'll get you a list of all the temp tables you've created
mytemptables = """
    select owner, table_name
    from all_tables
    where TEMPORARY = 'Y'
    AND OWNER = sys_context('USERENV', 'SESSION_USER')
"""

# -----------------------------------------------------------------------------------------
# Routines (these functions need a cursor passed into them)
# -----------------------------------------------------------------------------------------

# have a bunch of temp tables lying around? want to wipe the slate clean?
# just run this function. It'll get rid of ALL of them (INCLUDING ONES THAT HAVE DATA IN THEM)
def eraseallmytemptables(cursor):
    temps = doquery(cursor, mytemptables)

    for tup in temps:
        trunc = """
        truncate table """ + tup[0] + "." + tup[1] + """
        """
        takeaction(cursor, trunc)

        drop = """
        drop table """ + tup[0] + "." + tup[1] + """
        """
        takeaction(cursor, drop)

    return

# this function is a little more graceful than the previous function.
# it'll eat any errors that pop up that come from trying to erase a table
# that doesn't exist.
# it only tries to delete one table
# It's purpose is to ensure you're able to create a table when you want to.
# If you rerun a script that creates a table, and you try to create a table
# that already exists, you'll hit an error, so you can just call this before trying to create a table
# you can use this to delete any temporary tables or permanent tables you've created
def attemptTableErasure(cursor, tablename, owner=None):
    if owner == None:
        owner = currentuser(cursor)

    try:
        res = cursor.execute("truncate table " + owner + "." + tablename)
        res = cursor.execute("drop table " + owner + "." + tablename)
    except:
        pass

    return

# So, you have a query that has all the WHERE conditions you can think of, but still has too many rows
# give this function a tablename, a query, and a percentage (0 to 100 not 0 to 1. i.e. 22.5 -> 22.5%, .5 -> .5%, be aware!)
# this function 1. puts the results of that query into a temp table
#               2. gives every row a 'your chosen percent' chance of making it into the sample
#                      i.e. it rolls a 100 sided die for every row. If the roll is less than your percent, the row makes it in.
#               3. takes the 'winning' rows and puts them into a table with the name that you chose
# yes this is a lot of trouble, but the 'SAMPLE' clause in oracle has a lot of quirks. You can't
# really just use it as part of a subquery in a lot of cases, so it's better to do it this way so it works all the time
def createsamplefromquery(cursor, tablename, query, percentage):
    temptablename = tablename + "_TEMP"
    attemptTableErasure(cursor, tablename)
    attemptTableErasure(cursor, temptablename)

    takeaction(cursor, temptablefromquery(temptablename, query))

    sampler = """
        SELECT *
        FROM """ + temptablename + """
        SAMPLE (""" + str(percentage) + """)
    """

    takeaction(cursor, temptablefromquery(tablename, sampler))

    attemptTableErasure(cursor, temptablename)

    return

# this function only works on real tables, not queries.
# Proper SQL languages let you do a lot of things. For plenty of good reasons, you can
# select every column with * but there often isn't a way select 'every column but this one'
# or select 'every column except for the ones in this list'. This gets around that.
#
# you give it a table (it assumes you're the owner), and the columns you don't want as a list of strings.
# it'll look up the list of columns in that table, drop out the ones you don't want,
# and return a select statement on that table that selects every column except the ones you listed
# example: myquery = exclusionarycolumnselector(mycursor, "MY_TEMP_TABLE", ["UNWANTED_COL_1", "UNWANTED_COL_2"])
def exclusionarycolumnselector(cursor, table, exclusions, owner=None):

    if owner == None:
        owner = currentuser(cursor)

    getcols = gettablecolumns(table, owner=owner)
    cols = doquery(cursor, getcols)
    flatcols = indexgrabber(cols, 0)
    colset = set([x.upper() for x in flatcols])

    exclusions = set([x.upper() for x in exclusions])

    colset = list(colset - exclusions)

    columnstring = " " + stringquoter(colset, quote="") + " "

    accessor = """
    SELECT
    """ + columnstring + """ 
    FROM """ + owner + "." + table

    return accessor

# This is the smarter, but more complicated deduplicator
# you still feed it your own partition/order_by clause, and the query that you want to dedup
# but now you also give it an output table name
# it runs the query through rankEliminator, and puts the results into the output table
# then it uses exclusionarycolumnselector to give you a select statement that selects everything in
# the output table EXCEPT the column that got created as part of the deduplication process
# (you can give this function a list of other columns to leave out if you wish)
def rankcutter(cursor, query, newtable, partitionAndOrdering, extraexclusions=[]):
    attemptTableErasure(cursor, newtable)
    rankeliminated = rankEliminator(query, partitionAndOrdering)
    temptablemaker = temptablefromquery(newtable, rankeliminated)
    takeaction(cursor, temptablemaker)
    wantedcols = exclusionarycolumnselector( cursor, newtable, exclusions=["TEMP_DEDUP_INDICATOR"] + extraexclusions)
    return wantedcols

# This function takes a path to a CSV file, and a temp table schema (as a list of (columnname, columntype) pairs)
# and creates a temp table according to that schema, and uploads the csv contents to that temp table
# for now, csv columns must be in the same order as the schema.
# the schema column names are the ones that will be used. an example is in my article.
def csvtotemptable(cursor, filepath, tablename, schema, batchrows=-1):
    attemptTableErasure(cursor, tablename)

    lines = []
    with open(filepath, newline='') as csvfile:
        reader = csv.reader(csvfile)
        header = next(reader)
        for row in reader:
            lines.append(row)

    tablemaker = temptablefromschema(tablename, schema)
    takeaction(cursor, tablemaker)

    colnames = indexgrabber(schema, 0)
    colstring = ", ".join(colnames)

    value_locs = ", ".join(
        [":" + str(x) for x in list(range(1,
                                          len(colnames) + 1))])
    print("inserting values into new table " + tablename + "...")
    inserter = " INSERT INTO " + tablename + " (" + colstring + ") VALUES ( " + value_locs + " )"
    if batchrows <=0:
        cursor.executemany(inserter, lines)
    else:
        rows = len(lines)
        i = 0
        while i < rows:
            cursor.executemany(inserter, lines[i:i+batchrows])
            i += batchrows
    print("done inserting into temp table")
    return

# this function takes a query, and a filepath
# and saves the results of that query to the filepath as a CSV file.
def querytocsv(cursor, query, filepath, keepTypeInfo=False):
    dat = cursor.execute(query)
    dat = cursor.fetchall()

    colnames = indexgrabber(cursor.description, 0)

    coltypes = []
    for col in cursor.description:
        coltypes.append(col[1].__name__)

    schema = zip(colnames, coltypes)

    if keepTypeInfo == True:
        with open(filepath + ".schemainfo.txt", newline='', mode="w") as f:
            f.write("[\n")
            for pair in schema:
                f.write(str(pair) + "\n")
            f.write("]\n")

    with open(filepath, newline='', mode="w") as f:
        w = csv.writer(f)
        w.writerow(colnames)
        for row in dat:
            w.writerow(row)

    return

# -----------------------------------------------------------------------------------------
# PERMANENT TABLE RELATED STUFF (it gets its own category)
# -----------------------------------------------------------------------------------------

# This creates a permanent table from a query and a cursor
# It does not return a query, it creates the table for you.
# YOU SHOULD MAKE SURE TO RESPONSIBLY MANAGE THESE
# SAVE THE DATA TO A CSV OR SIMILAR LONG TERM
# JUST KEEP THEM UP WHILE ACTIVELY WORKING ON A PROJECT
# While these are convenient in that they don't die when your program closes, they can't 
# be quite regarded in the same way as tables in your PROJ library in SAS. 
# You shouldn't leave permanent tables that you create hanging around
# for longer than 4-7 days. There's a limited amount of space for 
# user-created permanent tables FOR EVERYONE IN TOTAL. Although that limit is pretty high,
# it could certainly be hit if people start leaving tables hanging around.
# If the limit gets hit, nobody is going to be able to do anything.

# Use them as bookmarks of sorts in ongoing projects so you don't have to constantly rerun ALL of 
# your SQL.

# you can use the attemptTableErasure function to delete specific permanent tables
# if data you want to save is in a temp table, just select * from it and use the querytocsv function.
def permatablefromquery(cursor, tablename, query):
    action = """
    CREATE TABLE 
    """ + tablename + """
    AS
    select * FROM ( 
    """ + query + """
    )
    """
    takeaction(cursor, action)
    return

# this is just a string you can run as a query
# it'll get you a list of all the permanent tables you've created
mypermatables = """
    select owner, table_name
    from all_tables
    where TEMPORARY = 'N'
    AND OWNER = sys_context('USERENV', 'SESSION_USER')
"""

# this will delete all of your permanent tables that you've created
def eraseallmypermatables(cursor):
    temps = doquery(cursor, mypermatables)

    for tup in temps:
        trunc = """
        truncate table """ + tup[0] + "." + tup[1] + """
        """
        takeaction(cursor, trunc)

        drop = """
        drop table """ + tup[0] + "." + tup[1] + """
        """
        takeaction(cursor, drop)

    return