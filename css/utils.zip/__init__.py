from hdputils.hdputils import *
import hdputils.oracle_utils as oracle_utils
