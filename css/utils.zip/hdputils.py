import sys
import pandas as pd
import io
import re
import os
import stat

# -----------------------------------------------------------------------------------------
# Basic Tools
# -----------------------------------------------------------------------------------------

# if you have a list of lists or list of dicts
# this grabs a certain part of those things
# and puts them into a flat array
def indexgrabber(itembox, loc):
    return [item[loc] for item in itembox]

def grant_smart_access():
    path = os.getcwd()
    if '/xfer/applications/projects' in path:
        for f in os.listdir() + ['.'] + [path]:
            try:
                os.chmod(f, stat.S_IRWXU | stat.S_IRWXO | stat.S_IRWXG)
                print(f'granted others access to {f}')
            except:
                print(f'{f} is not yours, someone else must grant access to it')
    else:
        print('this is a production folder, access not changed')
    return

# -----------------------------------------------------------------------------------------
# Basic DB Actions & Functions
# -----------------------------------------------------------------------------------------

def doquery(spark, action, doexit=False):
    try:
        res = spark.sql(action)
    except Exception as ex:
        print("action error")
        print("YOUR QUERY")
        print(action)
        print("ERROR MSG")
        print(str(ex).encode('latin-1').decode('unicode_escape'))
        if doexit == True:
            raise Exception('Query Error')
        return None
        

    return res

# this grabs the username of whoever is logged in (you)
def currentuser(spark):
    usr = spark._sc.sparkUser()
    return usr

# unpersists all spark dataframes that have been persisted
def unpersist_all_spark_dfs(spark):
    for (id, rdd) in spark._jsc.getPersistentRDDs().items():
        rdd.unpersist()
        print("Unpersisted {} rdd".format(id))
    return

# joins an array of dataframes on 1 key and returns a dataframe representing the join
# if there's only one df in the array, it is simply returned
# if there are none, an error is raised
def df_arr_joiner(df_arr, key, join_type = 'left'):
    if len(df_arr) == 0:
        raise("no DF objects in array")

    if len(df_arr) == 1:
        return df_arr[0]
    else:
        df_collector = df_arr[0]
        for df in df_arr[1:]:
            df_collector = df_collector.join(df, key, join_type)

    return df_collector


# -----------------------------------------------------------------------------------------
# Reusable SQL patterns
# -----------------------------------------------------------------------------------------

# takes any subquery and counts the rows returned
def getcount(anyquery):
    res = f"""
        SELECT COUNT(*) FROM (
            {anyquery} 
        ) countedTable
    """
    return res

def gettablecolumns(spark, table, keep_types=False):
    if '.' not in table:
        print("SCHEMA NOT PROVIDED")
        raise("ERROR: when creating table must provide 'schema.table'")
    
    query = f"describe {table}"
    df = doquery(spark, query)
    pf = df.toPandas()

    ret = [x for x in pf['col_name']]

    if keep_types == True:
        ret = list(zip(ret, [x for x in pf['data_type']]))

    return ret

# this function is mostly useful for deduplicating query results.
# you need to write your own partition/order by clause.
# the 'top' result of the ordering is kept. so make sure you're sure
# on whether or not you want to order ascending or descending.

def rankEliminator(query, partitionAndOrdering, chosenrank="1",
                additionalwhereclauses="", tempcolname="TEMP_DEDUP_INDICATOR"):

    distinguishedrows = f"""
    SELECT *
    FROM (
        SELECT rankElimTable.*, ROW_NUMBER() over ({partitionAndOrdering}) {tempcolname} 
        FROM ( {query} ) rankElimTable 
    ) outer_tbl
    WHERE {tempcolname} = {chosenrank} 
    {additionalwhereclauses} 
    """

    return distinguishedrows, tempcolname

def test():
    print("hi")
    return

def getsample(table, numrows):

    query = f"""
        select * from ({table}) tmp
        distribute by rand()
        sort by rand()
        limit {numrows}"""
    
    return query

def yrmth_col_to_date(col, newcol, day_of_month=1):
    q_str = f"to_date( concat(substr({col}, 0, 4), '-', substr({col}, 5), '-', {day_of_month} ) ) {newcol}"
    return q_str

# -----------------------------------------------------------------------------------------
# Routines (these functions need a spark object)
# -----------------------------------------------------------------------------------------
# If you have a fully valid query, you can feed this function
# a tablename, and the query string. It'll create a temp table with that name
# containing the columns and results from that query.
# This is useful for storing intermediate results for reuse.
def tablefromquery(spark, tablename, query, modifier=None):
    if '.' not in tablename:
        print("SCHEMA NOT PROVIDED FOR CREATION")
        raise("ERROR: when creating table must provide 'schema.table'")

    action = f"""
    CREATE TABLE 
    {tablename}
    STORED AS PARQUET
    AS
    select * FROM ( 
    {query}
    ) createdTable 
    """

    # setting modifier = 0 makes it so only column information is copied into this table.
    # seems silly but this can be useful for certain tasks
    if modifier == 0:
        action = action + "\nWHERE 1=0"

    # getting exactly 1 row in your table can also be nifty. both of these cases should
    # be a little rare though.
    if modifier == 1:
        action = action + "\nlimit 1"
    return doquery(spark, action)

# this function is a little more graceful than the previous function.
# it'll eat any errors that pop up that come from trying to erase a table
# that doesn't exist.
# it only tries to delete one table
# It's purpose is to ensure you're able to create a table when you want to.
# If you rerun a script that creates a table, and you try to create a table
# that already exists, you'll hit an error, so you can just call this before trying to create a table
# you can use this to delete any temporary tables or permanent tables you've created
def attemptTableErasure(spark, tablename):
    if '.' not in tablename:
        print("SCHEMA NOT PROVIDED FOR DELETION")
        raise("ERROR: when erasing table must provide 'schema.table'")

    try:
        res = spark.sql(f"truncate table {tablename}").head()
        res = spark.sql(f"drop table {tablename}").head()
    except Exception as ex:
        print(ex)
        pass

    return

# this deduplicator deduplicates according to your partition and ordering 
# and creates a temp view to put the results in that you specify 
def rankcutter(spark, query, tempviewname, partitionAndOrdering, extraexclusions=[]):

    elimquery, tempcol = rankEliminator(query, partitionAndOrdering)
    df = doquery(spark, elimquery)
    
    cols = df.columns
    exclusions=[tempcol] + extraexclusions
    keptcols = [col for col in cols if col not in exclusions]

    downselected = df.select(keptcols)
    downselected.createOrReplaceTempView(tempviewname)
    print(f'created {tempviewname}')
    return

def call_down_sparkdf_to_pandas(df):
    tcols = [col for col in df.columns if 'date' in col or 'time' in col]
    return pd.read_csv(io.StringIO(df.toPandas().to_csv(None, index_label='idx' )), parse_dates=tcols)
