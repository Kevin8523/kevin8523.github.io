from sklearn import metrics

def gains_tables(ml_clf, X_train_dataset, y_train_target, X_test_dataset, y_test_target, n_groups):
    
    ### Fit model, get probabilities and ranks based on training data ###
    
    # Use ML classifier
    clf = ml_clf.fit(X_train_dataset, y_train_target)
    #clf = ml_clf
    
    # Get probability of predictions
    y_pred_proba = clf.predict_proba(X_train_dataset)
        
    # Make a copy of DataFrame so inplace operations don't overwrite things
    y_actual = y_train_target.copy()
    y_actual = pd.DataFrame(y_actual)
    
    y_hat = pd.DataFrame(y_pred_proba, columns=['Score_0', 'Score_1'])
    y_hat = y_hat.drop(columns=['Score_0'], axis=1)
    
    # Reset index so it is possible to merge with the train DataFrame copy
    # then merge with DataFrame copy and rename columns
    y_actual.reset_index(inplace=True)
    y_hat = pd.concat([y_hat, y_actual], axis=1)
    y_hat.columns = ['Score_1','index','target']
    y_hat = y_hat[['index','target','Score_1']]
    
    # Get predictions
    ones_true = y_hat[(y_hat['target'] == 1)][['Score_1']].count()
    zeroes_true = y_hat[(y_hat['target'] == 0)][['Score_1']].count()

    level_ratio = ones_true / (ones_true + zeroes_true)
    #level_ratio = 0.5

    y_hat['cutpoint'] = float(level_ratio)

    y_hat.loc[y_hat.Score_1 >= y_hat.cutpoint, 'pred_target'] = 1
    y_hat.loc[y_hat.Score_1 < y_hat.cutpoint, 'pred_target'] = 0

    y_hat['pred_target'] = y_hat['pred_target'].astype(np.int)
    
    # Label groups
    
    if n_groups == 4:
        groups_label = 'quartiles'
    elif n_groups == 5:
        groups_label = 'quintiles'
    elif n_groups == 10:
        groups_label = 'deciles'
    elif n_groups == 20:
        groups_label = 'twentiles'
    elif n_groups == 100:
        groups_label = 'percentiles'
    else:
        groups_label = f'ranks_{n_groups}'
  
    # Calculate deciles for predictions
    y_hat[groups_label] = pd.qcut(y_hat['Score_1'], n_groups, labels=np.arange(n_groups, 0, -1), duplicates='drop')

    # Calculate mean, min, max, n by decile and append to y_hat DataFrame
    y_hat_mean = y_hat.groupby(by=groups_label,axis=0, as_index=False)[['Score_1']].mean()
    y_hat_mean.columns = [groups_label,'avg']

    y_hat_min = y_hat.groupby(by=groups_label,axis=0, as_index=False)[['Score_1']].min()
    y_hat_min.columns = [groups_label,'min']

    y_hat_max = y_hat.groupby(by=groups_label,axis=0, as_index=False)[['Score_1']].max()
    y_hat_max.columns = [groups_label,'max']

    y_hat_n = y_hat.groupby(by=groups_label,axis=0, as_index=False)[['Score_1']].count()
    y_hat_n.columns = [groups_label,'n']

    y_hat_act = y_hat.groupby(by=groups_label, axis=0, as_index=False)[['target']].sum()
    y_hat_act.columns = [groups_label,'target'] 

    y_hat_pred = y_hat.groupby(by=groups_label, axis=0, as_index=False)[['pred_target']].sum()
    y_hat_pred.columns = [groups_label,'binary_pred_target'] 
    
    y_hat_spred = y_hat.groupby(by=groups_label, axis=0, as_index=False)[['Score_1']].sum().round()
    y_hat_spred.columns = [groups_label, 'sum_pred_target']
    y_hat_spred['sum_pred_target'] = y_hat_spred['sum_pred_target'].astype(np.int)

    y_hat_summary = pd.merge(y_hat_mean, y_hat_min, how='left', on=[groups_label])
    y_hat_summary = pd.merge(y_hat_summary, y_hat_max, how='left', on=[groups_label])
    y_hat_summary = pd.merge(y_hat_summary, y_hat_n, how='left', on=[groups_label])
    y_hat_summary = pd.merge(y_hat_summary, y_hat_act, how='left', on=[groups_label])
    #y_hat_summary = pd.merge(y_hat_summary, y_hat_pred, how='left', on=[groups_label])
    y_hat_summary = pd.merge(y_hat_summary, y_hat_spred, how='left', on=[groups_label])

    y_hat_summary['act_perf'] = (y_hat_summary['target']/y_hat_summary['n'])
    y_hat_summary['lift'] = (y_hat_summary['act_perf']/float(level_ratio))
    #y_hat_summary['binary_pred_perf'] = y_hat_summary['binary_pred_target']/y_hat_summary['n']
    #y_hat_summary['sum_pred_perf'] = y_hat_summary['sum_pred_target']/y_hat_summary['n']
    
    
    # Training final gains table    
    gains_table_train_summary = y_hat_summary.set_index(groups_label)
        
    ### Create test gains table ###
    
    y_test_pred_proba = clf.predict_proba(X_test_dataset)
    
    y_actual_test = y_test_target.copy()
    y_actual_test = pd.DataFrame(y_actual_test)
    
    y_hat_test = pd.DataFrame(y_test_pred_proba, columns=['Score_0','Score_1'])
    y_hat_test = y_hat_test.drop(columns=['Score_0'], axis=1)
    
    y_actual_test.reset_index(inplace=True)
    
    y_hat_test = pd.concat([y_hat_test, y_actual_test], axis=1)
    
    y_hat_test.columns = ['Score_1','index','target']
    y_hat_test = y_hat_test[['index','target','Score_1']]
    
    y_hat_test['cutpoint'] = float(level_ratio)
    
    y_hat_test.loc[y_hat_test.Score_1 >= y_hat_test.cutpoint, 'pred_target'] = 1
    y_hat_test.loc[y_hat_test.Score_1 < y_hat_test.cutpoint, 'pred_target'] = 0
    
    y_hat_test['pred_target'] = y_hat_test['pred_target'].astype(np.int)

    ### Calculate ranks for test dataset ###
    new_decile_list = []
    y_hat_test_list = y_hat_test['Score_1'].tolist()
        
    ### Define decile_coder function ###
    def decile_coder(i, groups_label):
    
        y_hat_rank_list = y_hat_summary[groups_label].tolist()
        y_hat_min_val_list = y_hat_summary['min'].tolist()
        y_hat_test_list = y_hat_test['Score_1'].tolist()
        lookup_list = list(zip(y_hat_min_val_list, y_hat_rank_list))
    
        # Append score to list
        lookup_list.append((y_hat_test_list[i], -1))
        lookup_list.sort()
        
        # Get 2nd element of tuple
        decile_element = [x[1] for x in lookup_list]
        
        # Find -1 element and subtract from length of list
        new_decile = len(y_hat_rank_list)-decile_element.index(-1)+1
        
        new_decile_list.append(new_decile)
        del lookup_list
        
        return new_decile_list

    for i in range(0,len(y_hat_test_list)):
        decile_coder(i, groups_label)
    
    y_hat_test[groups_label] = new_decile_list
    
    # Summarize test gains table
    
    y_hat_test_mean = y_hat_test.groupby(by=groups_label,axis=0, as_index=False)[['Score_1']].mean()
    y_hat_test_mean.columns = [groups_label,'avg']

    y_hat_test_min = y_hat_test.groupby(by=groups_label,axis=0, as_index=False)[['Score_1']].min()
    y_hat_test_min.columns = [groups_label,'min']

    y_hat_test_max = y_hat_test.groupby(by=groups_label,axis=0, as_index=False)[['Score_1']].max()
    y_hat_test_max.columns = [groups_label,'max']

    y_hat_test_n = y_hat_test.groupby(by=groups_label,axis=0, as_index=False)[['Score_1']].count()
    y_hat_test_n.columns = [groups_label,'n']

    y_hat_test_act = y_hat_test.groupby(by=groups_label, axis=0, as_index=False)[['target']].sum()
    y_hat_test_act.columns = [groups_label,'target'] 

    y_hat_test_pred = y_hat_test.groupby(by=groups_label, axis=0, as_index=False)[['pred_target']].sum()
    y_hat_test_pred.columns = [groups_label,'binary_pred_target'] 
    
    y_hat_test_spred = y_hat_test.groupby(by=groups_label, axis=0, as_index=False)[['Score_1']].sum().round()
    y_hat_test_spred.columns = [groups_label, 'sum_pred_target']
    y_hat_test_spred['sum_pred_target'] = y_hat_test_spred['sum_pred_target'].astype(np.int)

    y_hat_test_summary = pd.merge(y_hat_test_mean, y_hat_test_min, how='left', on=[groups_label])
    y_hat_test_summary = pd.merge(y_hat_test_summary, y_hat_test_max, how='left', on=[groups_label])
    y_hat_test_summary = pd.merge(y_hat_test_summary, y_hat_test_n, how='left', on=[groups_label])
    y_hat_test_summary = pd.merge(y_hat_test_summary, y_hat_test_act, how='left', on=[groups_label])
    #y_hat_test_summary = pd.merge(y_hat_test_summary, y_hat_test_pred, how='left', on=[groups_label])
    y_hat_test_summary = pd.merge(y_hat_test_summary, y_hat_test_spred, how='left', on=[groups_label])

    y_hat_test_summary['act_perf'] = y_hat_test_summary['target']/y_hat_test_summary['n']
    y_hat_test_summary['lift'] = y_hat_test_summary['act_perf']/float(level_ratio)
    #y_hat_test_summary['binary_pred_perf'] = y_hat_test_summary['binary_pred_target']/y_hat_test_summary['n']
    #y_hat_test_summary['sum_pred_perf'] = y_hat_test_summary['sum_pred_target']/y_hat_test_summary['n']
    
    
    # Test final gains table
    gains_table_test_summary = y_hat_test_summary.set_index(groups_label)
    gains_table_test_summary = gains_table_test_summary.sort_index(ascending=False)
        
    ### Add Confusion Matrix metrics ###
    
    train_score = y_hat
    test_score = y_hat_test
    
    cm_train_actual = train_score['target'].tolist()
    cm_train_pred = train_score['pred_target'].tolist()
    cm_test_actual = test_score['target'].tolist()
    cm_test_pred = test_score['pred_target'].tolist()

    train_accuracy = metrics.accuracy_score(cm_train_actual, cm_train_pred)
    train_precision = metrics.precision_score(cm_train_actual, cm_train_pred)
    train_recall = metrics.recall_score(cm_train_actual, cm_train_pred)
    train_roc = metrics.roc_auc_score(cm_train_actual, cm_train_pred)
    train_f1 = f1_score(cm_train_actual, cm_train_pred)

    test_accuracy = metrics.accuracy_score(cm_test_actual, cm_test_pred)
    test_precision = metrics.precision_score(cm_test_actual, cm_test_pred)
    test_recall = metrics.recall_score(cm_test_actual, cm_test_pred)
    test_roc = metrics.roc_auc_score(cm_test_actual, cm_test_pred)
    test_f1 = f1_score(cm_test_actual, cm_test_pred)


    cm_list_names = ['Accuracy','Precision','Recall','ROC','F1']
    cm_train_list = [train_accuracy, train_precision, train_recall, train_roc, train_f1]
    cm_test_list = [test_accuracy, test_precision, test_recall, test_roc, test_f1]

    cm_df = pd.DataFrame(cm_list_names)
    cm_df.columns = ['metrics']
    cm_df['train_score'] = cm_train_list
    cm_df['test_score'] = cm_test_list
    cm = cm_df
        
    return gains_table_train_summary, gains_table_test_summary, y_hat, y_hat_test, cm