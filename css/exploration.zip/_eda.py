#  PTO TnL3 Unengaged Members

**Objective**: 

Explore Dataset to see if we can understand the member profile to create a hypothesis. This dataset is focused on the unengaged members primarily the Skeptical Control Seekers. 

_Start at a high level and drill down into more details_
- Population
- Additonal Breakdown
- Compare with full population
- Compare with self of other population
- Compare with support seeking partipators and health service maximizers

import pyodbc
import pandas as pd

connection = pyodbc.connect(dsn="dev_hdp", autocommit=True)

query_string = "SELECT * FROM CLMS.MTH_RXCLM LIMIT 2"

test = pd.read_sql_query(query_string, connection)
test.head()

#### Environment

import sys
print(sys.executable)
print(sys.version)

# Import Libraries
import pandas as pd
import numpy as np
import cx_Oracle as cxo
# import sqlalchemy as sqla
import datautils
import matplotlib.pyplot as plt
import seaborn as sns
import warnings
warnings.filterwarnings("ignore")
%matplotlib inline

## Table of Content<a id='0'></a>
#### Demographics, Geographics, Behavioral
- <a href='#1'>1 - Data Prep</a> 
    * <a href='#1.1'>1.1 - Unengaged Skeptical Control Seekers</a>
    * <a href='#1.2'>1.2 - All members excluding Skeptical Control Seekers</a>
- <a href='#2'>2 - Demographics</a>
    * <a href='#2.1'>2.1 - Unengaged Skeptical Control Seekers </a>
    * <a href='#2.2'>2.2 - Comparison of SCS with All Members</a>
<!---    * <a href='#2.3'>2.3 - Additional Breakdown (WIP)</a> -->
<!---    * <a href='#2.4'>2.4 - Comparison with Support Seeking Participator & Health Service Maximizers (WIP)</a> -->
- <a href='#3'>3 - Geographics</a>
    * <a href='#3.1'>3.1 - Unengaged Skeptical Control Seekers </a>
    * <a href='#3.2'>3.2 - Comparison of Skeptical Control Seekers with All Members</a>
<!---    * <a href='#3.3'>3.3 - Additional Breakdown (WIP)</a> -->
<!---    * <a href='#3.4'>3.4 - Comparison with Support Seeking Participator & Health (WIP)</a> -->
- <a href='#4'>4 - Behaviorial</a>
<!---
    * <a href='#4.1'>2.1 - Unengaged Skeptical Control Seekers </a>
    * <a href='#4.2'>2.2 - Comparison of SCS with All Members</a>
    * <a href='#4.3'>2.3 - Additional Breakdown (WIP)</a>
    * <a href='#4.4'>2.4 - Comparison with Support Seeking Participator & Health 
-->

#### Digital
- <a href='#5'>5 - Digital: Unengaged Skeptical Control Seekers</a>
    * <a href='#5.0'>5.0 - Data Prep</a>
    * <a href='#5.1'>5.1 - Web Sessions </a>
    * <a href='#5.2'>5.2 - OS & Mobile</a>
    * <a href='#5.3'>5.3 - Country</a>
    * <a href='#5.4'>5.4 - State</a>
    * <a href='#5.5'>5.5 - Category</a>
    * <a href='#5.6'>5.6 - Topic</a>

#### Pharmacy
- <a href='#6'>6 - Pharmacy: Unengaged Skeptical Control Seekers</a>
    * <a href='#6.0'>6.0 - Data Prep</a>
    * <a href='#6.1'>6.1 - Pharmacy Of Choice </a>

**Ideas & Things to look into**
* ~~Dedupe / Clean & Summary Stats~~ 
* ~~Summarize: # Females, # in TX, Etc~~
    * ~~Look at the Dec: Demographics, Digital Data, Behavior~~
    * Look at has disease does not have disease
    * Feature Engineering to breakout
* Read off hypo questions and find if data supports or negates it
* Do the same and compare with general population
* Look by both MAPD and PDP
* Look at the PowerPoint for more references
* Feature engineering: New members vs old members: TENURE

## <a id='1'>Data Preparation</a>
<a href='#0'>Back to top</a>

**Overview**

Dataset of the unengaged members & the all members, to understand and compare the unengaged members to the rest of the members

**Datasets**:
1. CON_DSH_PTOTRADMAIL_UPD1.csv: This dataset is the **unengaged mail order members**, in particular the skeptical control seekers. Dataset has some duplicated MBR_PERS_GEN_KEY that I will dedupe before analyzing.
    * Using a subset of the columns for the dataset
    * Removed duplicates
    * Only using MAPD
2. CON_DSH_2018Q3YTD_UPD1.txt: This dataset is **all of the members regardless of segment or mail/no-mail** but the dataset was filtered in Oracle with the following prior to reading file in this analysis:
    * Filters to only MAPD
    * Removes the mail order skeptical control seekers: IND_UNENG_TRADMAIL <> 1
    * Dropping all nan for MABH_SEG_GRP
    
**Need to Confirm**:
1. CON_DSH_2018Q3YTD_UPD1.txt ==> IND_UNENG_TRADMAIL <> 1 means they are NOT in the other file. It looks like even when I add this filter, there are skeptical control seekers within the population. 
2. CON_DSH_2018Q3YTD_UPD1.txt: Completely unengaged with Humana Pharmacy and also do not fill RXs there (in general).Descriptive statistics showed on average they had 0.1 fills through Humana Pharmacy in the first three quarters of 2018, so they may be in-store shoppers


#### Unengaged Skeptical Control Seekers<a id='1.1'></a>

**Read in Flatfiles: CON_DSH_PTOTRADMAIL_UPD1.csv**

# Data path
path = ''
filename = 'CON_DSH_PTOTRADMAIL_UPD1.csv'
filepath = f'{path}{filename}'
print(filepath)

# Read in list of columns
column_selection = ['MBR_PERS_GEN_KEY',
'LOB',
'LOB2',
'TOTAL_TENURE_MTHS',
'CNT_RX_CLM',
'CNT_HUM_PHARMACY',
'CNT_GENERIC_RX_CLM', 
'CNT_MAINT_DRUG_CLM',
'IND_RX_CLM',
'IND_GENERIC_RX_CLM',
'IND_MAINT_DRUG_CLM',
'IND_HUM_PHARMACY',
'EGBH_SEGMENT',
'EGBH_SEG_GRP',
'MABH_SEGMENT',
'MABH_SEG_GRP',
'NET_WORTH',
'EST_INCOME',
'NBR_PERSON_HH',
'EDUCATION_LEVEL',
'HHCOMP', 
'ETHNICITY',
'DIVISION', 
'REGION', 
'AGE', 
'SEX_CD', 
'BOLD_MOVE_MARKET', 
'STATE_CD', 
'ZIP_CD', 
'CNTY_CD', 
'IND_ENGAGEMENT', 
'MARITAL_STAT_CD', 
'LANG_SPOKEN_CD',
'IND_MAPD', 
'IND_PDP', 
'PROV_ORG_NAME',
'RX_RISK_SCORE',
'MA_RISK_SCORE', 
'DE_RISK_SCORE', 
'CNT_INQ', 
'CNT_CALLS',
'IND_INQ', 
'IND_CALL',
'IND_MAPD',
'IND_UNENG_TRADMAIL']

# Subset of Data
# pto_tradmail = pd.read_csv(filepath, header=0, usecols=column_selection)
pto_tradmail = pd.read_csv(filepath, header=0) # All Data

#### Quick look on the data

# Shape of the data
print('\033[1m'+'DATASET','(ROWS, COLUMNS)'+'\033[0m')
print('dataset',pto_tradmail.shape)

# df.head(), df.tail(),df.info(),df.describe()
pto_tradmail.head()

# Counts the number of occurences for a Column
# Sort by index: sort_index()
# df.groupby('MBR_PERS_GEN_KEY').size().sort_values('LOB')
pto_tradmail.MBR_PERS_GEN_KEY.value_counts().head(10)

# Print out Unique Values for Each Column
for col in range(0,len(pto_tradmail.columns)): # len(df.columns)
    if (col in []): # Add here to skip over these columns
        continue
    print(col,end=")")
    print('\033[1m'+ pto_tradmail.columns[col] +'\033[0m',end=":")
    print(pto_tradmail.iloc[:,col].dtype)
    print(pto_tradmail.iloc[:,col].unique(), '\n')

#### Dedupe / Minor Cleaning of the data

- Number of records after cleaning: 419265
- Only want MAPD members:IND_MAPD == 1
- Only want skeptical control seekers: MABH_SEG_GRP == 'SKPT_CTRL_SEKR'
- Remove duplicates

pto_clean = pto_tradmail[pto_tradmail.IND_MAPD == 1]
pto_clean.IND_MAPD.value_counts()

pto_clean = pto_clean[(pto_clean.MABH_SEG_GRP == 'SKPT_CTRL_SEKR')]
pto_clean.MABH_SEG_GRP.value_counts()

pto_clean = pto_clean.drop_duplicates('MBR_PERS_GEN_KEY', keep = 'first')
pto_clean.IND_MAPD.value_counts()

df = pto_clean

#### Quick look on cleaned data

for col in range(0,len(pto_clean.columns)): # len(df.columns)
    if (col in []): # Add here to skip over these columns
        continue
    print(col,end=")")
    print('\033[1m'+ pto_clean.columns[col] +'\033[0m',end=":")
    print(pto_clean.iloc[:,col].dtype)
    print(pto_clean.iloc[:,col].unique(), '\n')





#### All members excluding Skeptical Control Seekers <a id='1.2'></a>

**Read in Flatfiles: con_dsh_2018_all_data_pull.txt**

# Data path
path = ''
filename = 'CON_DSH_2018Q3YTD_UPD1.txt'
filepath = f'{path}{filename}'
print(filepath)

# Read in list of columns
column_selection = ['MBR_PERS_GEN_KEY',
'LOB',
'LOB2',
'TOTAL_TENURE_MTHS',
'CNT_RX_CLM',
'CNT_HUM_PHARMACY',
'CNT_GENERIC_RX_CLM', 
'CNT_MAINT_DRUG_CLM',
'IND_RX_CLM',
'IND_GENERIC_RX_CLM',
'IND_MAINT_DRUG_CLM',
'IND_HUM_PHARMACY',
'EGBH_SEGMENT',
'EGBH_SEG_GRP',
'MABH_SEGMENT',
'MABH_SEG_GRP',
'NET_WORTH',
'EST_INCOME',
'NBR_PERSON_HH',
'EDUCATION_LEVEL',
'HHCOMP', 
'ETHNICITY',
'DIVISION', 
'REGION', 
'AGE', 
'SEX_CD', 
'BOLD_MOVE_MARKET', 
'STATE_CD', 
'ZIP_CD', 
'CNTY_CD', 
'IND_ENGAGEMENT', 
'MARITAL_STAT_CD', 
'LANG_SPOKEN_CD',
'IND_MAPD', 
'IND_PDP', 
'PROV_ORG_NAME',
'RX_RISK_SCORE',
'MA_RISK_SCORE', 
'DE_RISK_SCORE', 
'CNT_INQ', 
'CNT_CALLS',
'IND_INQ', 
'IND_CALL',
'IND_MAPD',
'IND_UNENG_TRADMAIL']

dsh_all = pd.read_csv(filepath, sep=';', header=0, usecols=column_selection)

#### Quick look on the data

# Shape of the data
print('\033[1m'+'DATASET','(ROWS, COLUMNS)'+'\033[0m')
print('dataset',dsh_all.shape)

# df.head(), df.tail(),df.info(),df.describe()
dsh_all.tail()

# Counts the number of occurences for a Column
dsh_all.MBR_PERS_GEN_KEY.value_counts().head(10)

# Print out Unique Values for Each Column
for col in range(0,len(dsh_all.columns)): # len(df.columns)
    if (col in []): # Add here to skip over these columns
        continue
    print(col,end=")")
    print('\033[1m'+ dsh_all.columns[col] +'\033[0m',end=":")
    print(dsh_all.iloc[:,col].dtype)
    print(dsh_all.iloc[:,col].unique(), '\n')

#### Dedupe / Minor Cleaning of the data

- Number of records after cleaning: 2557211
- Only want MAPD members:IND_MAPD == 1
- Remove skeptical control seekers: MABH_SEG_GRP != 'SKPT_CTRL_SEKR'
- Dropping nan: MABH_SEG_GRP != 'SKPT_CTRL_SEKR'
- Remove duplicates

# Should already be all MAPD but just to be sure
dsh_all_clean = dsh_all[dsh_all.IND_MAPD == 1]
dsh_all_clean.IND_MAPD.value_counts()

dsh_all_clean = dsh_all_clean[(dsh_all_clean.MABH_SEG_GRP != 'SKPT_CTRL_SEKR')]
dsh_all_clean.MABH_SEG_GRP.value_counts()

dsh_all_clean = dsh_all_clean.dropna(subset=['MABH_SEG_GRP'])
dsh_all_clean.IND_MAPD.value_counts()

dsh_all_clean = dsh_all_clean.drop_duplicates('MBR_PERS_GEN_KEY', keep = 'first')
dsh_all_clean.IND_MAPD.value_counts()

df_all = dsh_all_clean

#### Quick look on cleaned data

for col in range(0,len(dsh_all_clean.columns)): # len(df.columns)
    if (col in []): # Add here to skip over these columns
        continue
    print(col,end=")")
    print('\033[1m'+ dsh_all_clean.columns[col] +'\033[0m',end=":")
    print(dsh_all_clean.iloc[:,col].dtype)
    print(dsh_all_clean.iloc[:,col].unique(), '\n')

# Correlation matrix 
corrmat = df.corr()
f, ax = plt.subplots(figsize=(12, 9))
sns.heatmap(corrmat, square=True)







## <a id='2'>Demographics</a>
<a href='#0'>Back to top</a>

<a id='2.1'></a>**Unengaged Members**

# Set environment for ease of use
df = pto_clean
sns.set_style('whitegrid') # Set Seaborn Styles
#sns.countplot(y=df.SEX_CD, order = ['M','F'])
# sns.barplot(x=df.SEX_CD.value_counts().index, y=df.SEX_CD.value_counts())
# TOTAL_TENURE_MTHS, CNT_RX_CLM, CNT_HUM_PHARMACY, 
# CNT_GENERIC_RX_CLM, CNT_MAINT_DRUG_CLM
# NET_WORTH, EST_INCOME, NBR_PERSON_HH, AGE

# Count of MAPD Skeptical Control Seekers
# 389559
df.loc[:,'MABH_SEG_GRP'].value_counts()

# GENDER
# df['SEX_CD'].value_counts(normalize=True) * 100
# g = df.loc[:,'SEX_CD'].value_counts()
# g_p = df.SEX_CD.value_counts()/df.SEX_CD.count()*100
# gender = pd.concat([g,g_p],axis=1).set_axis(['count','pct'], axis=1, inplace = False)
# Gender Table
gender = df.loc[:,'SEX_CD'].value_counts().to_frame('count')
gender['pct'] = df.SEX_CD.value_counts()/df.SEX_CD.count()*100
print(gender)

# Gender Plot
g = sns.catplot(y='SEX_CD', data=df, order=['F','M'], 
            kind='count', alpha=0.7, height = 3, aspect = 2)
g.fig.suptitle('Gender Breakdown') 

# AGE
# Age Table
age = pd.DataFrame(columns = ['count'])
age.loc['65+'] = df[df.AGE>64].AGE.count()
age.loc['< 65'] = df[df.AGE<65].AGE.count()
apct = (age.iloc[0:1,0].values / age.iloc[0:2,0].values.sum())*100
apct2 = (age.iloc[1:2,0].values / age.iloc[0:2,0].values.sum())*100
age['pct'] = np.concatenate([apct,apct2])
print(age)

# Age Plot
g = sns.catplot(y=age.index, x='count', data=age, 
                kind='bar', alpha=0.7, height = 3, aspect = 2)
g.fig.suptitle('Age Breakdown') 

# Histogram of age
sns.distplot(df.AGE)

# ETHNICITY
# Ethnicity Tables
ethnicity = df.loc[:,'ETHNICITY'].value_counts().to_frame('count')
ethnicity['pct'] = df.loc[:,'ETHNICITY'].value_counts() / df.loc[:,'ETHNICITY'].count()*100
print(ethnicity)
# Ethnicity Plots
g = sns.catplot(y='ETHNICITY', data=df, 
            kind='count', alpha=0.7, height = 3, aspect = 2)
g.fig.suptitle('Ethnicity Breakdown') 

# EDUCATION
# Education Tables
education = df.EDUCATION_LEVEL.value_counts().to_frame('count')
education['pct'] = df.EDUCATION_LEVEL.value_counts() / df.EDUCATION_LEVEL.count()*100
print(education)
# Education Plots
g = sns.catplot(y='EDUCATION_LEVEL', data=df, order = df.EDUCATION_LEVEL.value_counts().index,
            kind='count', alpha=0.7, height = 3, aspect = 2)
g.fig.suptitle('Education Breakdown') 

# INCOME
# Income Tables
income = df.EST_INCOME.value_counts().to_frame('count')
income['pct'] = df.EST_INCOME.value_counts() / df.EST_INCOME.count()*100
print(income.sort_index(ascending=True))
# Income Plots
g = sns.catplot(x='EST_INCOME', data=df, 
                order = df.EST_INCOME.value_counts().sort_index(ascending = True).index,
                kind='count', alpha=0.7, height = 3, aspect = 3.5)
g.fig.suptitle('Income Breakdown') 

# FAMILY STATUS
# Education Tables
family = df.HHCOMP.value_counts().to_frame('count')
family['pct'] = df.HHCOMP.value_counts() / df.HHCOMP.count()*100
print(family)
# Education Plots
g = sns.catplot(y='HHCOMP', data=df, order = df.HHCOMP.value_counts().index,
            kind='count', alpha=0.7, height = 3, aspect = 2)
g.fig.suptitle('Family Breakdown') 

# TENURE
# Tenure Table
tenure = pd.DataFrame(columns = ['count'])
tenure.loc['< 50'] = df[df.TOTAL_TENURE_MTHS<50].TOTAL_TENURE_MTHS.count()
tenure.loc['50_100'] = df[(df.TOTAL_TENURE_MTHS<100) & (df.TOTAL_TENURE_MTHS>=50)].TOTAL_TENURE_MTHS.count()
tenure.loc['100_150'] = df[(df.TOTAL_TENURE_MTHS<150) & (df.TOTAL_TENURE_MTHS>=100)].TOTAL_TENURE_MTHS.count()
tenure.loc['150_200'] = df[(df.TOTAL_TENURE_MTHS<200) & (df.TOTAL_TENURE_MTHS>=150)].TOTAL_TENURE_MTHS.count()
tenure.loc['200_250'] = df[(df.TOTAL_TENURE_MTHS<250) & (df.TOTAL_TENURE_MTHS>=200)].TOTAL_TENURE_MTHS.count()
tenure.loc['250+'] = df[(df.TOTAL_TENURE_MTHS>=250)].TOTAL_TENURE_MTHS.count()
apct1 = (tenure.iloc[0:1,0].values / tenure.iloc[0:5,0].values.sum())*100
apct2 = (tenure.iloc[1:2,0].values / tenure.iloc[0:5,0].values.sum())*100
apct3 = (tenure.iloc[2:3,0].values / tenure.iloc[0:5,0].values.sum())*100
apct4 = (tenure.iloc[3:4,0].values / tenure.iloc[0:5,0].values.sum())*100
apct5 = (tenure.iloc[4:5,0].values / tenure.iloc[0:5,0].values.sum())*100
apct6 = (tenure.iloc[5:6,0].values / tenure.iloc[0:5,0].values.sum())*100
tenure['pct'] = np.concatenate([apct1,apct2,apct3,apct4,apct5,apct6])
print(tenure)

# Age Plot
g = sns.catplot(y=tenure.index, x='count', data=tenure, 
                kind='bar', alpha=0.7, height = 6, aspect = 2)
g.fig.suptitle('Tenure by Months Breakdown') 

# Histogram of Tenure
sns.distplot(df.TOTAL_TENURE_MTHS)





<a id='2.2'></a>**Comparison with all members:**

# Set environment for ease of use
df_all = dsh_all_clean
sns.set_context('notebook')  #Everything is larger # Original is notebook

# Count of all members except Skeptical Control Seekers
# 2004998
print('Total:',df_all.MABH_SEG_GRP.count())
df_all.MABH_SEG_GRP.value_counts()

# Display Tables Side by Side
from IPython.display import display_html
def display_side_by_side(*args):
    html_str=''
    for df in args:
        html_str+=df.to_html()
    display_html(html_str.replace('table','table style="display:inline"'),raw=True)

# GENDER 
sns.set_context('poster')  #Everything is larger # Original is notebook
# Gender Table
gender_all = df_all.loc[:,'SEX_CD'].value_counts().to_frame('count')
gender_all['pct'] = df_all.SEX_CD.value_counts()/df_all.SEX_CD.count()*100
display_side_by_side(gender,gender_all)

# Gender Plot
fig, axis = plt.subplots(1,2,figsize=(15,4))
g = sns.catplot(y='SEX_CD', data=df, order=['F','M'], 
                kind='count', alpha=0.7, height = 3, aspect = 2,
                ax=axis[0])
g_all = sns.catplot(y='SEX_CD', data=df_all, order=['F','M'], 
                kind='count', alpha=0.7, height = 3, aspect = 2,
                ax=axis[1])
plt.close(2)
plt.close(3)

# AGE
sns.set_context('poster')  #Everything is larger # Original is notebook
# Age Table
age_all = pd.DataFrame(columns = ['count'])
age_all.loc['65+'] = df_all[df_all.AGE>64].AGE.count()
age_all.loc['< 65'] = df_all[df_all.AGE<65].AGE.count()
apct_all = (age_all.iloc[0:1,0].values / age_all.iloc[0:2,0].values.sum())*100
apct_all2 = (age_all.iloc[1:2,0].values / age_all.iloc[0:2,0].values.sum())*100
age_all['pct'] = np.concatenate([apct_all,apct_all2])
display_side_by_side(age,age_all)

# Age Plot
fig, axis = plt.subplots(1,2,figsize=(15,4))
g = sns.catplot(y=age.index, x='count', data=age, 
                kind='bar', alpha=0.7, height = 3, aspect = 2,
                ax=axis[0])
g_all = sns.catplot(y=age_all.index, x='count', data=age_all, 
                    kind='bar', alpha=0.7, height = 3, aspect = 2,
                    ax=axis[1])
plt.close(2)
plt.close(3)
plt.close(4)

# Histogram of age
sns.set_context('notebook')
sns.distplot(df.AGE, label = 'unengaged') 
sns.distplot(df_all.AGE, label = 'all_members')
plt.legend()

# ETHNICITY
sns.set_context('poster')  #Everything is larger # Original is notebook
# Ethnicity Tables
ethnicity_all = df_all.loc[:,'ETHNICITY'].value_counts().to_frame('count')
ethnicity_all['pct'] = df_all.loc[:,'ETHNICITY'].value_counts() / df_all.loc[:,'ETHNICITY'].count()*100
display_side_by_side(ethnicity,ethnicity_all)

# # Ethnicity Plots
# fig, axis = plt.subplots(1,2,figsize=(15,6))
# g = sns.catplot(y='ETHNICITY', data=df, order = df.ETHNICITY.value_counts().index,
#                 kind='count', alpha=0.7, height = 3, aspect = 2,
#                 ax=axis[0])
# g_all = sns.catplot(y='ETHNICITY', data=df_all, order = df_all.ETHNICITY.value_counts().index,
#                     kind='count', alpha=0.7, height = 3, aspect = 2,
#                     ax=axis[1])
# plt.close(2)
# plt.close(3)


# EDUCATION
sns.set_context('poster')  #Everything is larger # Original is notebook
# Education Tables
education_all = df_all.EDUCATION_LEVEL.value_counts().to_frame('count')
education_all['pct'] = df_all.EDUCATION_LEVEL.value_counts() / df_all.EDUCATION_LEVEL.count()*100
display_side_by_side(education,education_all)

# # Education Plots
# fig, axis = plt.subplots(1,2,figsize=(20,6))
# g = sns.catplot(y='EDUCATION_LEVEL', data=df, order = df.EDUCATION_LEVEL.value_counts().index,
#                 kind='count', alpha=0.7, height = 3, aspect = 2,
#                 ax=axis[0])
# g_all = sns.catplot(y='EDUCATION_LEVEL', data=df_all, order = df_all.EDUCATION_LEVEL.value_counts().index,
#                     kind='count', alpha=0.7, height = 3, aspect = 2,
#                     ax=axis[1])
# plt.close(2)
# plt.close(3)

# INCOME
sns.set_context('poster')  #Everything is larger # Original is notebook
# Income Tables
income_all = df_all.EST_INCOME.value_counts().to_frame('count')
income_all['pct'] = df_all.EST_INCOME.value_counts() / df_all.EST_INCOME.count()*100
display_side_by_side(income,income_all)
# # Income Plots
# fig, axis = plt.subplots(1,2,figsize=(15,4))
# g = sns.catplot(x='EST_INCOME', data=df, order = df.EST_INCOME.value_counts().sort_index(ascending = True).index,
#                 kind='count', alpha=0.7, height = 3, aspect = 3.5,
#                 ax=axis[0])
# g_all = sns.catplot(x='EST_INCOME', data=df_all, order = df_all.EST_INCOME.value_counts().sort_index(ascending = True).index,
#                     kind='count', alpha=0.7, height = 3, aspect = 3.5,
#                     ax=axis[1])
# plt.close(2)
# plt.close(3)

# FAMILY STATUS
# Education Tables
family_all = df_all.HHCOMP.value_counts().to_frame('count')
family_all['pct'] = df_all.HHCOMP.value_counts() / df_all.HHCOMP.count()*100
display_side_by_side(family,family_all)
# # Education Plots
# fig, axis = plt.subplots(1,2,figsize=(15,4))
# g = sns.catplot(y='HHCOMP', data=df, order = df.HHCOMP.value_counts().index,
#                 kind='count', alpha=0.7, height = 3, aspect = 2,
#                 ax=axis[0])
# g_all = sns.catplot(y='HHCOMP', data=df_all, order = df_all.HHCOMP.value_counts().index,
#                     kind='count', alpha=0.7, height = 3, aspect = 2,
#                     ax=axis[1])
# plt.close(2)
# plt.close(3)

# TENURE
sns.set_context('poster')  #Everything is larger # Original is notebook
# Tenure Table
tenure_all = pd.DataFrame(columns = ['count'])
tenure_all.loc['< 50'] = df_all[df_all.TOTAL_TENURE_MTHS<50].TOTAL_TENURE_MTHS.count()
tenure_all.loc['50_100'] = df_all[(df_all.TOTAL_TENURE_MTHS<100) & (df_all.TOTAL_TENURE_MTHS>=50)].TOTAL_TENURE_MTHS.count()
tenure_all.loc['100_150'] = df_all[(df_all.TOTAL_TENURE_MTHS<150) & (df_all.TOTAL_TENURE_MTHS>=100)].TOTAL_TENURE_MTHS.count()
tenure_all.loc['150_200'] = df_all[(df_all.TOTAL_TENURE_MTHS<200) & (df_all.TOTAL_TENURE_MTHS>=150)].TOTAL_TENURE_MTHS.count()
tenure_all.loc['200_250'] = df_all[(df_all.TOTAL_TENURE_MTHS<250) & (df_all.TOTAL_TENURE_MTHS>=200)].TOTAL_TENURE_MTHS.count()
tenure_all.loc['250+'] = df_all[(df_all.TOTAL_TENURE_MTHS>=250)].TOTAL_TENURE_MTHS.count()
apct_all1 = (tenure_all.iloc[0:1,0].values / tenure_all.iloc[0:5,0].values.sum())*100
apct_all2 = (tenure_all.iloc[1:2,0].values / tenure_all.iloc[0:5,0].values.sum())*100
apct_all3 = (tenure_all.iloc[2:3,0].values / tenure_all.iloc[0:5,0].values.sum())*100
apct_all4 = (tenure_all.iloc[3:4,0].values / tenure_all.iloc[0:5,0].values.sum())*100
apct_all5 = (tenure_all.iloc[4:5,0].values / tenure_all.iloc[0:5,0].values.sum())*100
apct_all6 = (tenure_all.iloc[5:6,0].values / tenure_all.iloc[0:5,0].values.sum())*100
tenure_all['pct'] = np.concatenate([apct_all1,apct_all2,apct_all3,apct_all4,apct_all5,apct_all6])
display_side_by_side(tenure,tenure_all)

# # Age Plot
# fig, axis = plt.subplots(1,2,figsize=(15,4))
# g = sns.catplot(y=tenure.index, x='count', data=tenure, 
#                 kind='bar', alpha=0.7, height = 6, aspect = 2,
#                  ax=axis[0])
# g_all = sns.catplot(y=tenure_all.index, x='count', data=tenure_all, 
#                     kind='bar', alpha=0.7, height = 6, aspect = 2,
#                     ax=axis[1])
# plt.close(2)
# plt.close(3)

# Histogram of Tenure
sns.set_context('notebook')
sns.distplot(df.TOTAL_TENURE_MTHS, label = 'unengaged') 
sns.distplot(df_all.TOTAL_TENURE_MTHS, label = 'all_members')
plt.legend()

**More Detailed Breakdown:(Work in Progress)**<a id='2.3'></a>

# What is the breakout of Males & Females by Ethnicity
# df_scs[(df_scs.MABH_SEG_GRP == 'SKPT_CTRL_SEKR')].SEX_CD.value_counts()
df.groupby(['ETHNICITY','SEX_CD']).size().sort_values(ascending = False)





## <a id='3'>Geographical Data</a>
<a href='#0'>Back to top</a>

geo_columns = ['MBR_PERS_GEN_KEY','REGION','DIVISION','BOLD_MOVE_MARKET','STATE_CD','ZIP_CD','CNTY_CD']
df[geo_columns].head()

<a id='3.1'></a>**Unengaged Members**

# REGION Table
region = df.REGION.value_counts().to_frame('count')
region['pct'] = df.REGION.value_counts()/df.REGION.count()*100
print(region)

# DIVISION Table
division = df.DIVISION.value_counts().to_frame('count')
division['pct'] = df.DIVISION.value_counts()/df.DIVISION.count()*100
print(division)

# BOLD_MOVE_MARKET Table
bold = df.BOLD_MOVE_MARKET.value_counts().to_frame('count')
bold['pct'] = df.BOLD_MOVE_MARKET.value_counts()/df.BOLD_MOVE_MARKET.count()*100
print(bold)

# STATE Table
state = df.STATE_CD.value_counts().to_frame('count')
state['pct'] = df.STATE_CD.value_counts()/df.STATE_CD.count()*100
print(state)

<a id='3.2'></a>**Comparison with all members:**

df_all[geo_columns].head()

# Display Tables Side by Side
from IPython.display import display_html
def display_side_by_side(*args):
    html_str=''
    for df in args:
        html_str+=df.to_html()
    display_html(html_str.replace('table','table style="display:inline"'),raw=True)

# REGION Table
region_all = df_all.REGION.value_counts().to_frame('count')
region_all['pct'] = df_all.REGION.value_counts()/df_all.REGION.count()*100
print('     Unengaged Members', '                         All')
display_side_by_side(region,region_all)

# DIVISION Table
division_all = df_all.DIVISION.value_counts().to_frame('count')
division_all['pct'] = df_all.DIVISION.value_counts()/df_all.DIVISION.count()*100
print('     Unengaged Members', '                         All')
display_side_by_side(division,division_all)

# BOLD_MOVE_MARKET Table
bold_all = df_all.BOLD_MOVE_MARKET.value_counts().to_frame('count')
bold_all['pct'] = df_all.BOLD_MOVE_MARKET.value_counts()/df_all.BOLD_MOVE_MARKET.count()*100
print('     Unengaged Members', '                         All')
display_side_by_side(bold,bold_all)

# STATE Table
state_all = df_all.STATE_CD.value_counts().to_frame('count')
state_all['pct'] = df_all.STATE_CD.value_counts()/df_all.STATE_CD.count()*100
print(' Unengaged Members', '         All')
display_side_by_side(state,state_all)





## <a id='4'>Behaviorial Data</a>
<a href='#0'>Back to top</a>

**Bring in Dataset: (_Optional if already brought in_)**

# Data path
path = ''
filename = 'CON_DSH_PTOTRADMAIL_UPD1.csv'
filepath = f'{path}{filename}'
print(filepath)

pto_tradmail = pd.read_csv(filepath, header=0)

pto_clean = pto_tradmail[pto_tradmail.IND_MAPD == 1]
pto_clean.IND_MAPD.value_counts()

pto_clean = pto_clean[(pto_clean.MABH_SEG_GRP == 'SKPT_CTRL_SEKR')]
pto_clean.MABH_SEG_GRP.value_counts()

pto_clean = pto_clean.drop_duplicates('MBR_PERS_GEN_KEY', keep = 'first')
pto_clean.IND_MAPD.value_counts()

df = pto_clean
df.MBR_PERS_GEN_KEY.count()

**Exploration**

print(df.shape)
print(df_all.shape)

df.iloc[:,5:6].sum()/df.MBR_PERS_GEN_KEY.count()

**Topic1**

# Column names
col_names = datautils.resultColumnNames(mycursor)
col_names

# Convert query to a dataframe
digital_data3 = pd.DataFrame(dataset,columns = col_names)

# Close Cursor
mycursor.close()

# Reshape data
# Subset data
dd = digital_data3
# Select data 
category = dd.drop(['CRMTRC_YR_MTH'],axis=1)

print('Member Count:' ,category.MBR_PERS_GEN_KEY.nunique())
category.shape

category.sum().sort_values(ascending=False).head()

# Count of DISTINCT usage by OS LOD:MBR_PERS_GEN_KEY
for i in range(0,(len(category.columns)-1)):
    print(category.iloc[:,i+1].name,':  '\
          ,'COUNT:',sum(category.groupby('MBR_PERS_GEN_KEY').sum().iloc[:,i] >= 1) \
          ,'PCT:',round(sum(category.groupby('MBR_PERS_GEN_KEY').sum().iloc[:,i] >= 1)/category.MBR_PERS_GEN_KEY.nunique()*100),'%' )

## <a id='5'>Digital Data</a>
<a href='#0'>Back to top</a>

**_Summary_:**
- Web Session: From the list of tradmail, only 22% of the users had at least 1 web session
- OS & Mobile: ~ 74% of the users use Windows ; ~ 20% of users use IOS: Iphones or Ipad
- Country:
- State: Florida, Texas, and Georgia make up ~50% of the population of webusers; (Florida: ~28%, Texas: ~11%, Georgia: ~10%)
- Category:
- Topic: 

**_Ideas_:**
- Could look into the members with the most views and try to understand why are they using it more vs the group that isn't using as much. Is there something about them?
    * Bin into different groups

<a id='5.0'></a>**Read in CSV instead of Oracle**

path = ''
filename = 'WEB_ACTIVE_MBR_MTH.csv'
filepath = f'{path}{filename}'
print(filepath)
# digital_data = pd.read_csv(filepath,header=0) #uncomment to get data

**Retrieving data through Oracle**

# db = sqla.create_engine('oracle+cx_oracle://kgh2848:hay7323#@isbcan02.humana.com:1526/CANDEV')
# pd.read_sql('SELECT MBR_PERS_GEN_KEY FROM CA_RPT.CON_DSH_PTOTRADMAIL_UPD1 fetch first 10 rows only', db)

# Connecting to Oracle
dbcon = datautils.candevconnect()

mycursor = dbcon.cursor()

# Query written out by Segments of data to analyze
myquery = """
SELECT
    MBR_PERS_GEN_KEY
    ,CRMTRC_YR_MTH
    ,IND_LOB_MEDICARE,IND_LOB_COMMERCIAL,IND_LOB2_MAPD_MA,IND_LOB2_PDP,IND_LOB2_GRP_MAPD,IND_LOB2_GRP_PDP,IND_LOB2_HUM1
--    ,IND_PRDLINE_MED,IND_PRDLINE_DEN,IND_PRDLINE_VIS,IND_PRDLINE_LIF,IND_PRDLINE_OTH
    ,CNT_WEB_SESSIONS,CNT_PAGE_VIEW,DURATION_MINUTES
    ,IND_LANG_PREF_ENGLISH,IND_LANG_PREF_SPANISH,IND_LANG_PREF_OTHER
    ,IND_USAGE_ANDROID_OS,IND_USAGE_IOS_OS,IND_USAGE_MAC_OSX_OS,IND_USAGE_WINDOWS_OS,IND_USAGE_OTHER_OS,CNT_DISTINCT_OS
    ,IND_COUNTRY_USA,IND_COUNTRY_CANADA,IND_COUNTRY_MEXICO,IND_COUNTRY_OTHER
    ,IND_MOBILE_DEVICE,IND_MOBILE_DEVICE_TYPE_TABLET,IND_MOBILE_DEVICE_TYPE_PHONE,IND_MOBILE_DEVICE_TYPE_OTHER,IND_MOBILE_DEVICE_IPHONE,IND_MOBILE_DEVICE_IPAD,IND_MOBILE_DEVICE_GALAXY,IND_MOBILE_DEVICE_KINDLE,IND_MOBILE_DEVICE_DROID,IND_MOBILE_DEVICE_OTHER,CNT_DISTINCT_DEVICES
    ,IND_STATE_AL ,IND_STATE_AK ,IND_STATE_AZ ,IND_STATE_AR ,IND_STATE_CA ,IND_STATE_CO ,IND_STATE_CT ,IND_STATE_DE ,IND_STATE_DC ,IND_STATE_FL ,IND_STATE_GA ,IND_STATE_HI ,IND_STATE_ID ,IND_STATE_IL ,IND_STATE_IN ,IND_STATE_IA ,IND_STATE_KS ,IND_STATE_KY ,IND_STATE_LA ,IND_STATE_ME ,IND_STATE_MD ,IND_STATE_MA ,IND_STATE_MI ,IND_STATE_MN ,IND_STATE_MS ,IND_STATE_MO ,IND_STATE_MT ,IND_STATE_NE ,IND_STATE_NV ,IND_STATE_NH ,IND_STATE_NJ ,IND_STATE_NM ,IND_STATE_NY ,IND_STATE_NC ,IND_STATE_ND ,IND_STATE_OH ,IND_STATE_OK ,IND_STATE_OR ,IND_STATE_PA ,IND_STATE_RI ,IND_STATE_SC ,IND_STATE_SD ,IND_STATE_TN ,IND_STATE_TX ,IND_STATE_UT ,IND_STATE_VT ,IND_STATE_VA ,IND_STATE_WA ,IND_STATE_WV ,IND_STATE_WY ,IND_STATE_WI ,IND_STATE_OTHER  ,CNT_DISTINCT_STATES
    ,IND_CAT_AGENT_PORTAL ,IND_CAT_CAREGIVER_PORTAL ,IND_CAT_EMPLOYER_PORTAL  ,IND_CAT_MEMBER_PORTAL  ,IND_CAT_PROVIDER_PORTAL  ,IND_CAT_AGENT_WKBENCH  ,IND_CAT_CAC_MED_CENTER ,IND_CAT_CAREPLUS ,IND_CAT_CLOSETHEGAP  ,IND_CAT_CUSTOM_CLIENT  ,IND_CAT_EAPWL  ,IND_CAT_EBILLING ,IND_CAT_EMPLYR_BEN_CENTR ,IND_CAT_ENGMNTSRC_GO365  ,IND_CAT_ENGMNTSRC_HUMANA ,IND_CAT_ENROLLMENT_CENTR ,IND_CAT_FINDER_TOOLS ,IND_CAT_GO365  ,IND_CAT_HARRISROTHENBERG ,IND_CAT_HUM_INTELLICHC_GUIDE ,IND_CAT_HUM_MBR_ASSIST_PROG  ,IND_CAT_HUM_MILITARY ,IND_CAT_HUM_PTS_OF_CARE  ,IND_CAT_HUMANA_COM ,IND_CAT_HUM_BHVRL_HLTH ,IND_CAT_HUM_MEDR_LEGACY  ,IND_CAT_HUM_MIL_ANDROID_APP  ,IND_CAT_HUM_MIL_IOS_APP  ,IND_CAT_HUMONE_DENT_LEGACY ,IND_CAT_HUMANA_DENTAL  ,IND_CAT_HUMANA_VISIONCARE  ,IND_CAT_HUM_PHARMACY_COM ,IND_CAT_HUM_PHARM_ANDROID_APP  ,IND_CAT_HUM_PHARM_IOS_APP  ,IND_CAT_RIGHTSOURCERX  ,IND_CAT_RIGHTSOURCE_APP  ,IND_CAT_HUM_VANTAGE  ,IND_CAT_ID_CARD_CNTR ,IND_CAT_MKTPLC_HUM_COM ,IND_CAT_MYDENTALIQ ,IND_CAT_MYHEALTH_ANDROID_APP ,IND_CAT_MYHEALTH_IOS_APP ,IND_CAT_MYHUMANA_ANDROID_APP ,IND_CAT_MYHUMANA_IOS_APP ,IND_CAT_MY_MEDR_ANSWERS_COM  ,IND_CAT_MYWELL_BEING_COM ,IND_CAT_PAYNOW ,IND_CAT_RX_CONNECT_PRO ,IND_CAT_SHOP_HUM_COM ,IND_CAT_VIRT_GUIDNC_CNTR ,IND_CAT_VITALITY_LEGACY  ,IND_CAT_HUMANAVITALITY ,IND_CAT_HUMANAVITALITY_APP ,CNT_CATEGORIES
    ,IND_TOPIC_ACCT_SETTING ,IND_TOPIC_ACHIEVEMENT  ,IND_TOPIC_APP_COVERAGE ,IND_TOPIC_BENEFIT_ACCUM  ,IND_TOPIC_BIOMETRICS ,IND_TOPIC_BONE_JOINT ,IND_TOPIC_CANCER ,IND_TOPIC_COPD ,IND_TOPIC_DIABETES ,IND_TOPIC_HEART_DISEASE  ,IND_TOPIC_FLU  ,IND_TOPIC_CAREER ,IND_TOPIC_CHALLENGE  ,IND_TOPIC_CHECKOUT ,IND_TOPIC_SHOPPING_CART  ,IND_TOPIC_CLAIMRECONTOOL ,IND_TOPIC_CLAIM  ,IND_TOPIC_CLAIM_DETAIL ,IND_TOPIC_CLAIM_SNAPSHOT ,IND_TOPIC_COMM_CENTR ,IND_TOPIC_CONTACT_US ,IND_TOPIC_COVERAGE_BENEFIT ,IND_TOPIC_COVERAGE_CLAIM ,IND_TOPIC_MEDICAL_CLAIM  ,IND_TOPIC_RX_CLAIM ,IND_TOPIC_DENTAL_CLAIM ,IND_TOPIC_VISION_CLAIM ,IND_TOPIC_DEDUCTIBLE ,IND_TOPIC_DIET_NUTRN ,IND_TOPIC_DRIVING_DIRECTIONS ,IND_TOPIC_DRUG_LIST  ,IND_TOPIC_DRUG_PLAN  ,IND_TOPIC_DRUG_SEARCH  ,IND_TOPIC_EARN_POINTS  ,IND_TOPIC_EARN_REWARDS ,IND_TOPIC_EAT_HEALTHY  ,IND_TOPIC_FILE_DWNLD ,IND_TOPIC_FIND_CLINIC  ,IND_TOPIC_FIND_DENTIST ,IND_TOPIC_FIND_DENTAL_SPECLST  ,IND_TOPIC_FIND_DOCTOR  ,IND_TOPIC_FIND_MEDICAL_SPECLST ,IND_TOPIC_FIND_HEALTH_CLUB ,IND_TOPIC_FIND_HOSPITAL  ,IND_TOPIC_FIND_PHARMACY  ,IND_TOPIC_FIND_PROVIDER  ,IND_TOPIC_FIND_URGENT_CARE ,IND_TOPIC_FITNESS_DEVICE ,IND_TOPIC_FITNESS_EXERCS ,IND_TOPIC_FITNESS_CNTR ,IND_TOPIC_GO365_ACTVTYS  ,IND_TOPIC_FORGOT_PASSWD  ,IND_TOPIC_GRIEVANCE_APPEAL ,IND_TOPIC_HEALTHY_FOOD ,IND_TOPIC_HLTH_WELL_BEING  ,IND_TOPIC_HLTH_WELLNESS  ,IND_TOPIC_HLTH_ASMT_RESULT ,IND_TOPIC_HLTH_ASMT  ,IND_TOPIC_GO365_FORMS  ,IND_TOPIC_ID_CARD  ,IND_TOPIC_INDIV_PROD ,IND_TOPIC_INVOICE  ,IND_TOPIC_MAIL_DELIVERY  ,IND_TOPIC_MANAGE_ACCESS  ,IND_TOPIC_MRKTPNT_LOCATION ,IND_TOPIC_MED_CABINET  ,IND_TOPIC_MEDICAL_RECDS  ,IND_TOPIC_MENTAL_HLTH  ,IND_TOPIC_MSG_DETAIL ,IND_TOPIC_MY_GOAL  ,IND_TOPIC_MY_PRESCRIPTIONS ,IND_TOPIC_ORDER_CONFIRMATION ,IND_TOPIC_ORDER_HISTORY  ,IND_TOPIC_ORDER_STATUS ,IND_TOPIC_PAYMENT  ,IND_TOPIC_PAY_BILL ,IND_TOPIC_PCP  ,IND_TOPIC_PHARM_SPCLTY ,IND_TOPIC_PHARM_TOOLS  ,IND_TOPIC_PRODCTS_SRVCS  ,IND_TOPIC_QUIT_SMOKING ,IND_TOPIC_QUOTE  ,IND_TOPIC_RECD_MSG ,IND_TOPIC_REFILL ,IND_TOPIC_REFERRAL ,IND_TOPIC_REGISTRATION ,IND_TOPIC_RESET_PASSWD ,IND_TOPIC_RTRV_USERNAME  ,IND_TOPIC_REWARDS_MALL ,IND_TOPIC_REMINDER ,IND_TOPIC_RXCALCULATOR ,IND_TOPIC_RX_PRICING ,IND_TOPIC_RX_TOOLS ,IND_TOPIC_SWITCH_RX  ,IND_TOPIC_SALESFORCE_CHAT  ,IND_TOPIC_SMART_SMRY ,IND_TOPIC_SPANISH  ,IND_TOPIC_SPENDING_CLAIMS  ,IND_TOPIC_STARTWITHHEALTHY ,IND_TOPIC_VITAMIN  ,CNT_TOPICS

FROM
    CA_DIGITAL.WEB_ACTIVE_MBR_MTH
WHERE
    MBR_PERS_GEN_KEY in
        (SELECT DISTINCT
            MBR_PERS_GEN_KEY
        FROM
            CA_RPT.CON_DSH_PTOTRADMAIL_UPD1
        )
"""

dataset = datautils.doquery(mycursor,myquery)

# Column names
col_names = datautils.resultColumnNames(mycursor)
col_names

# Convert query to a dataframe
digital_data = pd.DataFrame(dataset,columns = col_names)

# Close Cursor
mycursor.close()

**Explore Data**

print('Unique Member Count:' ,digital_data.MBR_PERS_GEN_KEY.nunique())
digital_data.head()

# Shape of the data
print('\033[1m'+'DATASET','(ROWS, COLUMNS)'+'\033[0m')
print('dataset',digital_data.shape)

# Print out Unique Values for Each Column
for col in range(0,len(digital_data.columns)): # len(df.columns)
    if (col in []): # Add here to skip over these columns
        continue
    print(col,end=")")
    print('\033[1m'+ digital_data.columns[col] +'\033[0m',end=":")
    print(digital_data.iloc[:,col].dtype)
    print(digital_data.iloc[:,col].unique(), '\n')

sns.set_style('whitegrid') # Set Seaborn Styles

# Correlation matrix 
corrmat = digital_data.corr()
f, ax = plt.subplots(figsize=(12, 9))
sns.heatmap(corrmat, square=True)

**Subset data to just 2018 if want to compare to Cara's dataset**

result = pd.merge(digital_data,df, how='left', on='MBR_PERS_GEN_KEY')
result2 = pd.merge(digital_data,df, how='inner', on='MBR_PERS_GEN_KEY')
print('dimensions',digital_data.shape)
print('result dimensions:', result.shape)
print('result dimensions:', result2.shape)

test = result2.sort_values(by='CRMTRC_YR_MTH').reset_index()

test2 = test.iloc[219814:,]

test2.nunique()

<a id='5.1'></a>**Web_Sessions**

**_Summary_:**
- From the list of tradmail, only 22% of the users had at least 1 web session

**_Assumptions_:**
- Digital footprint is defined by user having 1 websession. A distinct count is taking from that value
- Not sure what the date range is for the pto_tradmail data, might want to normalize the data so we're comparing the same timeframe

# Distinct Count of members with a digital footprint (At least 1 web session)
ct = digital_data.groupby('MBR_PERS_GEN_KEY').size().count()
ct_trad = df.groupby('MBR_PERS_GEN_KEY').size().count()
print('Data Range: '+ digital_data.CRMTRC_YR_MTH.min() + '-' + digital_data.CRMTRC_YR_MTH.max(),'\n')
print('\033[1m'+'DESCRIPTION:','RESULTS'+'\033[0m')
print('digital footprint:',ct)
print('pto_tradmail:',ct_trad) # Count of members in the PTO_TRADMAIL
print('percent:', ct/ct_trad*100)

# All records
digital_data.CNT_WEB_SESSIONS.describe()
sns.distplot(digital_data.CNT_WEB_SESSIONS)
plt.xlim(0,15)

# Shows Number of Months a user had a websession. LOD: Month
print(digital_data.groupby('MBR_PERS_GEN_KEY').size().head())
sns.distplot(digital_data.groupby('MBR_PERS_GEN_KEY').size())
plt.xlim(0,15)

# Average Count of Web Sessions per user at LOD: month
print('Avg of the Avg by users:',digital_data.groupby('MBR_PERS_GEN_KEY').CNT_WEB_SESSIONS.mean().mean())
sns.distplot(digital_data.groupby('MBR_PERS_GEN_KEY').CNT_WEB_SESSIONS.mean())
plt.xlim(0,15)

<a id='5.2'></a>**OS & Mobile**

- ~ 74% of the users use Windows
- ~ 20% of users use IOS: Iphones or Ipad

# Reshape data
# Subset data
dd = digital_data
cats = ['MBR_PERS_GEN_KEY','IND_USAGE_ANDROID_OS','IND_USAGE_IOS_OS','IND_USAGE_MAC_OSX_OS','IND_USAGE_WINDOWS_OS','IND_USAGE_OTHER_OS']
# Select data 
mobile = dd[cats]

# Count of total usage (NOT DISTINCT)
print('Member Count:' ,digital_data.MBR_PERS_GEN_KEY.nunique())
mobile.iloc[:,1:].sum()

# Count of DISTINCT usage by OS LOD:MBR_PERS_GEN_KEY
for i in range(0,(len(mobile.columns)-1)):
    print(mobile.iloc[:,i+1].name) 
    print('COUNT:',sum(mobile.groupby('MBR_PERS_GEN_KEY').sum().iloc[:,i] >= 1))
    print('PCT:',sum(mobile.groupby('MBR_PERS_GEN_KEY').sum().iloc[:,i] >= 1)/digital_data.MBR_PERS_GEN_KEY.nunique(),'\n')

# Reshape data
# Subset data
dd = digital_data
cats = ['MBR_PERS_GEN_KEY','IND_MOBILE_DEVICE','IND_MOBILE_DEVICE_TYPE_TABLET'
        ,'IND_MOBILE_DEVICE_TYPE_PHONE','IND_MOBILE_DEVICE_TYPE_OTHER'
        ,'IND_MOBILE_DEVICE_IPHONE','IND_MOBILE_DEVICE_IPAD','IND_MOBILE_DEVICE_GALAXY'
        ,'IND_MOBILE_DEVICE_KINDLE','IND_MOBILE_DEVICE_DROID','IND_MOBILE_DEVICE_OTHER'
        ,'IND_MOBILE_DEVICE_OTHER','CNT_DISTINCT_DEVICES'
       ]
# Select data 
mobile2 = dd[cats]

# Count of DISTINCT usage by OS LOD:MBR_PERS_GEN_KEY
for i in range(0,(len(mobile2.columns)-1)):
    print(mobile2.iloc[:,i+1].name) 
    print('COUNT:',sum(mobile2.groupby('MBR_PERS_GEN_KEY').sum().iloc[:,i] >= 1))
    print('PCT:',sum(mobile2.groupby('MBR_PERS_GEN_KEY').sum().iloc[:,i] >= 1)/digital_data.MBR_PERS_GEN_KEY.nunique(),'\n')

<a id='5.3'></a>**Country**

# Reshape data
# Subset data
dd = digital_data
cats = ['MBR_PERS_GEN_KEY','IND_COUNTRY_USA','IND_COUNTRY_CANADA','IND_COUNTRY_MEXICO','IND_COUNTRY_OTHER']
# Select data 
country = dd[cats]

print('Member Count:' ,digital_data.MBR_PERS_GEN_KEY.nunique())

# Count of DISTINCT usage by OS LOD:MBR_PERS_GEN_KEY
for i in range(0,(len(country.columns)-1)):
    print(country.iloc[:,i+1].name) 
    print('COUNT:',sum(country.groupby('MBR_PERS_GEN_KEY').sum().iloc[:,i] >= 1))
    print('PCT:',sum(country.groupby('MBR_PERS_GEN_KEY').sum().iloc[:,i] >= 1)/digital_data.MBR_PERS_GEN_KEY.nunique(),'\n')

<a id='5.4'></a>**State**

- Florida, Texas, and Georgia make up ~50% of the population of webusers
    * Florida: ~28%
    * Texas: ~11%
    * Georgia: ~10%

mycursor = dbcon.cursor()

# Query written out by Segments of data to analyze
myquery = """
SELECT
    MBR_PERS_GEN_KEY
    ,CRMTRC_YR_MTH
    ,IND_STATE_AL ,IND_STATE_AK ,IND_STATE_AZ ,IND_STATE_AR ,IND_STATE_CA ,IND_STATE_CO ,IND_STATE_CT ,IND_STATE_DE ,IND_STATE_DC ,IND_STATE_FL ,IND_STATE_GA ,IND_STATE_HI ,IND_STATE_ID ,IND_STATE_IL ,IND_STATE_IN ,IND_STATE_IA ,IND_STATE_KS ,IND_STATE_KY ,IND_STATE_LA ,IND_STATE_ME ,IND_STATE_MD ,IND_STATE_MA ,IND_STATE_MI ,IND_STATE_MN ,IND_STATE_MS ,IND_STATE_MO ,IND_STATE_MT ,IND_STATE_NE ,IND_STATE_NV ,IND_STATE_NH ,IND_STATE_NJ ,IND_STATE_NM ,IND_STATE_NY ,IND_STATE_NC ,IND_STATE_ND ,IND_STATE_OH ,IND_STATE_OK ,IND_STATE_OR ,IND_STATE_PA ,IND_STATE_RI ,IND_STATE_SC ,IND_STATE_SD ,IND_STATE_TN ,IND_STATE_TX ,IND_STATE_UT ,IND_STATE_VT ,IND_STATE_VA ,IND_STATE_WA ,IND_STATE_WV ,IND_STATE_WY ,IND_STATE_WI ,IND_STATE_OTHER  ,CNT_DISTINCT_STATES
FROM
    CA_DIGITAL.WEB_ACTIVE_MBR_MTH
WHERE
    MBR_PERS_GEN_KEY in
        (SELECT DISTINCT
            MBR_PERS_GEN_KEY
        FROM
            CA_RPT.CON_DSH_PTOTRADMAIL_UPD1
        )
"""

dataset = datautils.doquery(mycursor,myquery)

# Column names
col_names = datautils.resultColumnNames(mycursor)
col_names

# Convert query to a dataframe
digital_data2 = pd.DataFrame(dataset,columns = col_names)

# Close Cursor
mycursor.close()

# Reshape data
# Subset data
dd = digital_data2
# Select data 
state = dd.drop(['CRMTRC_YR_MTH'],axis=1)

print('Member Count:' ,state.MBR_PERS_GEN_KEY.nunique())

state.sum().sort_values(ascending=False).head()

# Count of DISTINCT usage by OS LOD:MBR_PERS_GEN_KEY
for i in range(0,(len(state.columns)-1)):
    print(state.iloc[:,i+1].name,':  ','COUNT:' \
          ,sum(state.groupby('MBR_PERS_GEN_KEY').sum().iloc[:,i] >= 1) \
          ,'PCT:',round(sum(state.groupby('MBR_PERS_GEN_KEY').sum().iloc[:,i] >= 1)/state.MBR_PERS_GEN_KEY.nunique()*100),'%')

<a id='5.5'></a>**Category**

- Usage Stats
    * Using Member Portal 95%
    * Ebilling 18%
    * Finder Tools 44%
    * Humana.com 94%
    * Humana Pharmacy.com 24%
    * HumOne dent legacy 11%
    * ID Card Center 18%
    * Shop Humana 28%

mycursor = dbcon.cursor()

# Query written out by Segments of data to analyze
myquery = """
SELECT
    MBR_PERS_GEN_KEY
    ,CRMTRC_YR_MTH
    ,IND_CAT_AGENT_PORTAL ,IND_CAT_CAREGIVER_PORTAL ,IND_CAT_EMPLOYER_PORTAL  ,IND_CAT_MEMBER_PORTAL  ,IND_CAT_PROVIDER_PORTAL  ,IND_CAT_AGENT_WKBENCH  ,IND_CAT_CAC_MED_CENTER ,IND_CAT_CAREPLUS ,IND_CAT_CLOSETHEGAP  ,IND_CAT_CUSTOM_CLIENT  ,IND_CAT_EAPWL  ,IND_CAT_EBILLING ,IND_CAT_EMPLYR_BEN_CENTR ,IND_CAT_ENGMNTSRC_GO365  ,IND_CAT_ENGMNTSRC_HUMANA ,IND_CAT_ENROLLMENT_CENTR ,IND_CAT_FINDER_TOOLS ,IND_CAT_GO365  ,IND_CAT_HARRISROTHENBERG ,IND_CAT_HUM_INTELLICHC_GUIDE ,IND_CAT_HUM_MBR_ASSIST_PROG  ,IND_CAT_HUM_MILITARY ,IND_CAT_HUM_PTS_OF_CARE  ,IND_CAT_HUMANA_COM ,IND_CAT_HUM_BHVRL_HLTH ,IND_CAT_HUM_MEDR_LEGACY  ,IND_CAT_HUM_MIL_ANDROID_APP  ,IND_CAT_HUM_MIL_IOS_APP  ,IND_CAT_HUMONE_DENT_LEGACY ,IND_CAT_HUMANA_DENTAL  ,IND_CAT_HUMANA_VISIONCARE  ,IND_CAT_HUM_PHARMACY_COM ,IND_CAT_HUM_PHARM_ANDROID_APP  ,IND_CAT_HUM_PHARM_IOS_APP  ,IND_CAT_RIGHTSOURCERX  ,IND_CAT_RIGHTSOURCE_APP  ,IND_CAT_HUM_VANTAGE  ,IND_CAT_ID_CARD_CNTR ,IND_CAT_MKTPLC_HUM_COM ,IND_CAT_MYDENTALIQ ,IND_CAT_MYHEALTH_ANDROID_APP ,IND_CAT_MYHEALTH_IOS_APP ,IND_CAT_MYHUMANA_ANDROID_APP ,IND_CAT_MYHUMANA_IOS_APP ,IND_CAT_MY_MEDR_ANSWERS_COM  ,IND_CAT_MYWELL_BEING_COM ,IND_CAT_PAYNOW ,IND_CAT_RX_CONNECT_PRO ,IND_CAT_SHOP_HUM_COM ,IND_CAT_VIRT_GUIDNC_CNTR ,IND_CAT_VITALITY_LEGACY  ,IND_CAT_HUMANAVITALITY ,IND_CAT_HUMANAVITALITY_APP ,CNT_CATEGORIES

FROM
    CA_DIGITAL.WEB_ACTIVE_MBR_MTH
WHERE
    MBR_PERS_GEN_KEY in
        (SELECT DISTINCT
            MBR_PERS_GEN_KEY
        FROM
            CA_RPT.CON_DSH_PTOTRADMAIL_UPD1
        )
"""

dataset = datautils.doquery(mycursor,myquery)

# Column names
col_names = datautils.resultColumnNames(mycursor)
col_names

# Convert query to a dataframe
digital_data3 = pd.DataFrame(dataset,columns = col_names)

# Close Cursor
mycursor.close()

# Reshape data
# Subset data
dd = digital_data3
# Select data 
category = dd.drop(['CRMTRC_YR_MTH'],axis=1)

print('Member Count:' ,category.MBR_PERS_GEN_KEY.nunique())
category.shape

category.sum().sort_values(ascending=False).head()

# Count of DISTINCT usage by OS LOD:MBR_PERS_GEN_KEY
for i in range(0,(len(category.columns)-1)):
    print(category.iloc[:,i+1].name,':  '\
          ,'COUNT:',sum(category.groupby('MBR_PERS_GEN_KEY').sum().iloc[:,i] >= 1) \
          ,'PCT:',round(sum(category.groupby('MBR_PERS_GEN_KEY').sum().iloc[:,i] >= 1)/category.MBR_PERS_GEN_KEY.nunique()*100),'%' )

<a id='5.6'></a>**Topic**

- Shopping Cart => Checkout

mycursor = dbcon.cursor()

# Query written out by Segments of data to analyze
myquery = """
SELECT
    MBR_PERS_GEN_KEY
    ,CRMTRC_YR_MTH
    ,IND_TOPIC_ACCT_SETTING ,IND_TOPIC_ACHIEVEMENT  ,IND_TOPIC_APP_COVERAGE ,IND_TOPIC_BENEFIT_ACCUM  ,IND_TOPIC_BIOMETRICS ,IND_TOPIC_BONE_JOINT ,IND_TOPIC_CANCER ,IND_TOPIC_COPD ,IND_TOPIC_DIABETES ,IND_TOPIC_HEART_DISEASE  ,IND_TOPIC_FLU  ,IND_TOPIC_CAREER ,IND_TOPIC_CHALLENGE  ,IND_TOPIC_CHECKOUT ,IND_TOPIC_SHOPPING_CART  ,IND_TOPIC_CLAIMRECONTOOL ,IND_TOPIC_CLAIM  ,IND_TOPIC_CLAIM_DETAIL ,IND_TOPIC_CLAIM_SNAPSHOT ,IND_TOPIC_COMM_CENTR ,IND_TOPIC_CONTACT_US ,IND_TOPIC_COVERAGE_BENEFIT ,IND_TOPIC_COVERAGE_CLAIM ,IND_TOPIC_MEDICAL_CLAIM  ,IND_TOPIC_RX_CLAIM ,IND_TOPIC_DENTAL_CLAIM ,IND_TOPIC_VISION_CLAIM ,IND_TOPIC_DEDUCTIBLE ,IND_TOPIC_DIET_NUTRN ,IND_TOPIC_DRIVING_DIRECTIONS ,IND_TOPIC_DRUG_LIST  ,IND_TOPIC_DRUG_PLAN  ,IND_TOPIC_DRUG_SEARCH  ,IND_TOPIC_EARN_POINTS  ,IND_TOPIC_EARN_REWARDS ,IND_TOPIC_EAT_HEALTHY  ,IND_TOPIC_FILE_DWNLD ,IND_TOPIC_FIND_CLINIC  ,IND_TOPIC_FIND_DENTIST ,IND_TOPIC_FIND_DENTAL_SPECLST  ,IND_TOPIC_FIND_DOCTOR  ,IND_TOPIC_FIND_MEDICAL_SPECLST ,IND_TOPIC_FIND_HEALTH_CLUB ,IND_TOPIC_FIND_HOSPITAL  ,IND_TOPIC_FIND_PHARMACY  ,IND_TOPIC_FIND_PROVIDER  ,IND_TOPIC_FIND_URGENT_CARE ,IND_TOPIC_FITNESS_DEVICE ,IND_TOPIC_FITNESS_EXERCS ,IND_TOPIC_FITNESS_CNTR ,IND_TOPIC_GO365_ACTVTYS  ,IND_TOPIC_FORGOT_PASSWD  ,IND_TOPIC_GRIEVANCE_APPEAL ,IND_TOPIC_HEALTHY_FOOD ,IND_TOPIC_HLTH_WELL_BEING  ,IND_TOPIC_HLTH_WELLNESS  ,IND_TOPIC_HLTH_ASMT_RESULT ,IND_TOPIC_HLTH_ASMT  ,IND_TOPIC_GO365_FORMS  ,IND_TOPIC_ID_CARD  ,IND_TOPIC_INDIV_PROD ,IND_TOPIC_INVOICE  ,IND_TOPIC_MAIL_DELIVERY  ,IND_TOPIC_MANAGE_ACCESS  ,IND_TOPIC_MRKTPNT_LOCATION ,IND_TOPIC_MED_CABINET  ,IND_TOPIC_MEDICAL_RECDS  ,IND_TOPIC_MENTAL_HLTH  ,IND_TOPIC_MSG_DETAIL ,IND_TOPIC_MY_GOAL  ,IND_TOPIC_MY_PRESCRIPTIONS ,IND_TOPIC_ORDER_CONFIRMATION ,IND_TOPIC_ORDER_HISTORY  ,IND_TOPIC_ORDER_STATUS ,IND_TOPIC_PAYMENT  ,IND_TOPIC_PAY_BILL ,IND_TOPIC_PCP  ,IND_TOPIC_PHARM_SPCLTY ,IND_TOPIC_PHARM_TOOLS  ,IND_TOPIC_PRODCTS_SRVCS  ,IND_TOPIC_QUIT_SMOKING ,IND_TOPIC_QUOTE  ,IND_TOPIC_RECD_MSG ,IND_TOPIC_REFILL ,IND_TOPIC_REFERRAL ,IND_TOPIC_REGISTRATION ,IND_TOPIC_RESET_PASSWD ,IND_TOPIC_RTRV_USERNAME  ,IND_TOPIC_REWARDS_MALL ,IND_TOPIC_REMINDER ,IND_TOPIC_RXCALCULATOR ,IND_TOPIC_RX_PRICING ,IND_TOPIC_RX_TOOLS ,IND_TOPIC_SWITCH_RX  ,IND_TOPIC_SALESFORCE_CHAT  ,IND_TOPIC_SMART_SMRY ,IND_TOPIC_SPANISH  ,IND_TOPIC_SPENDING_CLAIMS  ,IND_TOPIC_STARTWITHHEALTHY ,IND_TOPIC_VITAMIN  ,CNT_TOPICS

FROM
    CA_DIGITAL.WEB_ACTIVE_MBR_MTH
WHERE
    MBR_PERS_GEN_KEY in
        (SELECT DISTINCT
            MBR_PERS_GEN_KEY
        FROM
            CA_RPT.CON_DSH_PTOTRADMAIL_UPD1
        )
"""

dataset = datautils.doquery(mycursor,myquery)

# Column names
col_names = datautils.resultColumnNames(mycursor)
col_names

# Convert query to a dataframe
digital_data4 = pd.DataFrame(dataset,columns = col_names)

# Close Cursor
mycursor.close()

# Reshape data
# Subset data
dd = digital_data4
# Select data 
topic = dd.drop(['CRMTRC_YR_MTH'],axis=1)

# Correlation matrix 
graph = topic.iloc[:,0:30]
corrmat = graph.corr()
f, ax = plt.subplots(figsize=(12, 9))
sns.heatmap(corrmat, square=True)

print('Member Count:' ,topic.MBR_PERS_GEN_KEY.nunique())
topic.shape

topic.sum().sort_values(ascending=False).head(12)

# Count of DISTINCT usage by OS LOD:MBR_PERS_GEN_KEY
for i in range(0,(len(topic.columns)-1)):
    print(topic.iloc[:,i+1].name,':  '\
          ,'COUNT:',sum(topic.groupby('MBR_PERS_GEN_KEY').sum().iloc[:,i] >= 1) \
          ,'PCT:',round(sum(topic.groupby('MBR_PERS_GEN_KEY').sum().iloc[:,i] >= 1)/topic.MBR_PERS_GEN_KEY.nunique()*100),'%' )

## Two across all features combination
# sns.set()
# cols = ['CNT_WEB_SESSIONS','CNT_PAGE_VIEW','DURATION_MINUTES']
# sns.pairplot(digital_data[cols], size=3)






## <a id='6'>Pharmacy Data: Unengaged Skeptical Control Seekers</a>
<a href='#0'>Back to top</a>

Getting a bit more records in this dataset vs the original dataset. Need to see where that difference is coming from.
Since this is just eda, I'm not too worried about it

**_Could be that this dataset includes all unengaged members. If we filter down to SCS, it might match up_**


<a id='6.0'></a>**Read in Flatfiles: mbr_uniq_seg_rx_data_pull.csv**

path = ''
filename = 'mbr_uniq_seg_rx_data_pull.csv'
filepath = f'{path}{filename}'
print(filepath)

mbr_uniq = pd.read_csv(filepath,header=0)

list(mbr_uniq)

<a id='1.3'></a>**Read in Flatfiles: mth_rxclm_data_ref_mbr_uniq.csv** 

# Data path
path = ''
filename = 'mth_rxclm_data_ref_mbr_uniq.csv'
filepath = f'{path}{filename}'
print(filepath)

rxclm = pd.read_csv(filepath,header=0)

list(rxclm.columns)

**Scrub Data**

# Dedupe data
rxclm = rxclm.drop_duplicates()

rxclm[rxclm.MBR_PERS_GEN_KEY == 8883004382618].head()

rxclm.head(15)

**Data Join: mbr_uniq_seg_rx_data_pull & mth_rxclm_data_ref_mbr_uniq**

pharm = pd.merge(mbr_uniq,rxclm, how='left', on=['MBR_PERS_GEN_KEY'])

list(pharm.columns)

# Breakout of records
print('\033[1m'+'DATASET','(ROWS, COLUMNS)'+'\033[0m')
print('mbr_uniq',mbr_uniq.shape)
print('rxclm',rxclm.shape)
print('result',pharm.shape)

# Save CSV to file
# pharm.to_csv('mbr_uniq_seg_rx_data_pull_append_rxclm_data.csv', na_rep='NULL')





<a id='6.1'></a> **Pharmacy of Choice**

Some members have multiple records because they could have used multiple pharmacy locations.

_Ranking of Pharmacy of Unengaged Members with Humana after data is normalized to exclude missing data: 
1. Walgreens: 30%
2. CVS: 24%
3. Walmart: 23%
4. Grocery Store: 15%


# Reshape data
# Subset data
ph = pharm
cats = ['MBR_PERS_GEN_KEY'
#        ,'SEGMENT_ID','SEX_CD'
#        ,'MAIL_ORDER_LAST_USED_DATE','RIGHT_SOURCE_LAST_USED_DATE','RIGHT_SRCE_SPCL_LAST_USED_DATE','HUM_OWN_PHAR_LAST_USED_DATE','WALMART_LAST_USED_DATE'
        ,'IND_PH_SPECIALTY','IND_PH_GROCERY_STORE','IND_PH_RIGHTSRC','IND_PH_RIGHTSRC_SPCL'
        ,'IND_PH_WALMART','IND_PH_KMART','IND_PH_TARGET','IND_PH_COSTCO','IND_PH_WALGREEN','IND_PH_CVS','IND_PH_RITEAID','IND_PH_MEDICINE_SHOPPE','IND_PH_SAFEWAY','IND_PH_CAREMARK']
# Select data 
rx = ph[cats]

# Dedupe data
rx = rx.drop_duplicates()

print('Member Count:' ,rx.MBR_PERS_GEN_KEY.nunique())

rx[rx.MBR_PERS_GEN_KEY == 6729004553622].iloc[:,:]

# Count of DISTINCT usage by OS LOD:MBR_PERS_GEN_KEY
for i in range(0,(len(rx.columns)-1)):
    print(rx.iloc[:,i+1].name,':  ','COUNT:' \
          ,sum(rx.groupby('MBR_PERS_GEN_KEY').sum().iloc[:,i] >= 1) \
          ,'PCT:',round(sum(rx.groupby('MBR_PERS_GEN_KEY').sum().iloc[:,i] >= 1)/rx.MBR_PERS_GEN_KEY.nunique()*100),'%')