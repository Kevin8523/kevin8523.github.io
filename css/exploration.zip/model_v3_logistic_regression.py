import sys
print(sys.executable)
print(sys.version)

# Preprocessing
import pandas as pd
import numpy as np
import random
# import cx_Oracle as cxo
# import datautils

# Visualizations
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
import seaborn as sns
from pandas.tools.plotting import scatter_matrix
import warnings
warnings.filterwarnings("ignore")
# %matplotlib qt
%matplotlib inline

# Model
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import ExtraTreesClassifier
from xgboost import XGBClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import f1_score
from sklearn.metrics import roc_auc_score, roc_curve, auc
from sklearn.utils import resample
import statsmodels.api as sm
from statsmodels.stats.outliers_influence import variance_inflation_factor
# from scipy.stats import kstest
# from scipy.stats import ks_2samp
# from imblearn_over_sampling import SMOTE # conda install -c conda-forge imbalanced-learn

### MAPD NONHP

**READ IN FLATFILE**

# PATH
path = ''
file = 'allunimapd.csv'
filepath = f'{path}{file}'
print(filepath)
# Read Flatfile
target = pd.read_csv(filepath, header=0,
                    dtype={'SDR_PERSON_ID': np.int64,
                           'MBR_PERS_GEN_KEY': str,
                           'target': np.int64,})

target.target.value_counts()
#print(target.target.sum())

# Columns to reading in # 15:1 or 20:1 ratio
# col_names = ['MBR_PERS_GEN_KEY']
# mapd_nohp = pd.read_csv('mapd_nohp.csv', header = 0, usecols = col_names) #nrows=5 ; chunksize=1000
random.seed(21)
filename = "mapd_nohp.csv"
n = sum(1 for line in open(filename)) - 1 #number of records in file (excludes header)
s = 100000 #desired sample size
skip = sorted(random.sample(range(1,n+1),n-s)) #the 0-indexed header will not be included in the skip list
mapd_nohp = pd.read_csv(filename, skiprows=skip)

**QUICK LOOK AT THE DATA**

# Shape of the data
print('\033[1m'+'DATASET','(ROWS, COLUMNS)'+'\033[0m')
print('dataset',mapd_nohp.shape,'\n')

# Class Distribution
print('\033[1m'+'BREAKOUT OF CLASSIFICATION','(0, 1)'+'\033[0m')
print(mapd_nohp.groupby('target').size(),'\n')
print('\033[1m'+'% OF 1s'+'\033[0m')
print('PCT:',2482/(17518+2482))

**FEATURE ENGINEERING**

Probably should do the feature engineering and feature selection AFTER splitting the dataset to avoid any data leakage, but since I am trying to recreate JP's model, I am just going to use his inputs.

Need to ask JP about the BIN values it is replaced on

# Create BIN_CMYS for MAPD NonHp Users
# if CMYS in ('','6' ) then BIN_CMYS = 0.4505444646 ;
# if CMYS in ('4','5','3','0','1','2','7' ) then BIN_CMYS = 0.5170857511 ;
list1 = [6,] # Includes Null
list2 = [4,5,3,0,1,2,7]
# List Comprehension
mapd_nohp['BIN_CMYS'] = mapd_nohp['CMYS']
mapd_nohp['BIN_CMYS']= [0.5170857511 if i in list2 else 0.4505444646 for i in mapd_nohp.BIN_CMYS]
# mapd_nohp['BIN_CMYS'] = mapd_nohp.CMYS.replace([0,3],[0.4413173653,0.5146579805]) # Single Value
mapd_nohp[['CMYS','BIN_CMYS']].head(5)

# Create BIN_MOBPLUS for MAPD NonHp Users
# if MOBPLUS in ('U','','P' ) then BIN_MOBPLUS = 0.4441558442 ;
# if MOBPLUS in ('S' ) then BIN_MOBPLUS = 0.4991408935 ;
# if MOBPLUS in ('M' ) then BIN_MOBPLUS = 0.5356564019 ;
list1 = ['U','P'] # Includes Null
list2 = ['S']
list3 = ['M']
# List Comprehension
mapd_nohp['BIN_MOBPLUS'] = mapd_nohp['MOBPLUS']
mapd_nohp['BIN_MOBPLUS']= [0.5356564019 if i in list3 else 0.4991408935 if i in list2 else 0.4441558442 for i in mapd_nohp.BIN_MOBPLUS]
mapd_nohp[['MOBPLUS','BIN_MOBPLUS']].head()

# Create BIN_mapd_segment for MAPD Hp Users
# if mapd_segment in ('C5','H4','H5','H6','H7','H8','C4','C1' ) then BIN_mapd_segment = 0.4201500536 ;
# if mapd_segment in ('H1','H2','NEW','C2' ) then BIN_mapd_segment = 0.4952707334 ;
# if mapd_segment in ('H3','C7' ) then BIN_mapd_segment = 0.5452914798 ;
# if mapd_segment in ('C3' ) then BIN_mapd_segment = 0.6331168831 

**MODELS**

**BASELINE MODEL: Logisic Regression Model**

# Baseline Model on subset of features to see how the model performs
# Usually try to start with a more interpretable model for a baseline

# Features for the baseline model
final_features = ['BIN_MOBPLUS'
                ,'PDPE'
                ,'RX_CNT_TIER2_12M'
                ,'cnt_cp_vat_12m'
                ,'ind_seg_engaged'
                ,'main_drug_tag_12m'              
                ,'tenure_mbr_cov'
                ,'target']

# Subset to features used for model 
df = mapd_nohp[final_features]
df = df.fillna(0)
X = df.iloc[:,:-1].values
y = df.iloc[:,-1].values

# Split to training & test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.3,
                                                    random_state = 21,
                                                    stratify = y,
                                                    shuffle = True)

# Feature Scaling
sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)

# Class Distribution for the training and test set
print('TRAIN')
print(np.unique(y_train))
print(np.bincount(y_train))
print('PCT',(y_train==1).sum()/(y_train.shape[0])*100)
print('\n','TEST')
print(np.unique(y_test))
print(np.bincount(y_test))
print('PCT',(y_test==1).sum()/(y_test.shape[0])*100)

# Fit Logistic Regression Classifier to Training Data
# C= 1/lambda: 
# Small C - More regularization aka weights go to 0 (simple models which underfit the data)
# Large C - Less regularization (Model is allowed to increase its complexity therefore overfit the data)
classifier = LogisticRegression(penalty='l1',C=100.0,random_state=21) # Smaller C: More regularization aka weights go to 0
classifier.fit(X_train_std,y_train)

# Probabilities
y_probas = classifier.predict_proba(X_test_std[:, :]) #  Probabilites for first 10 records
# classifier.predict(X_test_std[:10, :]) # Predict on n records
# classifier.predict(X_test_std[0, :].reshape(1,-1)) # Predict on 1 record

# Predict on Test Set
y_pred = classifier.predict(X_test_std)

y_test

# Missclassified
(y_test != y_pred).sum()

classifier.score(X_test_std,y_test)

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
print('[[True Negative, False Positive]')
print('[False Negative, True Positive]]')
print(cm)

# Recall
# Number of correctly predicted positives / total number of positives
print('Recall: %.3f' % recall_score(y_true=y_test, y_pred=y_pred))
# print('Precision: %.3f' % precision_score(y_true=y_test, y_pred=y_pred))
# print('F1: %.3f' % f1_score(y_true=y_test, y_pred=y_pred))

The model just predicted 0 on the whole dataset to get the 87.5% accuracy. Since this is an imbalanced dataset, we will need to do some changes to the model like changing the model evaultion, upsampling or downsampling the dataset.

print('ROC AUC: %.3f' % roc_auc_score(y_true=y_test, y_score=y_probas[:,1]))
print('Accuracy: %.3f' % accuracy_score(y_true=y_test, y_pred=y_pred))





**MODEL ITERATION 2: Upsampling Minority Class - Logisic Regression Model 2**

# Class imbalance techniques
# assign larger penalty to wrong predictions on the minority class
# upsampling the minority class
# downsampling the majority class
# generation of synthetic training samples

# One way to deal with imbalanced class proportions during model fitting 
# is to assign a larger penalty to wrong predictions on the minority class. 
# Via scikit-learn, adjusting such a penalty is as convenient as setting the 
# class_weight parameter to class_weight='balanced', which is implemented for 
# most classifiers.

# upsampling the minority class by drawing new samples from the dataset 
# with replacement

# Subset to features used for model 
df = mapd_nohp[final_features]
df = df.fillna(0)
X = df.iloc[:,:-1].values
y = df.iloc[:,-1].values

# Split to training & test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.3,
                                                    random_state = 21,
                                                    shuffle = True)

# Class Distribution for the training and test set
print('TRAIN')
print(np.unique(y_train))
print(np.bincount(y_train))
print('PCT',(y_train==1).sum()/(y_train.shape[0])*100)
print('\n','TEST')
print(np.unique(y_test))
print(np.bincount(y_test))
print('PCT',(y_test==1).sum()/(y_test.shape[0])*100)

# Before Resampling
print('Number of class 1 samples before:',X_train[y_train == 1].shape[0])

# Upsample dataset
X_sampled, y_sampled = resample(X_train[y_train == 1], y_train[y_train == 1]
                                    ,n_samples = X_train[y_train == 0].shape[0]
                                    ,replace = True, random_state=21)

# After Resampling
print('Number of class 1 samples after:',X_sampled.shape[0])

# Balanced Dataset
X_train = np.vstack((X_train[y_train == 0], X_sampled))
y_train = np.hstack((y_train[y_train == 0], y_sampled))

# Confirm Upsampling
zero_ = np.zeros(y_train.shape[0]) # Create 0 array
np.mean(zero_ == y_train) * 100 # Class 0 

# Class Distribution for the training and test set
print('TRAIN')
print(np.unique(y_train))
print(np.bincount(y_train))
print('PCT',(y_train==1).sum()/(y_train.shape[0])*100)
print('\n','TEST')
print(np.unique(y_test))
print(np.bincount(y_test))
print('PCT',(y_test==1).sum()/(y_test.shape[0])*100)

# Feature Scaling
sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)

# Fit Logistic Regression Classifier to Training Data
# C= 1/lambda: 
# Small C - More regularization aka weights go to 0 (simple models which underfit the data)
# Large C - Less regularization (Model is allowed to increase its complexity therefore overfit the data)
classifier = LogisticRegression(penalty='l1',C=100.0,random_state=21) # Smaller C: More regularization aka weights go to 0
classifier.fit(X_train_std,y_train)

# Probabilities
y_probas = classifier.predict_proba(X_test_std[:, :])
# classifier.predict(X_test_std[:10, :]) # Predict on n records
# classifier.predict(X_test_std[0, :].reshape(1,-1)) # Predict on 1 record

# Predict on Test Set
y_pred = classifier.predict(X_test_std)

# Missclassified
(y_test != y_pred).sum()

# Score: Correct predictions / Total 
classifier.score(X_test_std,y_test)

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
print('Negative Cases','[[True Negative, False Positive]')
print('Positive Cases','[False Negative, True Positive]]')
print(cm)

# Recall (True Positive / Positive Cases): True Positive Rate
print('Recall: %.3f' % recall_score(y_true=y_test, y_pred=y_pred))
# print('Accuracy: %.3f' % accuracy_score(y_true=y_test, y_pred=y_pred))
# print('Precision: %.3f' % precision_score(y_true=y_test, y_pred=y_pred))

print('ROC AUC: %.3f' % roc_auc_score(y_true=y_test, y_score=y_probas[:,1]))
#print('Accuracy: %.3f' % accuracy_score(y_true=y_test, y_pred=y_labels))

# False Postive Rate and True Positive Rate for all thresholds 
fpr, tpr, threshold = roc_curve(y_test, y_probas[:,1])
roc_auc = auc(fpr,tpr)
roc_auc

print('FALSE POSITIVE RATE =','FP / (FP+TN)')
print('TRUE POSITIVE RATE =','TP / (TP+FN)')

plt.title('Receiver Operating Characteristic')
plt.plot(fpr, tpr, 'b', label = 'AUC = %0.2f' % roc_auc)
plt.legend(loc = 'lower right')
plt.plot([0, 1], [0, 1],'r--')
plt.xlim([0, 1])
plt.ylim([0, 1])
plt.ylabel('True Positive Rate')
plt.xlabel('False Positive Rate')
plt.show()

# Compare with training set
y_pred_train = classifier.predict(X_train_std)

# Missclassified
(y_train != y_pred_train).sum()

# Score: Correct predictions / Total 
classifier.score(X_train_std,y_train)

# Confusion Matrix
cm_train = confusion_matrix(y_train, y_pred_train)
print('Negative Cases','[[True Negative, False Positive]')
print('Positive Cases','[False Negative, True Positive]]')
print(cm_train)

# Recall (True Positive / Positive Cases): True Positive Rate
print('Recall: %.3f' % recall_score(y_true=y_train, y_pred=y_pred_train))
# print('Accuracy: %.3f' % accuracy_score(y_true=y_test, y_pred=y_pred))
# print('Precision: %.3f' % precision_score(y_true=y_test, y_pred=y_pred))





**MODEL ITERATION 3: Downsampling Majority Class - Logisic Regression Model 3**

# Since we have alot of data that is going unused, using downsampling makes
# a lot of sense for the class imbalance

# downsampling the majority class

**Pre-Processing**

# Features for the baseline model
final_features = ['MBR_PERS_GEN_KEY'
                ,'BIN_MOBPLUS'
                ,'PDPE'
                ,'RX_CNT_TIER2_12M'
                ,'cnt_cp_vat_12m'
                ,'ind_seg_engaged'
                ,'main_drug_tag_12m'              
                ,'tenure_mbr_cov'
                ,'target']

# Subset to features used for model
df = mapd_nohp[final_features]
df = df.fillna(0)
X = df.iloc[:,:-1].values
y = df.iloc[:,-1].values

# Split to training & test
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.3,
                                                    random_state = 21,
                                                    shuffle = True)

# Class Distribution for the training and test set
print('TRAIN')
print(np.unique(y_train))
print(np.bincount(y_train))
print('PCT',(y_train==1).sum()/(y_train.shape[0])*100)
print('\n','TEST')
print(np.unique(y_test))
print(np.bincount(y_test))
print('PCT',(y_test==1).sum()/(y_test.shape[0])*100)

# Before Resampling
print('Number of class 1 samples before:',X_train[y_train == 0].shape[0])

# Downsample dataset
X_sampled, y_sampled = resample(X_train[y_train == 0], y_train[y_train == 0]
                                    ,n_samples = X_train[y_train == 1].shape[0]
                                    ,replace = True, random_state=21)

# After Resampling
print('Number of class 0 samples after:',X_sampled.shape[0])

# Balanced Dataset
X_train = np.vstack((X_train[y_train == 1], X_sampled))
y_train = np.hstack((y_train[y_train == 1], y_sampled))

# Confirm Downsample
zero_ = np.ones(y_train.shape[0]) # Create 0 array
np.mean(zero_ == y_train) * 100 # Class 0 

# Class Distribution for the training and test set
print('TRAIN')
print(np.unique(y_train))
print(np.bincount(y_train))
print('PCT',(y_train==1).sum()/(y_train.shape[0])*100)
print('\n','TEST')
print(np.unique(y_test))
print(np.bincount(y_test))
print('PCT',(y_test==1).sum()/(y_test.shape[0])*100)

train = X_train
test = X_test
X_train = X_train[:,1:]
X_test = X_test[:,1:]
print(X_train.shape)
print(X_test.shape)

# Feature Scaling
sc = StandardScaler()
sc.fit(X_train)
X_train_std = sc.transform(X_train)
X_test_std = sc.transform(X_test)

**Classifier**

# Fit Logistic Regression Classifier to Training Data: l1:LAD, L2:LSE
# C= 1/lambda: 
# Small C - More regularization aka weights go to 0 (simple models which underfit the data)
# Large C - Less regularization (Model is allowed to increase its complexity therefore overfit the data)
classifier = LogisticRegression(penalty='l2',C=10.0, fit_intercept=True) 
classifier.fit(X_train_std,y_train)

# Probabilities
y_probas = classifier.predict_proba(X_test_std[:, :])
# classifier.predict(X_test_std[:10, :]) # Predict on n records
# classifier.predict(X_test_std[0, :].reshape(1,-1)) # Predict on 1 record

# Predict on Test Set
y_pred = classifier.predict(X_test_std)

# Missclassified
(y_test != y_pred).sum()

# Score: Correct predictions / Total 
classifier.score(X_test_std,y_test)

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
print('Negative Cases','[[True Negative, False Positive]')
print('Positive Cases','[False Negative, True Positive]]')
print(cm)

# Recall (True Positive / Positive Cases): True Positive Rate
print('Recall: %.3f' % recall_score(y_true=y_test, y_pred=y_pred))
# print('Accuracy: %.3f' % accuracy_score(y_true=y_test, y_pred=y_pred))
# print('Precision: %.3f' % precision_score(y_true=y_test, y_pred=y_pred))

print('ROC AUC: %.3f' % roc_auc_score(y_true=y_test, y_score=y_probas[:,1]))
#print('Accuracy: %.3f' % accuracy_score(y_true=y_test, y_pred=y_labels))

# False Postive Rate and True Positive Rate for all thresholds 
fpr, tpr, threshold = roc_curve(y_test, y_probas[:,1])
roc_auc = auc(fpr,tpr)
roc_auc

print('FALSE POSITIVE RATE =','FP / (FP+TN)')
print('TRUE POSITIVE RATE =','TP / (TP+FN)')

plt.title('Receiver Operating Characteristic')
plt.plot(fpr, tpr, 'b', label = 'AUC = %0.2f' % roc_auc)
plt.legend(loc = 'lower right')
plt.plot([0, 1], [0, 1],'r--')
plt.xlim([0, 1])
plt.ylim([0, 1])
plt.ylabel('True Positive Rate')
plt.xlabel('False Positive Rate')
plt.show()
# import scikitplot as skplt
# skplt.metrics.plot_cumulative_gain(y_test, y_probas)
# plt.show()

# ROC Curve Cutoff
print(np.argmax(tpr - fpr))
print(threshold[np.argmax(tpr - fpr)])

**Coefficients**

# Coefficients by Variables
print(final_features[1:8])
print(classifier.coef_)
# sigmoid( dot([val1, val2], classifier.coef_) + classifier.intercept_ ) 

# Coefficents # Assumes b=0 ==> Add the Intercept
X_train_std_const = sm.add_constant(X_train_std) # Add constant
model = sm.Logit(y_train,X_train_std_const)
result = model.fit()
# result = model.fit_regularized(method = 'l1')
result.summary()

# Calculate the odds
# One unit increase in BIN_MOBPLUS (ind_seg_engage)
# we expect the odds of joining to increase by almost 7.4%(54% or 1.5 times more), 
# holding everything else constant 
np.exp(result.params)

**VIF**

print("['intercept',",final_features[1:8])
[variance_inflation_factor(X_train_std_const,i) for i in range(X_train_std_const.shape[1])]

**Exploring Results**

# Merge results back with Test Dataset
colnames = ['MBR_PERS_GEN_KEY'
            ,'BIN_MOBPLUS'
            ,'PDPE'
            ,'RX_CNT_TIER2_12M'
            ,'cnt_cp_vat_12m'
            ,'ind_seg_engaged'
            ,'main_drug_tag_12m'              
            ,'tenure_mbr_cov']

results = pd.DataFrame(test,columns = colnames)
results['MBR_PERS_GEN_KEY'] = test[:,0].astype(np.int64)
results['y_actual'] = y_test
results['y_probas'] = y_probas[:,1]
results['y_preds'] = y_pred
results.head(5)

# Results sorted by Probability Predicted
results['decile']= pd.cut(results.y_probas, 10
       ,labels=['Decile 9','Decile 8','Decile 7','Decile 6','Decile 5'
               ,'Decile 4','Decile 3','Decile 2','Decile 1','Decile 0'])
results_sort = results.sort_values(by='y_probas',ascending=False).reset_index()
results_sort = results_sort.drop(['index'], axis=1)
results_sort.head(5)

**KS Statistic & Gains Chart**

**Test set**

# Results by Decile
decile = pd.cut(results.y_probas, 10
       ,labels=['Decile 9:','Decile 8:','Decile 7:','Decile 6:','Decile 5:'
               ,'Decile 4:','Decile 3:','Decile 2:','Decile 1:','Decile 0:']
      ).value_counts().sort_index(ascending=False)

# Total Actuals by Decile
actual_1 = results_sort.groupby('decile').agg({'y_actual':'sum'}).sort_index(ascending=False)
actual_1 = actual_1.values.reshape(10,)

# Create columns
actual_0 = decile - actual_1
actual_0_cumsum = actual_0.cumsum()/actual_0.sum()
actual_1_cumsum = actual_1.cumsum()/actual_1.sum()
ks = actual_1_cumsum - actual_0_cumsum

# Decile Table
decile_table = decile.to_frame('count')
decile_table['actual_0'] = actual_0
decile_table['actual_1'] = actual_1
decile_table['pct_population'] = decile/results.y_probas.count()
decile_table['pct_population2'] = decile_table['pct_population']*100
decile_table['actual_0_cumsum'] = actual_0_cumsum
decile_table['actual_1_cumsum'] = actual_1_cumsum
decile_table['ks'] = ks
print(decile_table)

decile_table.reset_index().plot(y=['actual_1_cumsum','actual_0_cumsum'])
plt.title('Kolomogorov Smirnov chart')
plt.legend(loc = 'lower right')
# plt.plot([0, 9], [0, 1],'r--')
plt.ylabel('Cumulative % of Population')
plt.xlabel('Deciles')
plt.show()
# # import scikitplot as skplt
# # skplt.metrics.plot_cumulative_gain(y_test, y_probas)
# # plt.show()

# Gains Chart
pct_1 = actual_1 / actual_1.sum()
print('\033[1m'+'Lift At Decile','(Lift)'+'\033[0m')
print(pct_1 / decile_table['pct_population'],'\n')
print('\033[1m'+'Total Lift','(Lift)'+'\033[0m')
print(pct_1.cumsum() / decile_table['pct_population'].cumsum())

**Training Set**

_PLEASE NOTE THAT THIS DATASET IS THE DOWNSAMPLEDSAMPLED DATA, TO GET THE ORIGINAL TRAINING SET, RUN THE ABOVE CODE THEN COME BACK HERE. THE KS STATISTIC HAPPENS TO END UP BEING_ 

- NONSAMPLED TRAINING SET: 30.2830
- DOWNSAMPLED TRAINING SET: 30.4128

# Compare with training set
y_probas_train = classifier.predict_proba(X_train_std[:, :])
y_pred_train = classifier.predict(X_train_std)

# Missclassified
print('Misclassified:',(y_train != y_pred_train).sum())

# Score: Correct predictions / Total 
print('Accuracy:',classifier.score(X_train_std,y_train),'\n')

# Confusion Matrix
cm_train = confusion_matrix(y_train, y_pred_train)
print('Negative Cases','[[True Negative, False Positive]')
print('Positive Cases','[False Negative, True Positive]]')
print(cm_train)

# Recall (True Positive / Positive Cases): True Positive Rate
print('Recall: %.3f' % recall_score(y_true=y_train, y_pred=y_pred_train))
# print('Accuracy: %.3f' % accuracy_score(y_true=y_test, y_pred=y_pred))
# print('Precision: %.3f' % precision_score(y_true=y_test, y_pred=y_pred))

# Merge results back with Train Dataset
colnames = ['MBR_PERS_GEN_KEY'
            ,'BIN_MOBPLUS'
            ,'PDPE'
            ,'RX_CNT_TIER2_12M'
            ,'cnt_cp_vat_12m'
            ,'ind_seg_engaged'
            ,'main_drug_tag_12m'              
            ,'tenure_mbr_cov']

results = pd.DataFrame(train,columns = colnames)
results['MBR_PERS_GEN_KEY'] = train[:,0].astype(np.int64)
results['y_actual'] = y_train
results['y_probas'] = y_probas_train[:,1]
results['y_preds'] = y_pred_train
results.head(5)

# Results sorted by Probability Predicted
results['decile']= pd.cut(results.y_probas, 10
       ,labels=['Decile 9','Decile 8','Decile 7','Decile 6','Decile 5'
               ,'Decile 4','Decile 3','Decile 2','Decile 1','Decile 0'])
results_sort = results.sort_values(by='y_probas',ascending=False).reset_index()
results_sort = results_sort.drop(['index'], axis=1)
results_sort.head(5)

# Results by Decile
decile = pd.cut(results.y_probas, 10
       ,labels=['Decile 9:','Decile 8:','Decile 7:','Decile 6:','Decile 5:'
               ,'Decile 4:','Decile 3:','Decile 2:','Decile 1:','Decile 0:']
      ).value_counts().sort_index(ascending=False)

# Total Actuals by Decile
actual_1 = results_sort.groupby('decile').agg({'y_actual':'sum'}).sort_index(ascending=False)
actual_1 = actual_1.values.reshape(10,)

# Create columns
actual_0 = decile - actual_1
actual_0_cumsum = actual_0.cumsum()/actual_0.sum()
actual_1_cumsum = actual_1.cumsum()/actual_1.sum()
ks = actual_1_cumsum - actual_0_cumsum

# Decile Table
decile_table = decile.to_frame('count')
decile_table['actual_0'] = actual_0
decile_table['actual_1'] = actual_1
decile_table['pct_population'] = decile/results.y_probas.count()
decile_table['pct_population2'] = decile_table['pct_population']*100
decile_table['actual_0_cumsum'] = actual_0_cumsum
decile_table['actual_1_cumsum'] = actual_1_cumsum
decile_table['ks'] = ks
print(decile_table)

decile_table.reset_index().plot(y=['actual_1_cumsum','actual_0_cumsum'])
plt.title('Kolomogorov Smirnov chart')
plt.legend(loc = 'lower right')
# plt.plot([0, 9], [0, 1],'r--')
plt.ylabel('Cumulative % of Population')
plt.xlabel('Deciles')
plt.show()
# # import scikitplot as skplt
# # skplt.metrics.plot_cumulative_gain(y_test, y_probas)
# # plt.show()

# Gains Chart
pct_1 = actual_1 / actual_1.sum()
print('\033[1m'+'Lift At Decile','(Lift)'+'\033[0m')
print(pct_1 / decile_table['pct_population'],'\n')
print('\033[1m'+'Total Lift','(Lift)'+'\033[0m')
print(pct_1.cumsum() / decile_table['pct_population'].cumsum())

**K-S Difference**

Training = 0.304128
Test = 0.299325
print((Training - Test)/(Training) * 100,'%')

# Kfolds CV
# from sklearn.model_selection import KFold
# from sklearn.model_selection import cross_val_score
# kfold = KFold(n_splits=10, random_state=21)
# scoring = 'roc_auc'
# results = cross_val_score(classifier, X_test, y_test, cv=kfold, scoring=scoring)
# print("AUC: %.3f (%.3f)" % (results.mean(), results.std()))

**Classifier on Full Dataset / New Population**

# Bring in Compeletely New Dataset
random.seed(31)
filename = "mapd_nohp.csv"
n = sum(1 for line in open(filename)) - 1 #number of records in file (excludes header)
s = 50000 #desired sample size
skip = sorted(random.sample(range(1,n+1),n-s)) #the 0-indexed header will not be included in the skip list
mapd_nohp = pd.read_csv(filename, skiprows=skip)


# Feature Engineering
# Create BIN_CMYS for MAPD NonHp Users
list1 = [6,] # Includes Null
list2 = [4,5,3,0,1,2,7]
# List Comprehension
mapd_nohp['BIN_CMYS'] = mapd_nohp['CMYS']
mapd_nohp['BIN_CMYS']= [0.5170857511 if i in list2 else 0.4505444646 for i in mapd_nohp.BIN_CMYS]
mapd_nohp[['CMYS','BIN_CMYS']].head(5)
# Create BIN_MOBPLUS for MAPD NonHp Users
list1 = ['U','P'] # Includes Null
list2 = ['S']
list3 = ['M']
# List Comprehension
mapd_nohp['BIN_MOBPLUS'] = mapd_nohp['MOBPLUS']
mapd_nohp['BIN_MOBPLUS']= [0.5356564019 if i in list3 else 0.4991408935 if i in list2 else 0.4441558442 for i in mapd_nohp.BIN_MOBPLUS]
mapd_nohp[['MOBPLUS','BIN_MOBPLUS']].head()



# Features for the baseline model
final_features = ['BIN_MOBPLUS'
                ,'PDPE'
                ,'RX_CNT_TIER2_12M'
                ,'cnt_cp_vat_12m'
                ,'ind_seg_engaged'
                ,'main_drug_tag_12m'              
                ,'tenure_mbr_cov'
                ,'target']

# Subset to features used for model
df = mapd_nohp[final_features]
df = df.fillna(0)
X = df.iloc[:,:-1].values
y = df.iloc[:,-1].values

# Standardize data
X_std = sc.transform(X)

# Probabilities
y_probas = classifier.predict_proba(X_std[:, :])

# Predict on Test Set
y_pred = classifier.predict(X_std)

# Missclassified
print('Missclassified',(y != y_pred).sum())

# Score: Correct predictions / Total 
print('Accuracy:',classifier.score(X,y))

# Confusion Matrix
cm = confusion_matrix(y, y_pred)
print('Negative Cases','[[True Negative, False Positive]')
print('Positive Cases','[False Negative, True Positive]]')
print(cm)

# Recall (True Positive / Positive Cases): True Positive Rate
print('Recall: %.3f' % recall_score(y_true=y, y_pred=y_pred))
# print('Accuracy: %.3f' % accuracy_score(y_true=y_test, y_pred=y_pred))
# print('Precision: %.3f' % precision_score(y_true=y_test, y_pred=y_pred))

print('ROC AUC: %.3f' % roc_auc_score(y_true=y, y_score=y_probas[:,1]))
#print('Accuracy: %.3f' % accuracy_score(y_true=y_test, y_pred=y_labels))

import statsmodels.formula.api as smf

def forward_selected(data, response):
    """Linear model designed by forward selection.

    Parameters:
    -----------
    data : pandas DataFrame with all possible predictors and response

    response: string, name of response column in data

    Returns:
    --------
    model: an "optimal" fitted statsmodels linear model
           with an intercept
           selected by forward selection
           evaluated by adjusted R-squared
    """
    remaining = set(data.columns)
    remaining.remove(response)
    selected = []
    current_score, best_new_score = 0.0, 0.0
    while remaining and current_score == best_new_score:
        scores_with_candidates = []
        for candidate in remaining:
            formula = "{} ~ {} + 1".format(response,
                                           ' + '.join(selected + [candidate]))
            score = smf.ols(formula, data).fit().rsquared_adj
            scores_with_candidates.append((score, candidate))
        scores_with_candidates.sort()
        best_new_score, best_candidate = scores_with_candidates.pop()
        if current_score < best_new_score:
            remaining.remove(best_candidate)
            selected.append(best_candidate)
            current_score = best_new_score
    formula = "{} ~ {} + 1".format(response,
                                   ' + '.join(selected))
    model = smf.ols(formula, data).fit()
    return model

import pandas as pd

url = "http://data.princeton.edu/wws509/datasets/salary.dat"
data = pd.read_csv(url, sep='\\s+')

model = forward_selected(data, 'sl')

print model.model.formula
# sl ~ rk + yr + 1

print model.rsquared_adj
# 0.835190760538