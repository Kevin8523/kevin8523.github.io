# Databricks notebook source
# MAGIC %md # Feature Engineering
# MAGIC 
# MAGIC ### Requirements
# MAGIC 
# MAGIC 1. You have access to data and workspaces within Humana's Microsoft Azure cloud in a **Pre-Production** resource group.
# MAGIC 2. A Databricks Workspace exists with at least one Cluster created to attach your notebook to compute resources.
# MAGIC 3. A Key Vault and DB Secret Scope have been created for use with your Databricks Workspace.
# MAGIC 4. Necessary secret keys exist in the Key Vault associated with your Databricks Workspace.
# MAGIC 
# MAGIC ### Goals  
# MAGIC 1. Define a cohort of members for your predictive model to score
# MAGIC 2. Define a value for your model target for each selected member
# MAGIC 
# MAGIC ### Standard Conventions
# MAGIC 1. Coding standards in compliance with PEP8
# MAGIC 2. Exception: Constants follow same format as variable names
# MAGIC 3. All items the user is expected to change within existing code will appear in ALL_CAPS_WITH_UNDERSCORES

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md ### Initialization Steps  
# MAGIC 1. Load Packages  
# MAGIC 2. Display DB Secret Scopes  
# MAGIC 3. Set config parameters for connecting to a storage account

# COMMAND ----------

# Loads Basic Packages
from pyspark.sql.types import *
from pyspark.sql.functions import udf
from pyspark.sql.functions import col
from pyspark.sql import functions as f

# Python Packages
import sys; print('Python Version:',sys.version)
import numpy as np; print("Numpy Version:",np.__version__)
import pandas as pd; print("Pandas Version:",pd.__version__)
import matplotlib.pyplot as plt
import seaborn as sns

import time
from datetime import datetime
import re
from calendar import monthrange
from dateutil.relativedelta import relativedelta
from pyspark.sql.window import Window

# Creates the class needed to return error messages when pre-requisites are not met
class HaltException(Exception): pass

# COMMAND ----------

#Lists names of secret scopes and keys within them that are active for this Databricks Workspace
print("Secret Scopes:")
for x in dbutils.secrets.listScopes():
  print(x.name)
  print ("    Keys Available:")
  for y in dbutils.secrets.list(x.name):
    print ("    " + y.key)

# COMMAND ----------

# Required config settings to enable proper use of Credential PassThrough to connect to storage account
spark.conf.set("fs.azure.account.auth.type", "CustomAccessToken")
spark.conf.set("fs.azure.account.custom.token.provider.class", spark.conf.get("spark.databricks.passthrough.adls.gen2.tokenProviderClassName"))

# MLP storage account
storage_acct_name = "dha0mlp0prod"

# Computed constants
adls_source_path = "abfss://tempdata@" + storage_acct_name + ".dfs.core.windows.net"
adls_raw_path = "abfss://raw@" + storage_acct_name + ".dfs.core.windows.net"
adls_ref_path = "abfss://reference@" + storage_acct_name + ".dfs.core.windows.net"
adls_xformed_path = "abfss://transformed@" + storage_acct_name + ".dfs.core.windows.net"
adls_results_path = "abfss://results@" + storage_acct_name + ".dfs.core.windows.net"

#Use this to specify your write path underneath transformed
target_folder_path = "/lvl1/models/rxe-model-v1/20210131-rxe"

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md ### Load Base Reusable Functions

# COMMAND ----------

# MAGIC %run "/Shared/stdfeatures/ref/Base Functions"

# COMMAND ----------

# MAGIC %md ### Set Parameters
# MAGIC These parameters determine which data to load and how far into the future from the score date you want to include in the feature definitions.  
# MAGIC > **Important!** Any parameters you supplied during your cohort creation should match except for the direction, which should now be "backward".

# COMMAND ----------

# Standard Constants - DO NOT EDIT
fin_prod_non_medr = ['HMOC','ASO','PPO','MCD','IHM','IMV','IND','VIT']   #Non-Medicare LOBs
fin_prod_medr = "MEDR"
pdp_fin_sub_vals = ['MDG','MDI','MDL','HMI']                         # These subcategories identify PDP Plans
src_platform_vals = ['LV','EM','CP']                                 # Standard platforms including Louisville, Metavance and CarePlus
claim_types = ['A','C','E','R']                                      # Limit to key payment_cat_cds including Adjudicated, Completed (Paid) and Encounter
cost_types = ['A','C']                                               # Exclude encounter claims from cost calculations since the reported costs are not reliable
direction = "forward"                                                # Retrieves claims and other standard source data during prediction period only

# COMMAND ----------

#Set projectType
# "standard" pulls from standard claims tables with 3.5 yr history and only examines current members
# "historical" pulls from claims tables with 10 yr history and examines both current and past members
project_type = "standard"

#Should be set to true for Calendar Based Score Dates or when initially defining your cohort and identifying qualified members for Variable Score Dates  
#Should be set to false when generating variable score date member information 
mbr_selection_phase = True                              

#Set process_date_constrained - Set to False to remove process date restriction on any claims data
process_date_constrained = False

#Set score_date_type
# "fixed" uses a calendar date
# "variable" uses different dates for each member
score_date_type = "variable"

#Define score date for 'fixed' score dates and max date for 'variable' score dates
score_year = 2021
score_month = 2
score_day = 28


# today = datetime.now()
# today_date = today.replace(day=1) - timedelta(days=1)
# score_year = today_date.year
# score_month = today_date.month
# score_day = today_date.day

# Date range value in months for history periods - use for tenure qualifications - should match desired training data lookback - backward from score date
model_lookback = 6

# Date range value in months for index period
index_lookback = 12

# Date range value in months for custom lookback periods for Authorization data (default = 3 months) and DCSI scoring (default = 12 months, adjust to 27 months for Diabetes specific models)
auth_lookback = 3
dcsi_lookback = 27
dcsi_lookback = model_lookback  # Comment out this line if building a diabetes specific model and ensure project type correctly selected to provide required history

# Date range value in months for prediction period - forward from score date
eval_period = 3

#Defined lookback intervals to calculate - valid types are "months" and "days"
#Individual values cannot exceed model_lookback period - first value is 0 and last value should equal history_lookback length
#If no intervals are wanted, must still be set to [0] - another common value is [0,3,6,9,12]
#Max number of intervals supported is 6.
interval_values = [0,3,6]
interval_type = "months"

# Determine monthly PMPM precision
# True = fractional tenure based on days active in month period
# False = any tenure detected in a month = full month
precise_pmpm = True

# Determine claim grouping when generating counts
# "logical" uses the "lclm_medclm_key" (preferred method)
# "unique" uses the "clm_unique_key"
clm_grp_val = "logical"

#Build our score date as a datetime object
score_date = datetime(score_year,score_month,score_day,0,0)

# DO NOT EDIT - Quick Tests to make sure some basic parameters are valid:
try:
    assert (eval_period > 0)
    assert (model_lookback > 0)
except:
    raise HaltException("Lookback or eval periods must be greater than zero - please update these values")
    print(str(HaltException))
try:
    assert (interval_values[0] == 0)
    assert (interval_values[-1] == model_lookback)
except:
    raise HaltException("Interval boundaries must start with zero and end with model_lookback value")
    print(str(HaltException))

print ("Latest Possible Score Date: " + str(score_date))

# COMMAND ----------

# This should contain a list of the target platform(s) for the model - uncomment the appropriate line and comment out others based on your needs
fin_prod_tgt_list = ["MEDR"]  #Medicare, excluding PDP
#fin_prod_tgt_list = ["MCD"]  #Medicaid
#fin_prod_tgt_list = ['HMOC','ASO','PPO','IHM','IMV','IND']  #Commercial
#fin_prod_tgt_list = ["VIT"] #Go365 Members

# This sets which groups within Medicare will be included and is only relevant if the finProdTgtList is set to Medicare members
# "MA or MAPD" only includes only Medicare Advantage members who may or may not also have Prescription Drug Plans
# "PDP Only" includes only members who just have Prescription Drug Plans
# "All" includes all MAPD, MA and PDP members
medicare_option = "All"

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md ### Load functions from the Shared Scripts 

# COMMAND ----------

# MAGIC %md ##### Load Members and Calculate Tenure
# MAGIC This will pull all qualified members from your selected LOB based who were active on your score date and calculate their tenure in fractions of months for both the model_lookback and eval_period timeframes - it will generate an array by month in chronological order and a summed total for each of the 2 timeframes

# COMMAND ----------

# MAGIC %run "/Shared/stdfeatures/CMS Features"

# COMMAND ----------

# MAGIC %run "/Shared/stdfeatures/base/Base Membership"

# COMMAND ----------

# MAGIC %md ##### Write member list with flag or target values to ADLS Gen 2 Storage  
# MAGIC These two data sets will serve as the starting point for creating features

# COMMAND ----------

# This was a file I sent to the MLP team awhile back to have my target variables
event_df = (spark.read.parquet(adls_source_path + "/lvl1/rx_enrollment_campaign")
                 .select(col('sdr_person_id').cast(LongType()),
                         col('contact_date').cast(TimestampType()).alias('index_date'),
                         col('rx_enroll').cast(IntegerType()))
                 .withColumn('unique_id',f.concat(col('sdr_person_id'),col('index_date').cast(DateType()))).cache())

# COMMAND ----------



# COMMAND ----------

# Goal: Writes a dataframe of your members with appropriate flags or target to persistent storage
# If you are building a model, be sure to include your target variable here
(event_df
 .write
 .mode("overwrite")
 .option("header", "true")
 .format("parquet")
 .save(adls_xformed_path + "/lvl1/models/rxe-model-v1/datamart/20190630-rxe-mbr-event-list"))

# COMMAND ----------

# Unloading DF from memory and reading it back in from persistent storage (otherwise it would be deleted)
mbrs_df.unpersist()
event_df.unpersist()

event_df = spark.read.parquet(adls_xformed_path + "/lvl1/models/rxe-model-v1/datamart/20190630-rxe-mbr-event-list")

# Set to false now to get member data relative to the index dates you've assigned
mbr_selection_phase = False

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md ### Re-run functions from the Shared Scripts with the updated event_df 

# COMMAND ----------

# MAGIC %run "/Shared/stdfeatures/base/Base Membership"

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md ### Save members dataframe

# COMMAND ----------

# Write out membership info that looks back the length of your history_lookback from the index_date
(mbrs_df
 .write
 .mode("overwrite")
 .option("header", "true")
 .format("parquet")
 .save(adls_xformed_path + "/lvl1/models/rxe-model-v1/20190630-rxe-mbrs"))

(mbr_plans_df
 .write
 .mode("overwrite")
 .option("header", "true")
 .format("parquet")
 .save(adls_xformed_path + "/lvl1/models/rxe-model-v1/20190630-rxe-mbr-plans"))

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md ### Re-Load Base Reusable Functions and Set Parameters (Parameters changed)
# MAGIC These parameters determine which data to load and how far into the future from the score date you want to include in the feature definitions.  
# MAGIC > **Important!** Any parameters you supplied during your cohort creation should match except for the direction, which should now be "backward".

# COMMAND ----------

# MAGIC %run "/Shared/stdfeatures/ref/Base Functions"

# COMMAND ----------

# Standard Constants - DO NOT EDIT
fin_prod_non_medr = ['HMOC','ASO','PPO','MCD','IHM','IMV','IND','VIT']    # Non-Medicare LOBs
fin_prod_medr = "MEDR"                                                    # Medicare LOB
pdp_fin_sub_vals = ['MDG','MDI','MDL','HMI']                              # These subcategories identify PDP Plans
src_platform_vals = ['LV','EM','CP']                                      # Standard platforms including Louisville, Metavance and CarePlus
claim_types = ['A','C','E','R']                                           # Limit to key payment_cat_cds including Adjudicated, Completed (Paid), Encounter and Rejected
cost_types = ['A','C']                                                    # Exclude encounter claims from cost calculations since the reported costs are not reliable
direction = "backward"                                                    # Retrieves claims and other standard source data during prediction period only
mbr_selection_phase = False                                               # Relevant for variable score dates only - only retrieves data in lookback period relative to index date
                                                                          # mbr_selection_phase Can be set to any value (True or False), but has to exist for calendar score dates

# COMMAND ----------

#Set projectType
# "standard" pulls from standard claims tables with 3.5 yr history and only examines current members
# "historical" pulls from claims tables with 10 yr history and examines both current and past members
project_type = "standard"

#Set process_date_constrained - Set to False to remove process date restriction on any claims data
process_date_constrained = True

#Set score_date_type
# "fixed" uses a calendar date
# "variable" uses different dates for each member
score_date_type = "variable"

#Define max score date for 'variable' score dates
score_year = 2019
score_month = 6
score_day = 30

# Date range value in months for history periods - use for tenure qualifications - should match desired training data lookback - backward from score date
model_lookback = 6

# Date range value in months for custom lookback periods for Authorization data (default = 3 months) and DCSI scoring (default = 12 months, adjust to 27 months for Diabetes specific models)
auth_lookback = 3
dcsi_lookback = 27
dcsi_lookback = model_lookback  # Comment out this line if building a diabetes specific model and ensure project type correctly selected to provide required history

# Date range value in months for prediction period - forward from score date
eval_period = 3

#Defined lookback intervals to calculate - valid types are "months" and "days"
#Individual values cannot exceed model_lookback period - first value is 0 and last value should equal history_lookback length
#If no intervals are wanted, must still be set to [0] - another common value is [0,3,6,9,12]
#Max number of intervals supported is 6.
interval_values = [0,3,6]
interval_type = "months"

# Determine monthly PMPM precision
# True = fractional tenure based on days active in month period
# False = any tenure detected in a month = full month
precise_pmpm = True

# Determine claim grouping when generating counts
# "logical" uses the "lclm_medclm_key" (preferred method)
# "unique" uses the "clm_unique_key"
clm_grp_val = "logical"

#Build our max score date as a datetime object
score_date = datetime(score_year,score_month,score_day,0,0)

# DO NOT EDIT - Quick Tests to make sure some basic parameters are valid:
try:
    assert (eval_period > 0)
    assert (model_lookback > 0)
except:
    raise HaltException("Lookback or eval periods must be greater than zero - please update these values")
    print(str(HaltException))
try:
    assert (interval_values[0] == 0)
    assert (interval_values[-1] == model_lookback)
except:
    raise HaltException("Interval boundaries must start with zero and end with model_lookback value")
    print(str(HaltException))

print("Latest Possible Score Date: " + str(score_date))

# COMMAND ----------

# This should contain a list of the target platform(s) for the model - uncomment the appropriate line and comment out others based on your needs
fin_prod_tgt_list = ["MEDR"]  #Medicare, excluding PDP
#fin_prod_tgt_list = ["MCD"]  #Medicaid
#fin_prod_tgt_list = ['HMOC','ASO','PPO','IHM','IMV','IND']  #Commercial
#fin_prod_tgt_list = ["VIT"] #Go365 Members

# This sets which groups within Medicare will be included and is only relevant if the finProdTgtList is set to Medicare members
# "MA or MAPD" only includes only Medicare Advantage members who may or may not also have Prescription Drug Plans
# "PDP Only" includes only members who just have Prescription Drug Plans
# "All" includes all MAPD, MA and PDP members
medicare_option = "All"

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md ### Load Member Information
# MAGIC Uses data stored in ADLS Gen 2 from cohort creation.  If these artifcats do not yet exist, you must first create them using the template for creating a modeling target and associated cohort.

# COMMAND ----------

# Unloading DF from memory and reading it back in from persistent storage (otherwise it would be deleted)
mbrs_df.unpersist()
event_df.unpersist()

# Assumes you saved the mbrs_df dataframe with all its columns from running the Base Membership script when creating your modeling target
mbrs_df = spark.read.parquet(adls_xformed_path + "/lvl1/models/rxe-model-v1/20190630-rxe-mbrs").cache()
# mbrs_df = spark.read.parquet(adls_xformed_path + "/lvl1/models/rxe-model-v1/20190630-rxe-mbrs").drop("rx_enroll").cache()

# Assumes you saved the mbrs_df dataframe with all its columns from running the Base Membership script but don't have a target variable
#mbrs_df = spark.read.parquet(adls_xformed_path + "/PATH_TO_YOUR_FOLDER")

# Used for base scripts (membership and claims)
mbr_list_df = mbrs_df.select("sdr_person_id","unique_id").distinct()

# Needs to contain the columns of sdr_person_id (long) index_date (timestamp) and event_id (int) and unique_id (string)
event_df = mbrs_df.select("sdr_person_id","index_date","unique_id").cache()

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md ### Create Foundational Dataframes - used by multiple feature scripts
# MAGIC 
# MAGIC Creates 3 main dataframes (medical claims, pharmacy claims, and lab results) that will be leveraged by several different feature scripts

# COMMAND ----------

# Delete all comment line to run successfully
# %run "/Shared/stdfeatures/base/Base MedClaims" # Don't need
%run "/Shared/stdfeatures/base/Base PharmacyClaims"
# %run "/Shared/stdfeatures/base/Base LabClaims" # Don't need


# COMMAND ----------

# MAGIC %md ##### Dataframes created:
# MAGIC 1. medclms_df --> Medical Claims - claim line level data with extra fields added, only during lookback period for selected members
# MAGIC 2. rxclms_df --> Pharmacy Claims - claim line level data with extra fields added, only during lookback period for selected members
# MAGIC 3. labclms_df --> Lab Claims - cleansed claim line level data with extra fields added, only during lookback period for selected members

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### Reference Tools
# MAGIC Creates various python dictionaries from reference tables to enable handy lookups for abbreviated or numeric names for feature columns

# COMMAND ----------

# MAGIC %run "/Shared/stdfeatures/ref/Reference Dictionaries"

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md ### Feature Generation
# MAGIC 
# MAGIC > **Important!** Each time you re-run a script, all dataframes cached by that script will be automatically removed from memory before the script runs.

# COMMAND ----------

# MAGIC %md ##### Membership Attributes
# MAGIC 
# MAGIC 1. Basic Member Features (basic_mbr_char_df) - Adds Geographic and Risk Arrangement info to the base demographic information  
# MAGIC > Use this as your base dataframe for joining features together - only pulls most recent information as of score date or index date  
# MAGIC 2. Customer Coverage Plan Features (plan_info_df) - Creates Member Coverage Plan related features  
# MAGIC 3. CMS Features (cms_risk_df) - Creates CMS Risk-related features  
# MAGIC 4. HCC Features (hcc_features_df) - Creates CMS Risk-related features using Hierarchical Condition Categories  
# MAGIC 5. AMLK Conbase Features (conbase_df) - Derived from 3rd party data projected down from zip codes or counties  
# MAGIC 6. AMLK Credit Features (credit_df) - Derived from 3rd party data projected down from zip codes or counties  
# MAGIC 7. RWJF County Features (rwjf_features_df) - Generates county-level Robert Wood Johnson Foundation Features - Social Determinants  
# MAGIC 8. Smoking Status Features (smoke_status_df) - Smoking status - from 3 sources - Membership, Unstructured Data and Medical Claims - Requires medclms_df  
# MAGIC 9. Health Program Features (hlth_pgm_features_df) - Creates Health Program Participation and Referral related features  
# MAGIC 10. Behavioral Segmentation (bh_seg_features_df) - Create features related to behavioral segments assigned among Medicare (MA or PDP) members  
# MAGIC 11. FoodEnv and Rural Atlas SDoH Features (foodenv_rural_df) - Creates county-level features from public datasource - Social Determinants  

# COMMAND ----------

# MAGIC %md ##### Basic Member Features

# COMMAND ----------

# MAGIC %run "/Shared/stdfeatures/Basic Member Features"

# COMMAND ----------

# MAGIC %md ##### AmeriLink

# COMMAND ----------

# Humana members only?  Will filter down to your member list if set to True, otherwise will bring in all members
hum_mbrs_only = True

# There are multiple versions of the features based on date - defaults to current version
# Assumes the folder will reside in the tempdata folder, so just need to provide name of table you want to use
# You will only need to change this if you have a more historical score date - older tables are in the format "conbase_YYMM"
# IMPORTANT!!! Only the current version is supported in the cloud for now, so anything except "CURR" with throw an error

conbase_tbl_option = "CURR"
#conbase_tbl_option = "1903"   # This shows an example for the March 2019 version

# COMMAND ----------

# MAGIC %run "/Shared/stdfeatures/AMLK Conbase Features"

# COMMAND ----------

# MAGIC %md ##### Login Features

# COMMAND ----------

# Only want the standard 99 columns?  If true will limit to that list.  Otherwise will bring in all columns!
top99 = True

# COMMAND ----------

# MAGIC %run "/Shared/stdfeatures/Login Features"

# COMMAND ----------

# MAGIC %md ##### Behavioral Segmentation Features

# COMMAND ----------

# MAGIC %run "/Shared/stdfeatures/Behavioral Segmentation"

# COMMAND ----------

# MAGIC %md ##### Pharmacy Features
# MAGIC 1. RX Features (rx_features_df, rx_features_df1-6, rx_features_trend_df) - Pharmacy - Trend Features Available - Requires rxclms_df  

# COMMAND ----------

# Change interval_flag to True if you also wish to calculate interval features based on the interval_values previously defined
# -----------------------Interval Features------------------------
interval_flag = False

# Set some 
if interval_flag:
    direction = "backward"      #Only compatible with history period
# -----------------------------------------------------------------

#This is the path where the reference file for the HUM drug class will be stored - it should be stable from run to run, but can change
rx_hum_ref_path = adls_xformed_path + target_folder_path + "-pharm"  # Do NOT include a trailing / here

# COMMAND ----------

# MAGIC %run "/Shared/stdfeatures/RX Features"

# COMMAND ----------

# #Intermediate join of pharmacy features
# #Note that the DFs listed are based on having the interval flag = true and using 2 intervals as specified in default parameters
# #You will need to add more if you use more intervals or comment out those DFs you didn't generate before running or remove if you didn't create them

# model_rxtrend_df = (rx_features_df1.join(rx_features_df2,["sdr_person_id","unique_id"])
#                                    # Need to insert additional dataframes continuing the numbering trend if more than 2 intervals are built 
#                                    .join(rx_features_trend_df,["sdr_person_id","unique_id"])
#                                    .cache())

# # Forces dataframe to be cached
# print("Members: " + str(model_rxtrend_df.count()))
# print("Features: " + str(len(model_rxtrend_df.columns)-2))

# COMMAND ----------

# MAGIC %md ##### Tenure Features

# COMMAND ----------

# This is for the tenure for member for past 10 years - pre_month_total
tenure_df = spark.read.parquet(adls_xformed_path + "/lvl1/models/medr-rxe-model-v1/model-target-population/20190630-rxe-mbrs-10yr").cache()
# tenure_df = spark.read.parquet(adls_xformed_path + "/lvl1/models/rxe-model-v1/20190630-rxe-mbrs-10yr").cache()

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md ### Save Files

# COMMAND ----------

# Save df
# basic mbr info
(basic_mbr_char_df
.write
.mode("overwrite")
.option("header", "true")
.format("parquet")
.save(adls_xformed_path + target_folder_path + "-mbrinfo"))

# rx 
(rxclms_df
.write
.mode("overwrite")
.option("header", "true")
.format("parquet")
.save(adls_xformed_path + target_folder_path + "-rxclms"))

# amlk
(conbase_df
.write
.mode("overwrite")
.option("header", "true")
.format("parquet")
.save(adls_xformed_path + target_folder_path + "-amlk"))

# Login Features
(login_features_df
.write
.mode("overwrite")
.option("header", "true")
.format("parquet")
.save(adls_xformed_path + target_folder_path + "-login"))

# Behavioral Segmentation
(bh_seg_features_df
.write
.mode("overwrite")
.option("header", "true")
.format("parquet")
.save(adls_xformed_path + target_folder_path + "-behseg"))

# Rx Features
(rx_features_df
.write
.mode("overwrite")
.option("header", "true")
.format("parquet")
.save(adls_xformed_path + target_folder_path + "-feat-rx"))

# Write the data to persistent storage
# (model_rxtrend_df
# .write
# .mode("overwrite")
# .option("header", "true")
# .format("parquet")
# .save(adls_xformed_path + target_folder_path + "-feat-rxtrend"))

# COMMAND ----------

# MAGIC %md ### Load Files 
# MAGIC This loads all the files created above. You can probably start here and skip the above if you wish

# COMMAND ----------

# #Use this to specify your write path underneath transformed
# target_folder_path = "/lvl1/models/rxe-model-v1/20190630-rxe"

# # Run this and skip the above once you  have saved the rxclms_df
# basic_mbr_char_df = spark.read.parquet(adls_xformed_path + target_folder_path + "-mbrinfo").cache()
# rxclms_df = spark.read.parquet(adls_xformed_path + target_folder_path + "-rxclms").cache()
# conbase_df = spark.read.parquet(adls_xformed_path + target_folder_path + "-amlk").cache()
# login_features_df = spark.read.parquet(adls_xformed_path + target_folder_path + "-login").cache()
# bh_seg_features_df = spark.read.parquet(adls_xformed_path + target_folder_path + "-behseg").cache()
# rx_features_df = spark.read.parquet(adls_xformed_path + target_folder_path + "-feat-rx").cache()

# # This is for the tenure for member for past 10 years - pre_month_total
# tenure_df = spark.read.parquet(adls_xformed_path + "/lvl1/models/rxe-model-v1/20190630-rxe-mbrs-10yr").cache()

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md ### Create Additional Rx Features

# COMMAND ----------

# Creates more Rx Features
rx_features_df_2 = rxclms_df.groupBy('unique_id','sdr_person_id'
                                    ).agg(f.mean('mbr_respons_amt').alias('mbr_respons_amt_pmpm'),
                                          f.mean("ded_paid_amt").alias('ded_paid_amt_pmpm'))
# rx_features_df_2 = rxclms_df.groupBy('unique_id','sdr_person_id').agg({'mbr_respons_amt':'avg', "ded_paid_amt":'avg'}).show()

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md ### Select Features that the Model Uses

# COMMAND ----------

# Filter to columns used for modeling
basic_mbr_char_feat = ['unique_id', 'sdr_person_id','est_age']
conbase_feat = ['unique_id', 'sdr_person_id','cons_ntwperyr','cons_chva','cons_rxnum','cons_rxbrand','cons_rxsowrx','cons_hwrxloyl']
tenure_feat = ['unique_id', 'sdr_person_id','pre_month_total']
rx_features_feat = ['unique_id', 'sdr_person_id','rx_overall_pmpm_cost','rx_overall_pmpm_ct','rx_mail_pmpm_ct','rx_maint_pmpm_ct','rx_tier_1_pmpm_ct','rx_tier_2_pmpm_ct','rx_phar_cat_humana_pmpm_ct']
rx_features_2_feat = ['unique_id', 'sdr_person_id','mbr_respons_amt_pmpm','ded_paid_amt_pmpm']
login_features_feat = ['unique_id', 'sdr_person_id','days_since_last_login']
bh_seg_features_feat = ['unique_id', 'sdr_person_id', 'bhseg_engaged_mbrs_ind', 'bhseg_unengaged_mbrs_ind', 'bhseg_norecord_ind']
other_features_feat = ['unique_id', 'sdr_person_id','src_platform_cd','mco_contract_nbr','plan_benefit_package_id']

# Might be useful
# rx_days_since_last_script

#Filters your initial dataframe down to important columns
basic_mbr_char_df = basic_mbr_char_df.select(basic_mbr_char_feat).cache()
conbase_df = conbase_df.select(conbase_feat).cache()
tenure_df = tenure_df.select(tenure_feat).cache()
rx_features_df = rx_features_df.select(rx_features_feat).cache()
rx_features_df_2 = rx_features_df_2.select(rx_features_2_feat).cache()
login_features_df = login_features_df.select(login_features_feat).cache()
bh_seg_features_df = bh_seg_features_df.select(bh_seg_features_feat).cache()
other_features_df = mbrs_df.select(other_features_feat).cache()

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md ### Feature Engineering

# COMMAND ----------

rx_features_df = rx_features_df.withColumn("rx_cntrx_hprx_pmpm", (rx_features_df.rx_overall_pmpm_ct - rx_features_df.rx_phar_cat_humana_pmpm_ct))
rx_features_df = rx_features_df.withColumn('rx_cntrx_hprx_pmpm', f.when(rx_features_df.rx_cntrx_hprx_pmpm <= 0,0).otherwise(rx_features_df.rx_cntrx_hprx_pmpm))

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md ### Combine all features (Standard+Custom)

# COMMAND ----------

# Join features back to base mbr df
model_mbr_char_df = (basic_mbr_char_df.join(conbase_df,["sdr_person_id","unique_id"],'left_outer')
                                      .join(tenure_df,["sdr_person_id","unique_id"],'left_outer')
                                      .join(rx_features_df,["sdr_person_id","unique_id"],'left_outer')
                                      .join(rx_features_df_2,["sdr_person_id","unique_id"],'left_outer')
                                      .join(login_features_df,["sdr_person_id","unique_id"],'left_outer')
                                      .join(bh_seg_features_df,["sdr_person_id","unique_id"],'left_outer')
                                      .join(other_features_df,["sdr_person_id","unique_id"],'left_outer')
                                      .cache())

# COMMAND ----------

# Forces dataframe to be cached
print("Members: " + str(model_mbr_char_df.count()))
print("Features: " + str(len(model_mbr_char_df.columns)-2))

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md ### Save features for modeling

# COMMAND ----------

(model_mbr_char_df
.write
.mode("overwrite")
.option("header", "true")
.format("parquet")
.save(adls_xformed_path + target_folder_path + "-feat-mbr-char"))

# COMMAND ----------


