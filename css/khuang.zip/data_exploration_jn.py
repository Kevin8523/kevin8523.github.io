## Step 0: Setup Environment

spark

# Import Libraries
import hdputils
hdputilils.grant_smart_accessss()

import pandas as pd ; pd.set_option('display.max_columns', None);pd.set_option('display.max_rows', None)
import numpy as np

# Function to preview data
ask = lambda q: hdputils.doquery(spark, q).toPandas()



SELECT
    mapd_dt_kevin.MBR_PERS_GEN_KEY,
    mapd_dt_kevin.NTWPERYR, mapd_dt_kevin.CHVA,
    mapd_dt_kevin.RXNUM,mapd_dt_kevin.RXBRAND,mapd_dt_kevin.RXSOWRX,mapd_dt_kevin.HWRXLOYL,
    mapd_dt_kevin.TENURE, mapd_dt_kevin.AGE,
    mapd_dt_kevin.RX_ALLOWED_AMT_6M,
    mapd_dt_kevin.RX_CNT_MAINT_DRUG_6M,mapd_dt_kevin.RX_CNT_RHTSRCE_6M,mapd_dt_kevin.RX_CNT_RX_6M,
    mapd_dt_kevin.RX_CNT_TIER1_6M, mapd_dt_kevin.RX_CNT_TIER2_6M,
    mapd_dt_kevin.RX_MBR_RESP_AMT_6M, mapd_dt_kevin.RX_PAID_AMT_6M,
    mapd_dt_kevin.TS_LAST_LOGIN, mapd_dt_kevin.TS_LAST_CALL,
    mapd_dt_kevin.IND_SEG_ENGAGED
FROM
    consumer_work.mapd_dt_kevin;

#### Raw Tables:
- "consumer_work.recommender_engine_base_table_raw"
- "consumer_work.recommender_engine_disposition_table_raw"
- "consumer_work.recommender_engine_distinct_members_raw"
- "consumer_work.recommender_engine_distinct_conversion_history_raw"
- "consumer_work.recommender_engine_distinct_conversion_total_raw"

#### Staging Tables
- "consumer_work.recommender_engine_hop_trad_mail_driver_table"
- "consumer_work.recommender_engine_hop_trad_email_driver_table"
- "consumer_work.recommender_engine_rxe_driver_table"

#### Pulled Data tables
- "consumer_work.recommender_engine_hop_trad_mail_datapull"
- "consumer_work.recommender_engine_hop_trad_email_datapull"
- "consumer_work.recommender_engine_rxe_datapull"



# Members List:
# 0 conversion = 137004625822
# 1 conversion = 7748004515422
# Multiple C = 1000004231018 , 3290004725422


## Step 0: FAQs

#### What is the number of distinct members and members who converted at least once?

base_name = "consumer_work.recommender_engine_distinct_members_raw"

faq_members = f"""
    SELECT
        count(mbr_pers_gen_key)
        ,sum(conversion_ind) as total_conversion_ind
    FROM
       {base_name}


"""
ask(faq_members)

#### What is the total number of distinct conversions?

base_name = "consumer_work.recommender_engine_distinct_conversion_total_raw"

faq_total_conversion = f"""
    SELECT
        count(mbr_pers_gen_key)
        ,sum(total_conversion_count) as total_conversion_count
    FROM
       {base_name}
"""
ask(faq_total_conversion)

#### What is the total distinct conversion broken out by month?

base_name = "consumer_work.recommender_engine_distinct_conversion_history_raw"

faq_month_conversion_setup = f"""
    SELECT
        mbr_pers_gen_key
        ,MONTH(service_date) as month
        ,conversion_ind
    FROM
       {base_name}
"""

faq_month_conversion = f"""
    SELECT
        month
        ,count(distinct(mbr_pers_gen_key)) as distinct_pgk_for_month
        ,sum(conversion_ind) as total_conversion_count
    FROM
       ({faq_month_conversion_setup})
    GROUP BY
        month
    ORDER BY
        month asc
"""

ask(faq_month_conversion)

#### What is the most number of converted scripts for a single member?

base_name = "consumer_work.recommender_engine_distinct_conversion_total_raw"

faq_max_conversion = f"""
    SELECT
        max(total_conversion_count)
    FROM
       {base_name}
"""
ask(faq_max_conversion)

#### Number of conversions by channel (Includes duplication of channel)

base_name = "consumer_work.recommender_engine_disposition_table_raw"

faq_channel_conversion_setup = f"""
    SELECT
        mbr_pers_gen_key
        ,channel_desc
        ,targeted_document_key
        ,converted_document_key
        ,min_event_date
        ,service_date
        ,disp_type_desc
        ,conversion_ind
    FROM
       {base_name}
    ORDER BY
        min_event_date
"""

faq_channel_conversion = f"""
    SELECT
        channel_desc
        ,count(distinct(mbr_pers_gen_key))
        ,count(mbr_pers_gen_key)
        ,sum(conversion_ind) as sum_conversion
        ,(sum(conversion_ind))/(count(mbr_pers_gen_key)) as pct_conversion
    FROM
       ({faq_channel_conversion_setup})
    GROUP BY
        channel_desc
"""

ask(faq_channel_conversion)

## Step 1: Conversion by Channels

#### Members in Trad Mail ONLY

base_name_mail = "consumer_work.recommender_engine_hop_trad_mail_driver_table"
base_name_email = "consumer_work.recommender_engine_hop_trad_email_driver_table"
base_name_rxe = "consumer_work.recommender_engine_rxe_driver_table"

trad_mail_list = f"SELECT mbr_pers_gen_key,ref_date,channel_desc,conversion_ind FROM {base_name_mail}"
trad_email_list = f"SELECT mbr_pers_gen_key,ref_date,channel_desc,conversion_ind FROM {base_name_email}"
trad_rxe_list = f"SELECT mbr_pers_gen_key,ref_date,channel_desc,conversion_ind FROM {base_name_rxe}"

trad_mail_only_setup = f"""
    SELECT
        a.mbr_pers_gen_key
        ,a.ref_date
        ,a.channel_desc
        ,a.conversion_ind
    FROM
       ({trad_mail_list}) a LEFT JOIN ({trad_email_list}) b ON (a.mbr_pers_gen_key = b.mbr_pers_gen_key)
    WHERE
        b.mbr_pers_gen_key is NULL
"""

trad_mail_only = f"""
    SELECT
        a.mbr_pers_gen_key
        ,a.ref_date
        ,a.channel_desc
        ,a.conversion_ind
    FROM
       ({trad_mail_only_setup}) a LEFT JOIN ({trad_rxe_list}) b ON (a.mbr_pers_gen_key = b.mbr_pers_gen_key)
    WHERE
        b.mbr_pers_gen_key is NULL
"""

# base_name = "consumer_work.recommender_engine_hop_trad_mail_members_only"
# # run the query
# base_df = hdputils.doquery(spark, trad_mail_only)
# base_df.write.saveAsTable(base_name, mode="overwrite")

#### Members in Trad E-Mail ONLY

base_name_mail = "consumer_work.recommender_engine_hop_trad_mail_driver_table"
base_name_email = "consumer_work.recommender_engine_hop_trad_email_driver_table"
base_name_rxe = "consumer_work.recommender_engine_rxe_driver_table"

trad_mail_list = f"SELECT mbr_pers_gen_key,ref_date,channel_desc,conversion_ind FROM {base_name_mail}"
trad_email_list = f"SELECT mbr_pers_gen_key,ref_date,channel_desc,conversion_ind FROM {base_name_email}"
trad_rxe_list = f"SELECT mbr_pers_gen_key,ref_date,channel_desc,conversion_ind FROM {base_name_rxe}"

trad_email_only_setup = f"""
    SELECT
        a.mbr_pers_gen_key
        ,a.ref_date
        ,a.channel_desc
        ,a.conversion_ind
    FROM
       ({trad_email_list}) a LEFT JOIN ({trad_mail_list}) b ON (a.mbr_pers_gen_key = b.mbr_pers_gen_key)
    WHERE
        b.mbr_pers_gen_key is NULL
"""

trad_email_only = f"""
    SELECT
        a.mbr_pers_gen_key
        ,a.ref_date
        ,a.channel_desc
        ,a.conversion_ind
    FROM
       ({trad_email_only_setup}) a LEFT JOIN ({trad_rxe_list}) b ON (a.mbr_pers_gen_key = b.mbr_pers_gen_key)
    WHERE
        b.mbr_pers_gen_key is NULL
"""

# base_name = "consumer_work.recommender_engine_hop_trad_email_members_only"
# # run the query
# base_df = hdputils.doquery(spark, trad_email_only)
# base_df.write.saveAsTable(base_name, mode="overwrite")

#### Members in Trad E-Mail & Mail

base_name_mail = "consumer_work.recommender_engine_hop_trad_mail_driver_table"
base_name_email = "consumer_work.recommender_engine_hop_trad_email_driver_table"
base_name_rxe = "consumer_work.recommender_engine_rxe_driver_table"

trad_mail_list = f"SELECT mbr_pers_gen_key,ref_date,channel_desc,conversion_ind FROM {base_name_mail}"
trad_email_list = f"SELECT mbr_pers_gen_key,ref_date,channel_desc,conversion_ind FROM {base_name_email}"
trad_rxe_list = f"SELECT mbr_pers_gen_key,ref_date,channel_desc,conversion_ind FROM {base_name_rxe}"

trad_email_mail = f"""
    SELECT
        a.mbr_pers_gen_key
        ,a.ref_date
        ,a.channel_desc
        ,a.conversion_ind
    FROM
       ({trad_email_list}) a LEFT JOIN ({trad_rxe_list}) b ON (a.mbr_pers_gen_key = b.mbr_pers_gen_key)
    WHERE
        b.mbr_pers_gen_key is NULL
"""

# base_name = "consumer_work.recommender_engine_hop_trad_email_members_with_mail"
# # run the query
# base_df = hdputils.doquery(spark, trad_email_mail)
# base_df.write.saveAsTable(base_name, mode="overwrite")

#### Members in RxE ONLY

base_name_mail = "consumer_work.recommender_engine_hop_trad_mail_driver_table"
base_name_email = "consumer_work.recommender_engine_hop_trad_email_driver_table"
base_name_rxe = "consumer_work.recommender_engine_rxe_driver_table"

trad_mail_list = f"SELECT mbr_pers_gen_key,ref_date,channel_desc,conversion_ind FROM {base_name_mail}"
trad_email_list = f"SELECT mbr_pers_gen_key,ref_date,channel_desc,conversion_ind FROM {base_name_email}"
trad_rxe_list = f"SELECT mbr_pers_gen_key,ref_date,channel_desc,conversion_ind FROM {base_name_rxe}"

trad_rxe_only_setup = f"""
    SELECT
        a.mbr_pers_gen_key
        ,a.ref_date
        ,a.channel_desc
        ,a.conversion_ind
    FROM
       ({trad_rxe_list}) a LEFT JOIN ({trad_mail_list}) b ON (a.mbr_pers_gen_key = b.mbr_pers_gen_key)
    WHERE
        b.mbr_pers_gen_key is NULL
"""

trad_rxe_only = f"""
    SELECT
        a.mbr_pers_gen_key
        ,a.ref_date
        ,a.channel_desc
        ,a.conversion_ind
    FROM
       ({trad_rxe_only_setup}) a LEFT JOIN ({trad_email_list}) b ON (a.mbr_pers_gen_key = b.mbr_pers_gen_key)
    WHERE
        b.mbr_pers_gen_key is NULL
"""

# base_name = "consumer_work.recommender_engine_rxe_members_only"
# # run the query
# base_df = hdputils.doquery(spark, trad_rxe_only)
# base_df.write.saveAsTable(base_name, mode="overwrite")

#### Members in RxE and Trad Mail

base_name_mail = "consumer_work.recommender_engine_hop_trad_mail_driver_table"
base_name_email = "consumer_work.recommender_engine_hop_trad_email_driver_table"
base_name_rxe = "consumer_work.recommender_engine_rxe_driver_table"

trad_mail_list = f"SELECT mbr_pers_gen_key,ref_date,channel_desc,conversion_ind FROM {base_name_mail}"
trad_email_list = f"SELECT mbr_pers_gen_key,ref_date,channel_desc,conversion_ind FROM {base_name_email}"
trad_rxe_list = f"SELECT mbr_pers_gen_key,ref_date,channel_desc,conversion_ind FROM {base_name_rxe}"

trad_rxe_mail = f"""
    SELECT
        a.mbr_pers_gen_key
        ,a.ref_date
        ,a.channel_desc
        ,a.conversion_ind
    FROM
       ({trad_rxe_list}) a LEFT JOIN ({trad_email_list}) b ON (a.mbr_pers_gen_key = b.mbr_pers_gen_key)
    WHERE
        b.mbr_pers_gen_key is NULL
"""

# base_name = "consumer_work.recommender_engine_rxe_members_with_mail"
# # run the query
# base_df = hdputils.doquery(spark, trad_rxe_mail)
# base_df.write.saveAsTable(base_name, mode="overwrite")

#### Members in Trad Mail, E-Mail, & RxE

base_name_mail = "consumer_work.recommender_engine_hop_trad_mail_driver_table"
base_name_email = "consumer_work.recommender_engine_hop_trad_email_driver_table"
base_name_rxe = "consumer_work.recommender_engine_rxe_driver_table"

trad_mail_list = f"SELECT mbr_pers_gen_key,ref_date,channel_desc,conversion_ind FROM {base_name_mail}"
trad_email_list = f"SELECT mbr_pers_gen_key,ref_date,channel_desc,conversion_ind FROM {base_name_email}"
trad_rxe_list = f"SELECT mbr_pers_gen_key,ref_date,channel_desc,conversion_ind FROM {base_name_rxe}"

trad_all_setup = f"""
    SELECT
        a.mbr_pers_gen_key
        ,a.ref_date
        ,a.channel_desc
        ,a.conversion_ind
    FROM
       ({trad_mail_list}) a LEFT JOIN ({trad_email_list}) b ON (a.mbr_pers_gen_key = b.mbr_pers_gen_key)
    WHERE
        b.mbr_pers_gen_key is NOT NULL
"""

trad_all = f"""
    SELECT
        a.mbr_pers_gen_key
        ,a.ref_date
        ,a.channel_desc
        ,a.conversion_ind
    FROM
       ({trad_all_setup}) a LEFT JOIN ({trad_rxe_list}) b ON (a.mbr_pers_gen_key = b.mbr_pers_gen_key)
    WHERE
        b.mbr_pers_gen_key is NOT NULL
"""

# base_name = "consumer_work.recommender_engine_hop_trad_mail_email_rxe_all_members"
# # run the query
# base_df = hdputils.doquery(spark, trad_all)
# base_df.write.saveAsTable(base_name, mode="overwrite")

## Step 2: Explore Channel Tables Conversions

# Understand  the time between channel contacts
# Number of contacts touches before conversions

mail_base_name = "consumer_work.recommender_engine_hop_trad_mail_members_only"
email_base_name = "consumer_work.recommender_engine_hop_trad_email_members_only"
email_mail_base_name = "consumer_work.recommender_engine_hop_trad_email_members_with_mail"
rxe_base_name = "consumer_work.recommender_engine_rxe_members_only"
rxe_mail_base_name = "consumer_work.recommender_engine_rxe_members_with_mail"
all_base_name = "consumer_work.recommender_engine_hop_trad_mail_email_rxe_all_members"

print('Trad Mail Only')
# Only counts if they had a conversion, if they had multiple it still only counts as 1
mail_base_query = f"SELECT count(mbr_pers_gen_key),sum(conversion_ind) as sum_conversion,(sum(conversion_ind))/(count(mbr_pers_gen_key)) as pct_conversion  FROM {mail_base_name}"
ask(mail_base_query)

print('Trad Email Only')
# Only counts if they had a conversion, if they had multiple it still only counts as 1
email_base_query = f"SELECT count(mbr_pers_gen_key),sum(conversion_ind) as sum_conversion,(sum(conversion_ind))/(count(mbr_pers_gen_key)) as pct_conversion FROM {email_base_name}"
ask(email_base_query)

print('Trad Email & Mail')
# Only counts if they had a conversion, if they had multiple it still only counts as 1
email_mail_base_query = f"SELECT count(mbr_pers_gen_key),sum(conversion_ind) as sum_conversion,(sum(conversion_ind))/(count(mbr_pers_gen_key)) as pct_conversion FROM {email_mail_base_name}"
ask(email_mail_base_query)

print('RxE Only')
# Only counts if they had a conversion, if they had multiple it still only counts as 1
rxe_base_query = f"SELECT count(mbr_pers_gen_key),sum(conversion_ind) as sum_conversion,(sum(conversion_ind))/(count(mbr_pers_gen_key)) as pct_conversion FROM {rxe_base_name}"
ask(rxe_base_query)

print('RxE & Trad Mail')
# Only counts if they had a conversion, if they had multiple it still only counts as 1
rxe_mail_base_query = f"SELECT count(mbr_pers_gen_key),sum(conversion_ind) as sum_conversion,(sum(conversion_ind))/(count(mbr_pers_gen_key)) as pct_conversion FROM {rxe_mail_base_name}"
ask(rxe_mail_base_query)

print('All Channels')
# Only counts if they had a conversion, if they had multiple it still only counts as 1
all_base_query = f"SELECT count(mbr_pers_gen_key),sum(conversion_ind) as sum_conversion,(sum(conversion_ind))/(count(mbr_pers_gen_key)) as pct_conversion FROM {all_base_name}"
ask(all_base_query)

## Step 3: Create Datasets to Explore Features for each Channel

# Sum of the cond_var across as a feature engineer
# maybe summing number of class 00x tags

# all_traindf[cond_var].sort_values(by='conversion_ind').tail(15).head(12).sum(axis=1)
# all_traindf[factor_var].sort_values(by='conversion_ind').tail(15).head(12)

# Main Channels
mail_base_name = "consumer_work.recommender_engine_hop_trad_mail_members_only"
email_mail_base_name = "consumer_work.recommender_engine_hop_trad_email_members_with_mail"
rxe_mail_base_name = "consumer_work.recommender_engine_rxe_members_with_mail"
all_base_name = "consumer_work.recommender_engine_hop_trad_mail_email_rxe_all_members"

# # Conversion %
# Trad Mail - 0.018012
# TradM-Email - 0.03822
# TradM-Rxe - 0.047417
# All-Three - 0.077254

# Columns
amlk_var = ['mbr_pers_gen_key', 'apt_a', 'apt_b', 'apt_c', 'apt_m', 'apt_n', 'apt_p', 'apt_s', 'apt_w', 'cblu', 'ccip', 'cgqs', 'chmi', 'chva', 'cmys_1', 'cmys_2', 'cmys_3', 'cmys_4', 'cmys_5', 'cmys_6', 'cmys_7', 'cwht', 'emdm_y', 'famp_b', 'famp_c', 'famp_f', 'famp_g', 'famp_h',
             'famp_m', 'famp_p', 'famp_s', 'famp_w', 'hhcomp_a', 'hhcomp_b', 'hhcomp_c', 'hhcomp_d', 'hhcomp_e', 'hhcomp_f', 'hhcomp_g', 'hhcomp_h', 'hhcomp_i', 'hhcomp_j', 'hhcomp_k', 'hhcomp_l', 'homstat_p', 'homstat_r', 'homstat_t', 'homstat_u', 'homstat_y', 'lwcm02', 'lwcm02rrnk', 'lwcm03', 'lwcm03rrnk', 'lwcm04', 'lwcm04rrnk', 'lwcm05', 'lwcm05rrnk', 'lwcm06', 'lwcm06rrnk', 'lwcm07', 'lwcm07rrnk', 'lwcm08', 'lwcm08rrnk', 'lwcm09', 'lwcm09rrnk', 'lwcm10', 'lwcm10rrnk', 'lwcm11', 'lwcm11rrnk', 'lwcm12', 'lwcm12rrnk', 'meda', 'mobplus_m', 'mobplus_p', 'mobplus_s', 'n2mah', 'n2mob', 'n2ncy_a', 'n2ncy_b', 'n2ncy_c', 'n2ncy_d', 'n2pbl', 'n2pdv', 'n2phi', 'n2pmr', 'n2pmv', 'n2poo', 'n2psu', 'n2pwc', 'n2pwh', 'n3039_y', 'n4049_y', 'n5059_y', 'n6064_y', 'n65p_y', 'nah19', 'noc19', 'nph19', 'ntwperyr', 'nwperadult', 'offline_buyer', 'online_buyer', 'pdpe', 'poc19_p', 'poc19_y', 'poep_y', 'ret_y', 'retail_buyer', 'u18_y', 'veteran_y', 'bc_m', 'bc_y', 'college_y', 'n1819_y', 'n2029_y', 'part_d', 'part_i', 'part_r', 'rc_m', 'rc_y', 'vote_y', 'dwelling_age', 'irihlth_0', 'irihlth_9', 'irisnr_0', 'irisnr_9', 'ltcindx_0', 'ltcindx_9',
             'medsup_0', 'medsup_9', 'engage_0', 'engage_9', 'influenc_0', 'influenc_9', 'irilife_0', 'irilife_9', 'lvwl20_1', 'lvwl20_2', 'lvwl20_3', 'lvwl20_4', 'lvwl20_5', 'lvwl20_6', 'chanpr1_c', 'chanpr1_e', 'chanpr1_m', 'chanpr1_o', 'chanpr1_p', 'chanpr1_t', 'chanpr1_w', 'chanprc_0', 'chanprc_9', 'chanprt_0', 'chanprt_9', 'chanpre_0', 'chanpre_9', 'chanprw_0', 'chanprw_9', 'chanprp_0', 'chanprp_9', 'chanprm_0', 'chanprm_9', 'estinv30_rc', 'altruist_0', 'altruist_9', 'stlnindx_0', 'stlnindx_9', 'stlindex_0', 'stlindex_9', 'netw30_rc', 'estinc30_rc', 'hcaccprf_p', 'hcaccprf_c', 'hcaccprf_h', 'hxmboh', 'hxmh', 'hxmioc', 'hxwearbl', 'hbmulti', 'hbsust', 'rxadhm', 'rxadhs', 'rxbrand', 'rxmaint', 'rxncdrug_a', 'rxncdrug_c', 'rxncdrug_d', 'rxncdrug_n', 'rxnum', 'rxpurcha_d', 'rxpurcha_g', 'rxpurcha_m', 'rxpurcha_r', 'rxsowrx', 'rxsupp', 'mediaidd', 'mediaiod', 'mediaip_d', 'mediaip_o', 'mediaip_s', 'mediaism', 'hwfosl', 'hwfoss', 'hwrxloyl', 'saversst',
            'saverslt', 'hiempins', 'ltmedicr', 'eipharms', 'hlthunin', 'estdeb30_rc','conversion_ind']
demographic_var = ['mbr_pers_gen_key','gender_M', 'gender_F', 'gender_UNK','age', 'tenure','conversion_ind']
contact_var = ['mbr_pers_gen_key','cnt_cp_emails_12m', 'cnt_cp_print_12m', 'cnt_cp_vat_12m', 'cnt_cp_webstatement_12m', 'cnt_cp_livecall_12m', 'acq_ch_deleg_agent', 'acq_ch_career', 'acq_ch_telesales', 'acq_ch_d2c_online', 'acq_ch_unk',
               'login_count_12m', 'login_days_12m', 'myhumana_log_12m', 'ts_last_login','conversion_ind']
pharm_var = ['mbr_pers_gen_key','rx_allowed_amt_12m', 'rx_cnt_generic_12m', 'rx_cnt_maint_drug_12m', 'rx_cnt_rhtsrce_12m', 'rx_cnt_rx_12m', 'rx_cnt_tier1_12m', 'rx_cnt_tier2_12m', 'rx_cnt_tier3_12m', 'rx_cnt_tier4_12m', 'rx_cnt_uniq_pharm_12m', 'rx_mbr_resp_amt_12m', 'rx_paid_amt_12m', 'cnt_ind_maint_drug_12m', 'multi_mth_maint_drug_ind_12m', 'ind_rtsource_12m', 'rtsource_only_12m',
             'generic_only_12m', 'maint_drug_only_12m','conversion_ind']
cond_var = ['mbr_pers_gen_key','IND_AB_GASTRO','IND_AB_PAIN','IND_ANTINEO_CH','IND_ASMA','IND_BACK_ANY','IND_BACK_CERV','IND_BACK_LUMBAR','IND_BACK_SACRUM','IND_BACK_THORAC','IND_BACK_UNSPEC','IND_BONE_DENS','IND_BRAIN_HMRG','IND_BRSTCNCR','IND_BRTH_ASMA','IND_CAD','IND_CANC_HIST','IND_CANC_SCRN','IND_CBRONCH','IND_CHESTPAIN','IND_CHILD_XM','IND_CKD','IND_CPD','IND_CTD','IND_CVD','IND_DEM','IND_DEPR','IND_DIA','IND_DISCRDIET',
            'IND_DISCRDIS','IND_DISCRINJ','IND_DISCRMNG','IND_DISCRNO','IND_DISCRPHY','IND_DISCRPREG','IND_ESRD','IND_GALLBLADD','IND_HEADFRACT','IND_HF','IND_HIV','IND_HPL','IND_HYPERL','IND_HYPERT','IND_LEU','IND_LEUKEMIA','IND_LUP','IND_LYM','IND_MALIGNEO','IND_MAMMODIA','IND_MAMMOSCR','IND_MI','IND_MLD','IND_MPHZMA','IND_MRD','IND_MST','IND_ORTHO_BACK','IND_OSTEO','IND_OSTEOARTH','IND_POSTOPINF','IND_PREG','IND_PREGANTEP','IND_PREGCSEC','IND_PREGNONRO','IND_PVD','IND_RA','IND_REHAB','IND_SCOLIOSIS','IND_SLD','IND_STENOSIS',
             'IND_STROKE','IND_TUM','IND_ULC','IND_UTER_FIBR','conversion_ind']
bseg_var = ['mbr_pers_gen_key','ind_segment_mapd_new', 'ind_segment_mapd_c1', 'ind_segment_mapd_c2','ind_segment_mapd_c3', 'ind_segment_mapd_c4', 'ind_segment_mapd_c5', 'ind_segment_mapd_c6', 'ind_segment_mapd_c7', 'ind_segment_mapd_h1', 'ind_segment_mapd_h2', 'ind_segment_mapd_h3', 'ind_segment_mapd_h4', 'ind_segment_mapd_h5', 'ind_segment_mapd_h6', 'ind_segment_mapd_h7', 'ind_segment_mapd_h8', 'ind_seg_engaged',
            'ind_segment_pdp_new', 'ind_segment_pdp_p1', 'ind_segment_pdp_p2', 'ind_segment_pdp_p3',
             'ind_segment_pdp_p4','ind_segment_pdp_p5', 'ind_segment_pdp_p6', 'ind_segment_pdp_p7','conversion_ind']
pgm_var = ['mbr_pers_gen_key','current_pgm_part', 'pgm_participate','pgm_days_chf_ivr', 'pgm_chf_ivr', 'pgm_days_transplant', 'pgm_transplant', 'pgm_days_personal_nurse', 'pgm_personal_nurse', 'pgm_days_hc_snp', 'pgm_hc_snp', 'pgm_days_medicare_medicaid_duals', 'pgm_medicare_medicaid_duals', 'pgm_days_neonatal', 'pgm_neonatal', 'pgm_days_hc_careplus_snp', 'pgm_hc_careplus_snp', 'pgm_days_end_stage_renal_disease', 'pgm_end_stage_renal_disease', 'pgm_days_pn_self_managed', 'pgm_pn_self_managed', 'pgm_days_commercial_case_management', 'pgm_commercial_case_management', 'pgm_days_internal_diabetes', 'pgm_internal_diabetes', 'pgm_days_inhome_surveys', 'pgm_inhome_surveys', 'pgm_days_hc_core', 'pgm_hc_core', 'pgm_days_humana_beginnings', 'pgm_humana_beginnings', 'pgm_days_humana_chronic_care_program', 'pgm_humana_chronic_care_program', 'pgm_days_senior_case_management', 'pgm_senior_case_management', 'pgm_days_silver_sneakers','pgm_silver_sneakers', 'pgm_days_hc_congestive_heart_failure', 'pgm_hc_congestive_heart_failure',
            'pgm_days_transitions', 'pgm_transitions','conversion_ind']
phar_vend_var = ['mbr_pers_gen_key','sum_drug_store_chn_12m', 'sum_grocery_store_12m', 'sum_walmart_12m', 'sum_kmart_12m', 'sum_target_12m', 'sum_costco_12m', 'sum_walgreen_12m', 'sum_cvs_12m', 'sum_riteaid_12m', 'sum_medicine_shoppe_12m', 'sum_safeway_12m', 'sum_caremark_12m', 'ind_drug_store_chn_12m', 'ind_grocery_store_12m', 'ind_walmart_12m', 'ind_kmart_12m', 'ind_target_12m', 'ind_costco_12m', 'ind_walgreen_12m', 'ind_cvs_12m', 'ind_riteaid_12m', 'ind_medicine_shoppe_12m',
                 'ind_safeway_12m','ind_caremark_12m','conversion_ind']
drug_var = ['mbr_pers_gen_key','drug_count_12m', 'uniq_drug_class_cnt_12m','cnt_dg_antibiotics_12m', 'cnt_dg_anxiety_12m', 'cnt_dg_blood_platelet_thinner_12m','cnt_dg_cancer_12m', 'cnt_dg_cardio_12m', 'cnt_dg_depression_12m', 'cnt_dg_derm_12m', 'cnt_dg_diabetes_12m', 'cnt_dg_female_12m', 'cnt_dg_gastro_12m', 'cnt_dg_growth_hormone_12m','cnt_dg_hiv_12m', 'cnt_dg_immunosup_agents_12m', 'cnt_dg_laxative_bladder_12m', 'cnt_dg_male_12m', 'cnt_dg_neuro_12m', 'cnt_dg_osteoporosis_12m', 'cnt_dg_other_12m', 'cnt_dg_other_anti_infect_12m', 'cnt_dg_pain_12m', 'cnt_dg_psych_12m', 'cnt_dg_respiratory_12m', 'cnt_dg_sense_organs_12m', 'cnt_dg_sleep_12m', 'cnt_dg_steroids_12m', 'cnt_dg_stimulants_12m', 'cnt_dg_sups_12m', 'cnt_dg_thyroid_12m', 'ind_dg_antibiotics_12m', 'ind_dg_anxiety_12m', 'ind_dg_blood_platelet_thinner_12m', 'ind_dg_cancer_12m', 'ind_dg_cardio_12m', 'ind_dg_depression_12m', 'ind_dg_derm_12m', 'ind_dg_diabetes_12m', 'ind_dg_female_12m', 'ind_dg_gastro_12m', 'ind_dg_growth_hormone_12m', 'ind_dg_hiv_12m', 'ind_dg_immunosup_agents_12m', 'ind_dg_laxative_bladder_12m', 'ind_dg_male_12m', 'ind_dg_neuro_12m', 'ind_dg_osteoporosis_12m', 'ind_dg_other_12m', 'ind_dg_other_anti_infect_12m', 'ind_dg_pain_12m', 'ind_dg_psych_12m', 'ind_dg_respiratory_12m', 'ind_dg_sense_organs_12m', 'ind_dg_sleep_12m', 'ind_dg_steroids_12m', 'ind_dg_stimulants_12m', 'ind_dg_sups_12m', 'ind_dg_thyroid_12m', 'ind_donut_hole_12m', 'cnt_donut_hole_12m', 'ts_last_antibiotics', 'ts_last_anxiety', 'ts_last_blood_platelet_thinner', 'ts_last_cancer', 'ts_last_cardio', 'ts_last_depression', 'ts_last_derm', 'ts_last_diabetes', 'ts_last_female','ts_last_gastro', 'ts_last_growth_hormone', 'ts_last_hiv', 'ts_last_immunosup_agents', 'ts_last_laxative_bladder', 'ts_last_male', 'ts_last_neuro', 'ts_last_osteoporosis', 'ts_last_other', 'ts_last_other_anti_infect', 'ts_last_pain', 'ts_last_psych', 'ts_last_respiratory', 'ts_last_sense_organs', 'ts_last_sleep',
            'ts_last_steroids', 'ts_last_stimulants', 'ts_last_sups', 'ts_last_thyroid','conversion_ind']
call_var = ['mbr_pers_gen_key','ind_calls_12m', 'ind_inq_12m', 'cnt_calls_12m', 'cnt_inq_12m','class_001_tag_12m', 'class_001_cnt_12m', 'class_002_tag_12m', 'class_002_cnt_12m', 'class_003_tag_12m', 'class_003_cnt_12m', 'class_004_tag_12m', 'class_004_cnt_12m', 'class_005_tag_12m', 'class_005_cnt_12m', 'class_006_tag_12m', 'class_006_cnt_12m', 'class_007_tag_12m', 'class_007_cnt_12m', 'class_008_tag_12m', 'class_008_cnt_12m', 'class_009_tag_12m', 'class_009_cnt_12m', 'class_010_tag_12m', 'class_010_cnt_12m', 'class_011_tag_12m', 'class_011_cnt_12m', 'class_012_tag_12m', 'class_012_cnt_12m', 'intent_001_tag_12m', 'intent_001_cnt_12m', 'intent_002_tag_12m', 'intent_002_cnt_12m','intent_003_tag_12m', 'intent_003_cnt_12m', 'intent_004_tag_12m', 'intent_004_cnt_12m', 'intent_005_tag_12m', 'intent_005_cnt_12m', 'intent_006_tag_12m', 'intent_006_cnt_12m', 'intent_007_tag_12m', 'intent_007_cnt_12m', 'intent_008_tag_12m', 'intent_008_cnt_12m', 'intent_009_tag_12m', 'intent_009_cnt_12m', 'intent_010_tag_12m', 'intent_010_cnt_12m', 'intent_011_tag_12m', 'intent_011_cnt_12m', 'intent_012_tag_12m', 'intent_012_cnt_12m', 'intent_013_tag_12m', 'intent_013_cnt_12m', 'intent_014_tag_12m', 'intent_014_cnt_12m', 'intent_015_tag_12m', 'intent_015_cnt_12m', 'intent_016_tag_12m', 'intent_016_cnt_12m', 'intent_017_tag_12m','intent_017_cnt_12m', 'intent_018_tag_12m', 'intent_018_cnt_12m', 'intent_019_tag_12m', 'intent_019_cnt_12m', 'intent_020_tag_12m', 'intent_020_cnt_12m', 'intent_021_tag_12m', 'intent_021_cnt_12m', 'intent_022_tag_12m', 'intent_022_cnt_12m', 'intent_023_tag_12m',
             'intent_023_cnt_12m', 'intent_024_tag_12m', 'intent_024_cnt_12m', 'ts_last_call','conversion_ind']
factor_var = ['mbr_pers_gen_key','FACTOR1', 'FACTOR2', 'FACTOR3', 'FACTOR4', 'FACTOR5', 'FACTOR6', 'FACTOR7', 'FACTOR8', 'FACTOR9', 'FACTOR10', 'FACTOR11', 'FACTOR12', 'FACTOR13', 'FACTOR14',
              'FACTOR15','conversion_ind']
final_var = ['pgk','mbr_pers_gen_key','hiempins','ntwperyr','lwcm07','lwcm05','lwcm08','lwcm11','chva','n2pwh',
             'tenure','age',
             'ts_last_login','cnt_cp_emails_12m','acq_ch_career','cnt_cp_webstatement_12m','cnt_cp_vat_12m','cnt_cp_print_12m','login_days_12m',
             'rx_mbr_resp_amt_12m','rx_allowed_amt_12m','rx_paid_amt_12m','rx_cnt_rhtsrce_12m','ind_rtsource_12m',
             'IND_STROKE','IND_DISCRMNG','IND_DEPR','IND_OSTEO','IND_DIA','IND_HYPERL',
             'ind_segment_pdp_p1','ind_seg_engaged','ind_segment_mapd_new', 'ind_segment_pdp_new',
             'pgm_participate','current_pgm_part','pgm_days_silver_sneakers','pgm_days_transitions','pgm_days_humana_beginnings','pgm_days_humana_chronic_care_program',
             'drug_count_12m','sum_walgreen_12m','sum_walmart_12m','sum_cvs_12m','sum_grocery_store_12m',
             'ts_last_call','cnt_calls_12m','ind_inq_12m','FACTOR15',
             'conversion_ind']


mail_explore_query = f"""
    SELECT
        *
    FROM
        consumer_work.recommender_engine_hop_trad_mail_datapull
    WHERE
        mbr_pers_gen_key in (SELECT mbr_pers_gen_key FROM {mail_base_name})
"""

mail_explore_query2 = f"""
    SELECT
        a.*
        ,b.conversion_ind
    FROM
        ({mail_explore_query}) a LEFT JOIN {mail_base_name} b on a.mbr_pers_gen_key = b.mbr_pers_gen_key
"""

mail_data = hdputils.doquery(spark, mail_explore_query2)

###########################################################
mail_test = mail_data.select(pharm_var).cache()
seed = 1990


# Spliting in train and test set. Beware : It sorts the dataset
(mail_downsample_df, throwaway_) = mail_test.randomSplit([0.5,0.5],seed)
(traindf_, testdf) = mail_downsample_df.randomSplit([0.8,0.2],seed)
(traindf, valdf) = traindf_.randomSplit([0.8,0.2],seed)

# Class Distribution for the training and test set
print('TRAIN')
print('Total # Records',traindf.count())
print(traindf.groupBy("conversion_ind").count().take(2))
# print(traindf.select(f.sum(f.when(f.col('rx_enroll') == 1, 1)).alias('rx_enroll == 1')).show(truncate=False))

print('\n','VAL')
print('Total # Records',valdf.count())
print(valdf.groupBy("conversion_ind").count().take(2))

print('\n','TEST')
print('Total # Records',testdf.count())
print(testdf.groupBy("conversion_ind").count().take(2))
###########################################################

# Downsample dataset
# Before Resampling
print('\n','Resampled Training Set: ')
print('Number of class 0 samples before:',traindf.filter("conversion_ind=0.0").count())

# Downsample dataset
traindf_zero = traindf.filter("conversion_ind=0.0")
traindf_one = traindf.filter("conversion_ind=1.0")

traindf_sampleRatio = traindf_one.count() / traindf.count()
traindf_zero_downsample = traindf_zero.sample(withReplacement=False,fraction=traindf_sampleRatio+.001,seed=seed) #fraction = % you want to draw from that sample
traindf_sampled = traindf_one.unionAll(traindf_zero_downsample)

# After Resampling
print('Number of class 0 samples after:',traindf_zero_downsample.count())
print('Number of class 1 samples after:',traindf_one.count())
print(traindf_sampled.groupBy("conversion_ind").count().take(2))

mail_traindf = traindf_sampled.toPandas()
mail_traindf.sort_values(by ='mbr_pers_gen_key',inplace=True)
mail_traindf['conversion_ind'] = mail_traindf.conversion_ind.astype(int)

mail_valdf = valdf.toPandas()
mail_valdf.sort_values(by ='mbr_pers_gen_key',inplace=True)
mail_valdf['conversion_ind'] = mail_valdf.conversion_ind.astype(int)

mail_testdf = testdf.toPandas()
mail_testdf.sort_values(by ='mbr_pers_gen_key',inplace=True)
mail_testdf['conversion_ind'] = mail_testdf.conversion_ind.astype(int)

email_mail_explore_query = f"""
    SELECT
        *
    FROM
        consumer_work.recommender_engine_hop_trad_email_datapull
    WHERE
        mbr_pers_gen_key in (SELECT mbr_pers_gen_key FROM {email_mail_base_name})
"""

email_mail_explore_query2 = f"""
    SELECT
        a.*
        ,b.conversion_ind
    FROM
        ({email_mail_explore_query}) a LEFT JOIN {email_mail_base_name} b on a.mbr_pers_gen_key = b.mbr_pers_gen_key
"""

email_data = hdputils.doquery(spark, email_mail_explore_query2)

###########################################################
email_test = email_data.select(contact_var).cache()
seed = 1990


# Spliting in train and test set. Beware : It sorts the dataset
(email_downsample_df, throwaway_) = email_test.randomSplit([0.5,0.5],seed)
(traindf_, testdf) = email_downsample_df.randomSplit([0.8,0.2],seed)
(traindf, valdf) = traindf_.randomSplit([0.8,0.2],seed)

# Class Distribution for the training and test set
print('TRAIN')
print('Total # Records',traindf.count())
print(traindf.groupBy("conversion_ind").count().take(2))
# print(traindf.select(f.sum(f.when(f.col('rx_enroll') == 1, 1)).alias('rx_enroll == 1')).show(truncate=False))

print('\n','VAL')
print('Total # Records',valdf.count())
print(valdf.groupBy("conversion_ind").count().take(2))

print('\n','TEST')
print('Total # Records',testdf.count())
print(testdf.groupBy("conversion_ind").count().take(2))
###########################################################

# Downsample dataset
# Before Resampling
print('\n','Resampled Training Set: ')
print('Number of class 0 samples before:',traindf.filter("conversion_ind=0.0").count())

# Downsample dataset
traindf_zero = traindf.filter("conversion_ind=0.0")
traindf_one = traindf.filter("conversion_ind=1.0")

traindf_sampleRatio = traindf_one.count() / traindf.count()
traindf_zero_downsample = traindf_zero.sample(withReplacement=False,fraction=traindf_sampleRatio+.001,seed=seed) #fraction = % you want to draw from that sample
traindf_sampled = traindf_one.unionAll(traindf_zero_downsample)

# After Resampling
print('Number of class 0 samples after:',traindf_zero_downsample.count())
print('Number of class 1 samples after:',traindf_one.count())
print(traindf_sampled.groupBy("conversion_ind").count().take(2))

email_traindf = traindf_sampled.toPandas()
email_traindf.sort_values(by ='mbr_pers_gen_key',inplace=True)
email_traindf['conversion_ind'] = email_traindf.conversion_ind.astype(int)

email_valdf = valdf.toPandas()
email_valdf.sort_values(by ='mbr_pers_gen_key',inplace=True)
email_valdf['conversion_ind'] = email_valdf.conversion_ind.astype(int)

email_testdf = testdf.toPandas()
email_testdf.sort_values(by ='mbr_pers_gen_key',inplace=True)
email_testdf['conversion_ind'] = email_testdf.conversion_ind.astype(int)

rxe_explore_query = f"""
    SELECT
        *
    FROM
        consumer_work.recommender_engine_rxe_datapull
    WHERE
        mbr_pers_gen_key in (SELECT mbr_pers_gen_key FROM {rxe_mail_base_name})
"""

rxe_explore_query2 = f"""
    SELECT
        a.*
        ,b.conversion_ind
    FROM
        ({rxe_explore_query}) a LEFT JOIN {rxe_mail_base_name} b on a.mbr_pers_gen_key = b.mbr_pers_gen_key
"""

rxe_data = hdputils.doquery(spark, rxe_explore_query2)

###########################################################
###########################################################
rxe_test = rxe_data.select(pharm_var).cache()
seed = 1990


# Spliting in train and test set. Beware : It sorts the dataset
(rxe_downsample_df, throwaway_) = rxe_test.randomSplit([0.5,0.5],seed)
(traindf_, testdf) = rxe_downsample_df.randomSplit([0.8,0.2],seed)
(traindf, valdf) = traindf_.randomSplit([0.8,0.2],seed)

# Class Distribution for the training and test set
print('TRAIN')
print('Total # Records',traindf.count())
print(traindf.groupBy("conversion_ind").count().take(2))
# print(traindf.select(f.sum(f.when(f.col('rx_enroll') == 1, 1)).alias('rx_enroll == 1')).show(truncate=False))

print('\n','VAL')
print('Total # Records',valdf.count())
print(valdf.groupBy("conversion_ind").count().take(2))

print('\n','TEST')
print('Total # Records',testdf.count())
print(testdf.groupBy("conversion_ind").count().take(2))
###########################################################

# Downsample dataset
# Before Resampling
print('\n','Resampled Training Set: ')
print('Number of class 0 samples before:',traindf.filter("conversion_ind=0.0").count())

# Downsample dataset
traindf_zero = traindf.filter("conversion_ind=0.0")
traindf_one = traindf.filter("conversion_ind=1.0")

traindf_sampleRatio = traindf_one.count() / traindf.count()
traindf_zero_downsample = traindf_zero.sample(withReplacement=False,fraction=traindf_sampleRatio+.001,seed=seed) #fraction = % you want to draw from that sample
traindf_sampled = traindf_one.unionAll(traindf_zero_downsample)

# After Resampling
print('Number of class 0 samples after:',traindf_zero_downsample.count())
print('Number of class 1 samples after:',traindf_one.count())
print(traindf_sampled.groupBy("conversion_ind").count().take(2))

rxe_traindf = traindf_sampled.toPandas()
rxe_traindf.sort_values(by ='mbr_pers_gen_key',inplace=True)
rxe_traindf['conversion_ind'] = rxe_traindf.conversion_ind.astype(int)

rxe_valdf = valdf.toPandas()
rxe_valdf.sort_values(by ='mbr_pers_gen_key',inplace=True)
rxe_valdf['conversion_ind'] = rxe_valdf.conversion_ind.astype(int)

rxe_testdf = testdf.toPandas()
rxe_testdf.sort_values(by ='mbr_pers_gen_key',inplace=True)
rxe_testdf['conversion_ind'] = rxe_testdf.conversion_ind.astype(int)

all_explore_query = f"""
    SELECT
        mbr_pers_gen_key as pgk
        ,conversion_ind
    FROM
        consumer_work.recommender_engine_hop_trad_mail_email_rxe_all_members
"""

all_explore_query2 = f"""
    SELECT
        a.*
        ,b.*
    FROM
        ({all_explore_query}) a LEFT JOIN consumer_work.recommender_engine_hop_trad_mail_datapull b on a.pgk = b.mbr_pers_gen_key
"""

all_explore_query3 = f"""
    SELECT
        a.*
        ,c.*
    FROM
        ({all_explore_query}) a LEFT JOIN consumer_work.recommender_engine_hop_trad_email_datapull c on a.pgk = c.mbr_pers_gen_key
"""

all_explore_query4 = f"""
    SELECT
        a.*
        ,d.*
    FROM
        ({all_explore_query}) a LEFT JOIN consumer_work.recommender_engine_rxe_datapull d on a.pgk = d.mbr_pers_gen_key
"""

all_explore_concat = f"""
    SELECT
        *
    FROM
        ({all_explore_query2} UNION ALL {all_explore_query3} UNION ALL {all_explore_query4})
"""

all_data = hdputils.doquery(spark, all_explore_concat)

###########################################################
###########################################################
# all_test = all_data.cache()
all_test = all_data.select(final_var).cache()
seed = 1990


# Spliting in train and test set. Beware : It sorts the dataset
(all_downsample_df, throwaway_) = all_test.randomSplit([0.5,0.5],seed)
(traindf_, testdf) = all_downsample_df.randomSplit([0.8,0.2],seed)
(traindf, valdf) = traindf_.randomSplit([0.8,0.2],seed)

# Class Distribution for the training and test set
print('TRAIN')
print('Total # Records',traindf.count())
print(traindf.groupBy("conversion_ind").count().take(2))
# print(traindf.select(f.sum(f.when(f.col('rx_enroll') == 1, 1)).alias('rx_enroll == 1')).show(truncate=False))

print('\n','VAL')
print('Total # Records',valdf.count())
print(valdf.groupBy("conversion_ind").count().take(2))

print('\n','TEST')
print('Total # Records',testdf.count())
print(testdf.groupBy("conversion_ind").count().take(2))
###########################################################

# Downsample dataset
# Before Resampling
print('\n','Resampled Training Set: ')
print('Number of class 0 samples before:',traindf.filter("conversion_ind=0.0").count())

# Downsample dataset
traindf_zero = traindf.filter("conversion_ind=0.0")
traindf_one = traindf.filter("conversion_ind=1.0")

traindf_sampleRatio = traindf_one.count() / traindf.count()
traindf_zero_downsample = traindf_zero.sample(withReplacement=False,fraction=traindf_sampleRatio+.001,seed=seed) #fraction = % you want to draw from that sample
traindf_sampled = traindf_one.unionAll(traindf_zero_downsample)

# After Resampling
print('Number of class 0 samples after:',traindf_zero_downsample.count())
print('Number of class 1 samples after:',traindf_one.count())
print(traindf_sampled.groupBy("conversion_ind").count().take(2))

all_traindf = traindf_sampled.toPandas()
all_traindf.columns.values[1] = "duplicate_pgk"
all_traindf.columns.values[0] = "mbr_pers_gen_key"
all_traindf = all_traindf.drop(columns='duplicate_pgk')
all_traindf.sort_values(by ='mbr_pers_gen_key',inplace=True)
all_traindf['conversion_ind'] = all_traindf.conversion_ind.astype(int)
# # Quick & Dirty Collapse data for duplications
all_traindf = all_traindf.sort_values(by=['mbr_pers_gen_key','conversion_ind'],ascending=False)
all_traindf = all_traindf.groupby('mbr_pers_gen_key', as_index=False).first()

all_valdf = valdf.toPandas()
all_valdf.columns.values[1] = "duplicate_pgk"
all_valdf.columns.values[0] = "mbr_pers_gen_key"
all_valdf = all_valdf.drop(columns='duplicate_pgk')
all_valdf.sort_values(by ='mbr_pers_gen_key',inplace=True)
all_valdf['conversion_ind'] = all_valdf.conversion_ind.astype(int)
# # Quick & Dirty Collapse data for duplications
all_valdf = all_valdf.sort_values(by=['mbr_pers_gen_key','conversion_ind'],ascending=False)
all_valdf = all_valdf.groupby('mbr_pers_gen_key', as_index=False).first()

all_testdf = testdf.toPandas()
all_testdf.columns.values[1] = "duplicate_pgk"
all_testdf.columns.values[0] = "mbr_pers_gen_key"
all_testdf = all_testdf.drop(columns='duplicate_pgk')
all_testdf.sort_values(by ='mbr_pers_gen_key',inplace=True)
all_testdf['conversion_ind'] = all_testdf.conversion_ind.astype(int)
# # Quick & Dirty Collapse data for duplications
all_testdf = all_testdf.sort_values(by=['mbr_pers_gen_key','conversion_ind'],ascending=False)
all_testdf = all_testdf.groupby('mbr_pers_gen_key', as_index=False).first()

## Step 4: Explore Features by Channel

from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.utils import resample

from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import brier_score_loss
from sklearn.metrics import f1_score
from sklearn.metrics import roc_auc_score, roc_curve, auc

import matplotlib.pyplot as plt
import seaborn as sns
import pickle

# Columns
# amlk_var = ['mbr_pers_gen_key', 'lwcm11','hiempins','lwcm08','lwcm05','chva','lwcm06','lwcm07','lwcm04'
#             ,'ntwperyr','lwcm10','lwcm12','lwcm09','lwcm03','meda','n2poo','lwcm02'
#             ,'cwht','pdpe','ccip','cblu','n2pwc','n2psu','chmi','n2pmr','n2pwh'
#             ,'n2phi','cgqs','n2mah','hlthunin','n2pdv','conversion_ind']
# amlk_var = ['mbr_pers_gen_key', 'hiempins','lwcm11','lwcm08','lwcm07','lwcm05'
#             ,'ntwperyr','conversion_ind']
# demographic_var = ['mbr_pers_gen_key','age', 'tenure','conversion_ind']
# contact_var = ['mbr_pers_gen_key','cnt_cp_emails_12m', 'cnt_cp_print_12m', 'cnt_cp_vat_12m', 'cnt_cp_webstatement_12m', 'cnt_cp_livecall_12m', 'acq_ch_deleg_agent', 'acq_ch_career', 'acq_ch_telesales', 'acq_ch_d2c_online', 'acq_ch_unk',
#                'login_count_12m', 'login_days_12m', 'myhumana_log_12m', 'ts_last_login','conversion_ind']
# pharm_var = ['mbr_pers_gen_key','rx_allowed_amt_12m', 'rx_cnt_generic_12m', 'rx_cnt_maint_drug_12m', 'rx_cnt_rhtsrce_12m', 'rx_cnt_rx_12m', 'rx_cnt_tier1_12m', 'rx_cnt_tier2_12m', 'rx_cnt_tier3_12m', 'rx_cnt_tier4_12m', 'rx_cnt_uniq_pharm_12m', 'rx_mbr_resp_amt_12m', 'rx_paid_amt_12m', 'cnt_ind_maint_drug_12m', 'multi_mth_maint_drug_ind_12m', 'ind_rtsource_12m', 'rtsource_only_12m',
#              'generic_only_12m', 'maint_drug_only_12m','conversion_ind']
# cond_var = ['mbr_pers_gen_key','IND_AB_GASTRO','IND_AB_PAIN','IND_ANTINEO_CH','IND_ASMA','IND_BACK_ANY','IND_BACK_CERV','IND_BACK_LUMBAR','IND_BACK_SACRUM','IND_BACK_THORAC','IND_BACK_UNSPEC','IND_BONE_DENS','IND_BRAIN_HMRG','IND_BRSTCNCR','IND_BRTH_ASMA','IND_CAD','IND_CANC_HIST','IND_CANC_SCRN','IND_CBRONCH','IND_CHESTPAIN','IND_CHILD_XM','IND_CKD','IND_CPD','IND_CTD','IND_CVD','IND_DEM','IND_DEPR','IND_DIA','IND_DISCRDIET',
#             'IND_DISCRDIS','IND_DISCRINJ','IND_DISCRMNG','IND_DISCRNO','IND_DISCRPHY','IND_DISCRPREG','IND_ESRD','IND_GALLBLADD','IND_HEADFRACT','IND_HF','IND_HIV','IND_HPL','IND_HYPERL','IND_HYPERT','IND_LEU','IND_LEUKEMIA','IND_LUP','IND_LYM','IND_MALIGNEO','IND_MAMMODIA','IND_MAMMOSCR','IND_MI','IND_MLD','IND_MPHZMA','IND_MRD','IND_MST','IND_ORTHO_BACK','IND_OSTEO','IND_OSTEOARTH','IND_POSTOPINF','IND_PREG','IND_PREGANTEP','IND_PREGCSEC','IND_PREGNONRO','IND_PVD','IND_RA','IND_REHAB','IND_SCOLIOSIS','IND_SLD','IND_STENOSIS',
#              'IND_STROKE','IND_TUM','IND_ULC','IND_UTER_FIBR','conversion_ind']
# bseg_var = ['mbr_pers_gen_key','ind_segment_mapd_new', 'ind_segment_mapd_c1', 'ind_segment_mapd_c2','ind_segment_mapd_c3', 'ind_segment_mapd_c4', 'ind_segment_mapd_c5', 'ind_segment_mapd_c6', 'ind_segment_mapd_c7', 'ind_segment_mapd_h1', 'ind_segment_mapd_h2', 'ind_segment_mapd_h3', 'ind_segment_mapd_h4', 'ind_segment_mapd_h5', 'ind_segment_mapd_h6', 'ind_segment_mapd_h7', 'ind_segment_mapd_h8', 'ind_seg_engaged',
#             'ind_segment_pdp_new', 'ind_segment_pdp_p1', 'ind_segment_pdp_p2', 'ind_segment_pdp_p3',
#              'ind_segment_pdp_p4','ind_segment_pdp_p5', 'ind_segment_pdp_p6', 'ind_segment_pdp_p7','conversion_ind']
# pgm_var = ['mbr_pers_gen_key','current_pgm_part', 'pgm_participate','pgm_days_chf_ivr', 'pgm_chf_ivr', 'pgm_days_transplant', 'pgm_transplant', 'pgm_days_personal_nurse', 'pgm_personal_nurse', 'pgm_days_hc_snp', 'pgm_hc_snp', 'pgm_days_medicare_medicaid_duals', 'pgm_medicare_medicaid_duals', 'pgm_days_neonatal', 'pgm_neonatal', 'pgm_days_hc_careplus_snp', 'pgm_hc_careplus_snp', 'pgm_days_end_stage_renal_disease', 'pgm_end_stage_renal_disease', 'pgm_days_pn_self_managed', 'pgm_pn_self_managed', 'pgm_days_commercial_case_management', 'pgm_commercial_case_management', 'pgm_days_internal_diabetes', 'pgm_internal_diabetes', 'pgm_days_inhome_surveys', 'pgm_inhome_surveys', 'pgm_days_hc_core', 'pgm_hc_core', 'pgm_days_humana_beginnings', 'pgm_humana_beginnings', 'pgm_days_humana_chronic_care_program', 'pgm_humana_chronic_care_program', 'pgm_days_senior_case_management', 'pgm_senior_case_management', 'pgm_days_silver_sneakers','pgm_silver_sneakers', 'pgm_days_hc_congestive_heart_failure', 'pgm_hc_congestive_heart_failure',
#             'pgm_days_transitions', 'pgm_transitions','conversion_ind']
# phar_vend_var = ['mbr_pers_gen_key','sum_drug_store_chn_12m', 'sum_grocery_store_12m', 'sum_walmart_12m', 'sum_kmart_12m', 'sum_target_12m', 'sum_costco_12m', 'sum_walgreen_12m', 'sum_cvs_12m', 'sum_riteaid_12m', 'sum_medicine_shoppe_12m', 'sum_safeway_12m', 'sum_caremark_12m', 'ind_drug_store_chn_12m', 'ind_grocery_store_12m', 'ind_walmart_12m', 'ind_kmart_12m', 'ind_target_12m', 'ind_costco_12m', 'ind_walgreen_12m', 'ind_cvs_12m', 'ind_riteaid_12m', 'ind_medicine_shoppe_12m',
#                  'ind_safeway_12m','ind_caremark_12m','conversion_ind']
# drug_var = ['mbr_pers_gen_key','drug_count_12m', 'uniq_drug_class_cnt_12m','cnt_dg_antibiotics_12m', 'cnt_dg_anxiety_12m', 'cnt_dg_blood_platelet_thinner_12m','cnt_dg_cancer_12m', 'cnt_dg_cardio_12m', 'cnt_dg_depression_12m', 'cnt_dg_derm_12m', 'cnt_dg_diabetes_12m', 'cnt_dg_female_12m', 'cnt_dg_gastro_12m', 'cnt_dg_growth_hormone_12m','cnt_dg_hiv_12m', 'cnt_dg_immunosup_agents_12m', 'cnt_dg_laxative_bladder_12m', 'cnt_dg_male_12m', 'cnt_dg_neuro_12m', 'cnt_dg_osteoporosis_12m', 'cnt_dg_other_12m', 'cnt_dg_other_anti_infect_12m', 'cnt_dg_pain_12m', 'cnt_dg_psych_12m', 'cnt_dg_respiratory_12m', 'cnt_dg_sense_organs_12m', 'cnt_dg_sleep_12m', 'cnt_dg_steroids_12m', 'cnt_dg_stimulants_12m', 'cnt_dg_sups_12m', 'cnt_dg_thyroid_12m', 'ind_dg_antibiotics_12m', 'ind_dg_anxiety_12m', 'ind_dg_blood_platelet_thinner_12m', 'ind_dg_cancer_12m', 'ind_dg_cardio_12m', 'ind_dg_depression_12m', 'ind_dg_derm_12m', 'ind_dg_diabetes_12m', 'ind_dg_female_12m', 'ind_dg_gastro_12m', 'ind_dg_growth_hormone_12m', 'ind_dg_hiv_12m', 'ind_dg_immunosup_agents_12m', 'ind_dg_laxative_bladder_12m', 'ind_dg_male_12m', 'ind_dg_neuro_12m', 'ind_dg_osteoporosis_12m', 'ind_dg_other_12m', 'ind_dg_other_anti_infect_12m', 'ind_dg_pain_12m', 'ind_dg_psych_12m', 'ind_dg_respiratory_12m', 'ind_dg_sense_organs_12m', 'ind_dg_sleep_12m', 'ind_dg_steroids_12m', 'ind_dg_stimulants_12m', 'ind_dg_sups_12m', 'ind_dg_thyroid_12m', 'ind_donut_hole_12m', 'cnt_donut_hole_12m', 'ts_last_antibiotics', 'ts_last_anxiety', 'ts_last_blood_platelet_thinner', 'ts_last_cancer', 'ts_last_cardio', 'ts_last_depression', 'ts_last_derm', 'ts_last_diabetes', 'ts_last_female','ts_last_gastro', 'ts_last_growth_hormone', 'ts_last_hiv', 'ts_last_immunosup_agents', 'ts_last_laxative_bladder', 'ts_last_male', 'ts_last_neuro', 'ts_last_osteoporosis', 'ts_last_other', 'ts_last_other_anti_infect', 'ts_last_pain', 'ts_last_psych', 'ts_last_respiratory', 'ts_last_sense_organs', 'ts_last_sleep',
#             'ts_last_steroids', 'ts_last_stimulants', 'ts_last_sups', 'ts_last_thyroid','conversion_ind']
# call_var = ['mbr_pers_gen_key','ind_calls_12m', 'ind_inq_12m', 'cnt_calls_12m', 'cnt_inq_12m','class_001_tag_12m', 'class_001_cnt_12m', 'class_002_tag_12m', 'class_002_cnt_12m', 'class_003_tag_12m', 'class_003_cnt_12m', 'class_004_tag_12m', 'class_004_cnt_12m', 'class_005_tag_12m', 'class_005_cnt_12m', 'class_006_tag_12m', 'class_006_cnt_12m', 'class_007_tag_12m', 'class_007_cnt_12m', 'class_008_tag_12m', 'class_008_cnt_12m', 'class_009_tag_12m', 'class_009_cnt_12m', 'class_010_tag_12m', 'class_010_cnt_12m', 'class_011_tag_12m', 'class_011_cnt_12m', 'class_012_tag_12m', 'class_012_cnt_12m', 'intent_001_tag_12m', 'intent_001_cnt_12m', 'intent_002_tag_12m', 'intent_002_cnt_12m','intent_003_tag_12m', 'intent_003_cnt_12m', 'intent_004_tag_12m', 'intent_004_cnt_12m', 'intent_005_tag_12m', 'intent_005_cnt_12m', 'intent_006_tag_12m', 'intent_006_cnt_12m', 'intent_007_tag_12m', 'intent_007_cnt_12m', 'intent_008_tag_12m', 'intent_008_cnt_12m', 'intent_009_tag_12m', 'intent_009_cnt_12m', 'intent_010_tag_12m', 'intent_010_cnt_12m', 'intent_011_tag_12m', 'intent_011_cnt_12m', 'intent_012_tag_12m', 'intent_012_cnt_12m', 'intent_013_tag_12m', 'intent_013_cnt_12m', 'intent_014_tag_12m', 'intent_014_cnt_12m', 'intent_015_tag_12m', 'intent_015_cnt_12m', 'intent_016_tag_12m', 'intent_016_cnt_12m', 'intent_017_tag_12m','intent_017_cnt_12m', 'intent_018_tag_12m', 'intent_018_cnt_12m', 'intent_019_tag_12m', 'intent_019_cnt_12m', 'intent_020_tag_12m', 'intent_020_cnt_12m', 'intent_021_tag_12m', 'intent_021_cnt_12m', 'intent_022_tag_12m', 'intent_022_cnt_12m', 'intent_023_tag_12m',
#              'intent_023_cnt_12m', 'intent_024_tag_12m', 'intent_024_cnt_12m', 'ts_last_call','conversion_ind']
# factor_var = ['mbr_pers_gen_key','FACTOR1', 'FACTOR2', 'FACTOR3', 'FACTOR4', 'FACTOR5', 'FACTOR6', 'FACTOR7', 'FACTOR8', 'FACTOR9', 'FACTOR10', 'FACTOR11', 'FACTOR12', 'FACTOR13', 'FACTOR14',
#               'FACTOR15','conversion_ind']

final_var = ['mbr_pers_gen_key','hiempins','ntwperyr','lwcm07','lwcm05','lwcm08','lwcm11','chva','n2pwh',
             'tenure','age',
             'ts_last_login','cnt_cp_emails_12m','acq_ch_career','cnt_cp_webstatement_12m','cnt_cp_vat_12m','cnt_cp_print_12m','login_days_12m',
             'rx_mbr_resp_amt_12m','rx_allowed_amt_12m','rx_paid_amt_12m','rx_cnt_rhtsrce_12m','ind_rtsource_12m',
             'IND_STROKE','IND_DISCRMNG','IND_DEPR','IND_OSTEO','IND_DIA','IND_HYPERL',
             'ind_segment_pdp_p1','ind_seg_engaged','ind_segment_mapd_new', 'ind_segment_pdp_new',
             'pgm_participate','current_pgm_part','pgm_days_silver_sneakers','pgm_days_transitions','pgm_days_humana_beginnings','pgm_days_humana_chronic_care_program',
             'drug_count_12m','sum_walgreen_12m','sum_walmart_12m','sum_cvs_12m','sum_grocery_store_12m',
             'ts_last_call','cnt_calls_12m','ind_inq_12m','FACTOR15',
             'conversion_ind']



# Target Variable - Trad Mail Summary
# Test set
print(color.BOLD + color.UNDERLINE + 'Trad-Mail Summary:' + color.END)
print('Unique PGK - Trad Mail: ',mail_testdf.mbr_pers_gen_key.count())
print('Number of members converted Rx - Trad Mail: ',mail_testdf.conversion_ind.sum())
print('Conversion %: ',mail_testdf.conversion_ind.sum()/mail_testdf.mbr_pers_gen_key.count(),'(Doesnt include multiple scripts)')

# mail_df.apply(lambda x: x.fillna(x.mean()))
# df.fillna(0, inplace = True)
all_traindf.tail()

all_traindf_original = all_traindf.copy()
all_valdf_original = all_valdf.copy()
# all_traindf = all_traindf_original[factor_var]
# all_valdf = all_valdf_original[factor_var]

# Downsampling already done
seed = 1990

# Subset to features used for model
X_train = all_traindf.iloc[:,:-1].values
y_train = all_traindf.iloc[:,-1].values

X_val = all_valdf.iloc[:,:-1].values
y_val = all_valdf.iloc[:,-1].values

X_test = all_testdf.iloc[:,:-1].values
y_test = all_testdf.iloc[:,-1].values
##########################################################
# Class Distribution for the training and test set
print('TRAIN')
print(np.unique(y_train))
print(np.bincount(y_train))
print('PCT',(y_train==1).sum()/(y_train.shape[0])*100)

print('\n','VAL')
print(np.unique(y_val))
print(np.bincount(y_val))
print('PCT',(y_val==1).sum()/(y_val.shape[0])*100)

print('\n','TEST')
print(np.unique(y_test))
print(np.bincount(y_test))
print('PCT',(y_test==1).sum()/(y_test.shape[0])*100)
###########################################################
# Class Distribution for the training and test set
print('TRAIN')
print(np.unique(y_train))
print(np.bincount(y_train))
print('PCT',(y_train==1).sum()/(y_train.shape[0])*100)

print('\n','VALIDATION')
print(np.unique(y_val))
print(np.bincount(y_val))
print('PCT',(y_val==1).sum()/(y_val.shape[0])*100)
###########################################################
# Remove PGK from model
train = X_train
val = X_val
# test = X_test
X_train = X_train[:,1:]
X_val = X_val[:,1:]
# X_test = X_test[:,1:]
print(X_train.shape)
print(X_val.shape)
#print(X_test.shape)
###########################################################
# Fit Random Forest Classifier to Training Data
classifier = RandomForestClassifier(n_estimators=500,
                                    max_features = 'sqrt', # sqrt(num_of_features)
                                    criterion ='entropy', #gini samples per leaf = 30
#                                     class_weight = 'balanced',
                                    random_state=seed)

classifier.fit(X_train,y_train)

# Grab labels to plot feature Importance
feat_labels = all_traindf.columns[1:]

# Feat importance
feat_importances = classifier.feature_importances_
indices = np.argsort(feat_importances)[::-1]

# Print Feature Importance
for f in range(X_train.shape[1]):
    print("%2d) %-*s %f" % (f + 1, 30,
                            feat_labels[indices[f]],
                            feat_importances[indices[f]]))

# Plot Feature Importance
plt.title('Feature Importances')
plt.bar(range(X_train.shape[1]),
        feat_importances[indices],
        color='lightblue',
        align='center')

plt.xticks(range(X_train.shape[1]),
           feat_labels[indices], rotation=90)
plt.xlim([-1, X_train.shape[1]])
plt.tight_layout()
#plt.savefig('./random_forest.png', dpi=300)
plt.show()

# Probabilities
y_probas = classifier.predict_proba(X_val[:, :])
# classifier.predict(X_test_std[:10, :]) # Predict on n records
# classifier.predict(X_test_std[0, :].reshape(1,-1)) # Predict on 1 record

# Predict on Validation Set
y_pred = classifier.predict(X_val)

# Missclassified
print('Number of Misclassified: ',(y_val != y_pred).sum())

# Score on Validation set
print('Validation set score: ',classifier.score(X_val,y_val))
###########################################################
# Confusion Matrix
cm = confusion_matrix(y_val, y_pred)
print('[[True Negative, False Positive]')
print('[False Negative, True Positive]]')
print(cm)
###########################################################
# Recall (True Positive / Positive Cases (TP & FN)): True Positive Rate
# print('TRUE POSITIVE RATE (Recall or Sensitivity) =','TP / (TP+FN)')
# print('Accuracy: %.3f' % accuracy_score(y_true=y_test, y_pred=y_pred))
print('Recall: %.3f' % recall_score(y_true=y_val, y_pred=y_pred))
print('Precision: %.3f' % precision_score(y_true=y_val, y_pred=y_pred))

# False Postive Rate and True Positive Rate for all thresholds
fpr, tpr, threshold = roc_curve(y_val, y_probas[:,1])
roc_auc = auc(fpr,tpr)
roc_auc
print('AUC: %.3f' % roc_auc)

# f1_score(y_val, y_pred)
# classifier.classes_
print('Brier Score: %.4f' % brier_score_loss(y_val, y_probas[:,1]))

# Test Set Score
# Data Prep
test = X_test
X_test = X_test[:,1:]

# Probabilities
y_probas = classifier.predict_proba(X_test[:, :])
# classifier.predict(X_test_std[:10, :]) # Predict on n records
# classifier.predict(X_test_std[0, :].reshape(1,-1)) # Predict on 1 record

# Predict on Test Set
y_pred = classifier.predict(X_test)

# Missclassified
print('Number of Misclassified: ',(y_test != y_pred).sum())

# Score on Test set
print('Test set score: ',classifier.score(X_test,y_test))

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
print('[[True Negative, False Positive]')
print('[False Negative, True Positive]]')
print(cm)

# Recall (True Positive / Positive Cases (TP & FN)): True Positive Rate
# print('TRUE POSITIVE RATE (Recall or Sensitivity) =','TP / (TP+FN)')
# print('Accuracy: %.3f' % accuracy_score(y_true=y_test, y_pred=y_pred))
print('Recall: %.3f' % recall_score(y_true=y_test, y_pred=y_pred))
print('Precision: %.3f' % precision_score(y_true=y_test, y_pred=y_pred))

# False Postive Rate and True Positive Rate for all thresholds
fpr, tpr, threshold = roc_curve(y_test, y_probas[:,1])
roc_auc = auc(fpr,tpr)
roc_auc
print('AUC: %.3f' % roc_auc)
print('Brier Score: %.4f' % brier_score_loss(y_test, y_probas[:,1]))

# # Pickle model
# filename = 'all_rf_clf_all.sav'
# pickle.dump(classifier, open(filename, 'wb'))

# Deciles
# colnames = ['MBR_PERS_GEN_KEY',
#                   'NTWPERYR', 'CHVA',
#                   'RXNUM','HWRXLOYL',
#                   'TENURE_MBR_COV', 'HUM_AGE',
#                   'RX_ALLOWED_AMT_6M',
#                   'RX_CNT_MAINT_DRUG_6M','RX_CNT_RX_6M',
#                   'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
#                   'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
#                   'TS_LAST_LOGIN', 'TS_LAST_CALL',
#                   'RX_CNTRX_HPRX',
#                   'ENGAGED_MEMBERS','UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
#                  ]

# results = pd.DataFrame(test,columns = colnames)
# results['MBR_PERS_GEN_KEY'] = test[:,0].astype(np.int64)
# results['y_actual'] = y_test
# results['y_probas'] = y_probas[:,1]
# results['y_preds'] = y_pred
# results.head(5)
# #################################################################################
# # Results sorted by Probability Predicted
# results['decile']= pd.qcut(results.y_probas, 10
#        ,labels=[9,8,7,6,5,4,3,2,1,0])
# results_sort = results.sort_values(by='y_probas',ascending=False).reset_index()
# results_sort = results_sort.drop(['index'], axis=1)
# results_sort.head(5)
# #################################################################################
# # Decile Cut offs
# for decile in range(9):
#     print('-',decile,end=")")
#     print('\033[1m'+ 'Decile ' + str(decile) +'\033[0m',end=": ")
#     print(results_sort[results_sort.decile == decile].y_probas.min())

# ========================
# Columns to look at:
# ========================

# ========================
# Top Machine Columns:
# ========================
# age
# chva
# cnt_cp_emails_12m
# cnt_cp_print_12m
# cnt_cp_vat_12m
# cnt_cp_webstatement_12m
# cnt_ind_maint_drug_12m
# ind_rtsource_12m
# login_count_12m
# login_days_12m
# ntwperyr
# offline_buyer
# online_buyer
# rx_allowed_amt_12m
# rx_cnt_generic_12m
# rx_cnt_maint_drug_12m
# rx_cnt_rhtsrce_12m
# rx_cnt_rx_12m
# rx_cnt_tier1_12m
# rx_cnt_tier2_12m
# rx_cnt_tier3_12m
# rx_cnt_tier4_12m
# rx_cnt_uniq_pharm_12m
# rx_mbr_resp_amt_12m
# rx_paid_amt_12m
# rxadhm
# rxadhs
# rxbrand
# rxmaint
# rxnum
# rxsowrx
# rxsupp
# tenure
# ts_last_anxiety
# ts_last_call
# ts_last_cardio
# ts_last_depression
# ts_last_derm
# ts_last_diabetes
# ts_last_gastro
# ts_last_growth_hormone
# ts_last_laxative_bladder
# ts_last_login
# ts_last_male
# ts_last_other
# ts_last_respiratory
# ts_last_sense_organs

# =========================



df = pd.merge(hop_df,target, how = 'left', on = 'mbr_pers_gen_key')

## Step 2: ML for data exploration


from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.utils import resample

from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import brier_score_loss
from sklearn.metrics import f1_score
from sklearn.metrics import roc_auc_score, roc_curve, auc

import matplotlib.pyplot as plt
import seaborn as sns

# final_features = ['MBR_PERS_GEN_KEY',
#                   'NTWPERYR', 'CHVA',
#                   'RXNUM','HWRXLOYL',
#                   'TENURE_MBR_COV', 'HUM_AGE',
#                   'RX_ALLOWED_AMT_6M',
#                   'RX_CNT_MAINT_DRUG_6M','RX_CNT_RX_6M',
#                   'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
#                   'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
#                   'TS_LAST_LOGIN', 'TS_LAST_CALL',
#                   'RX_CNTRX_HPRX',
#                   'ENGAGED_MEMBERS',
#                   'UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
#                   'RX_ENROLL'
#                  ]
# df = df[final_features]
# df = df.drop(columns='ref_date')
df.fillna(0, inplace = True)

# Subset to features used for model
seed = 1990
X = df.iloc[:,:-1].values
y = df.iloc[:,-1].values
###########################################################
# Split to training & test
X_, X_test, y_, y_test = train_test_split(X, y, test_size = 0.2,random_state = seed)
X_train, X_val, y_train, y_val = train_test_split(X_, y_, test_size = 0.2,random_state = seed)


# Class Distribution for the training and test set
print('TRAIN')
print(np.unique(y_train))
print(np.bincount(y_train))
print('PCT',(y_train==1).sum()/(y_train.shape[0])*100)

print('\n','VAL')
print(np.unique(y_val))
print(np.bincount(y_val))
print('PCT',(y_val==1).sum()/(y_val.shape[0])*100)

print('\n','TEST')
print(np.unique(y_test))
print(np.bincount(y_test))
print('PCT',(y_test==1).sum()/(y_test.shape[0])*100)
###########################################################
# Downsample dataset
# Before Resampling
print('Number of class 0 samples before:',X_train[y_train == 0].shape[0])

# Downsample dataset
X_sampled, y_sampled = resample(X_train[y_train == 0], y_train[y_train == 0]
                                    ,n_samples = X_train[y_train == 1].shape[0]
                                    ,replace = True, random_state=seed)

# After Resampling
print('Number of class 0 samples after:',X_sampled.shape[0])
###########################################################
# Balanced Dataset
X_train = np.vstack((X_train[y_train == 1], X_sampled))
y_train = np.hstack((y_train[y_train == 1], y_sampled))

# Confirm Downsample
zero_ = np.ones(y_train.shape[0]) # Create 0 array
print('class ditrubution: ',np.mean(zero_ == y_train) * 100) # Class 0

# Class Distribution for the training and test set
print('TRAIN')
print(np.unique(y_train))
print(np.bincount(y_train))
print('PCT',(y_train==1).sum()/(y_train.shape[0])*100)

print('\n','VALIDATION')
print(np.unique(y_val))
print(np.bincount(y_val))
print('PCT',(y_val==1).sum()/(y_val.shape[0])*100)
###########################################################
# Remove PGK from model
train = X_train
val = X_val
# test = X_test
X_train = X_train[:,1:]
X_val = X_val[:,1:]
# X_test = X_test[:,1:]
print(X_train.shape)
print(X_val.shape)
#print(X_test.shape)
###########################################################
# Fit Random Forest Classifier to Training Data
classifier = RandomForestClassifier(n_estimators=500,
                                    max_features = 'sqrt', # sqrt(num_of_features)
                                    criterion ='entropy', #gini samples per leaf = 30
#                                     class_weight = 'balanced',
                                    random_state=seed)

classifier.fit(X_train,y_train)

# Grab labels to plot feature Importance
feat_labels = df.columns[1:]

# Feat importance
feat_importances = classifier.feature_importances_
indices = np.argsort(feat_importances)[::-1]

# Print Feature Importance
for f in range(X_train.shape[1]):
    print("%2d) %-*s %f" % (f + 1, 30,
                            feat_labels[indices[f]],
                            feat_importances[indices[f]]))

# Plot Feature Importance
plt.title('Feature Importances')
plt.bar(range(X_train.shape[1]),
        feat_importances[indices],
        color='lightblue',
        align='center')

plt.xticks(range(X_train.shape[1]),
           feat_labels[indices], rotation=90)
plt.xlim([-1, X_train.shape[1]])
plt.tight_layout()
#plt.savefig('./random_forest.png', dpi=300)
plt.show()

# Probabilities
y_probas = classifier.predict_proba(X_val[:, :])
# classifier.predict(X_test_std[:10, :]) # Predict on n records
# classifier.predict(X_test_std[0, :].reshape(1,-1)) # Predict on 1 record

# Predict on Validation Set
y_pred = classifier.predict(X_val)

# Missclassified
print('Number of Misclassified: ',(y_val != y_pred).sum())

# Score on Validation set
print('Validation set score: ',classifier.score(X_val,y_val))
###########################################################
# Confusion Matrix
cm = confusion_matrix(y_val, y_pred)
print('[[True Negative, False Positive]')
print('[False Negative, True Positive]]')
print(cm)
###########################################################
# Recall (True Positive / Positive Cases (TP & FN)): True Positive Rate
# print('TRUE POSITIVE RATE (Recall or Sensitivity) =','TP / (TP+FN)')
# print('Accuracy: %.3f' % accuracy_score(y_true=y_test, y_pred=y_pred))
print('Recall: %.3f' % recall_score(y_true=y_val, y_pred=y_pred))
print('Precision: %.3f' % precision_score(y_true=y_val, y_pred=y_pred))

# False Postive Rate and True Positive Rate for all thresholds
fpr, tpr, threshold = roc_curve(y_val, y_probas[:,1])
roc_auc = auc(fpr,tpr)
roc_auc
print('AUC: %.3f' % roc_auc)

# f1_score(y_val, y_pred)
# classifier.classes_
print('Brier Score: %.4f' % brier_score_loss(y_val, y_probas[:,1]))

import shap

# Create the SHAP explainer using the classifier
shap_explainer = shap.TreeExplainer(classifier)

# Calculate the Shapley Values for our Dataset(Train_Val & Test)
test_shap_vals = shap_explainer.shap_values(X_test) # array not df

df.columns[:]

X_val_df = pd.DataFrame(X_val,columns = df.columns[1:])

# Setup for Visual
shap.initjs()
# # Plot the explanation for a single prediction
# # 1 for the Predict 1 expected & SHAP values, looking at row 0 data
# shap.force_plot(shap_explainer.expected_value[1],test_shap_vals[1][0,:], X_test_df.iloc[0, :])


# # Plot explanations for whole dataset (Bunches samples by similiarty)
# shap.force_plot(shap_explainer.expected_value[1],test_shap_vals[1], X_test_df)

# Plots distribution of each feature's SHAP in a summary
shap.summary_plot(test_shap_vals[1], X_val_df, auto_size_plot=False)

# # Dependence plots to see how a feature's SHAP value changes over the range of features
# for feat in shap_features:
#     shap.dependence_plot(feat, test_shap_vals[1], X_test_df,
#                          dot_size=100)

# # Heat Map
# test_shap_df = pd.DataFrame(np.column_stack((test_shap_vals, y_test_and_pred_df)),
#                             columns= features + ['bias', 'true_AV_pctile',
#                                                  'pred_AV_pctile'])
# test_shap_df.sort_values('pred_AV_pctile', inplace=True)

# title = 'SHAP Values for each prediction in the testing data'
# fig = double_heatmap(test_shap_df[['true_AV_pctile', 'pred_AV_pctile']].T,
#                      test_shap_df[features].T, '%ile', 'SHAP Value',
#                      title=title, subplot_top=0.89)
# fig.axes[1].set_xlabel('Player');

