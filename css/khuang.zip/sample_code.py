# Databricks notebook source
# MAGIC %md #Setup Environment

# COMMAND ----------

# MAGIC %md Documentation: https://spark.apache.org/docs/latest/sql-pyspark-pandas-with-arrow.html#apache-arrow-in-spark

# COMMAND ----------

# Import
from pyspark.sql.types import * # IntegerType
from pyspark.sql.functions import udf, col, from_utc_timestamp, when
from pyspark.sql import functions as f
from pyspark.sql.window import Window

from pyspark.ml import Pipeline
from pyspark.ml.feature import OneHotEncoderEstimator, StringIndexer, VectorAssembler
from pyspark.ml.stat import Correlation
from pyspark.ml.linalg import Vectors
from pyspark.ml.classification import RandomForestClassifier
# from pyspark.ml.classification import LogisticRegression
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.tuning import ParamGridBuilder, CrossValidator
from pyspark.ml.evaluation import MulticlassClassificationEvaluator # Evaluation df
from pyspark.mllib.evaluation import MulticlassMetrics # Confusion Matrix rdd
from pyspark.mllib.evaluation import MultilabelMetrics

import time
from numpy.random import randint
import pandas as pd

import os
import logging
import shutil

import azureml.core
from azureml.core import Workspace
from azureml.core.run import Run
from azureml.core.experiment import Experiment
from azureml.core.authentication import ServicePrincipalAuthentication

print("SDK version:", azureml.core.VERSION)

# COMMAND ----------

# Read in mapd dataset
spark_mapd = spark.read.parquet(adlsRootPath + "/mapd_RxEmbr_conv").cache()
spark_mapd.printSchema() # shows the schema in tree format

# COMMAND ----------

# Random Spark Commands
# spark_mapd.select('tenure_mbr_cov').show() # shows one column
# spark_mapd.select(spark_mapd['id'], spark_mapd['tenure_mbr_cov'] + 1).show() # Grabs id and increments tenure by +1
# spark_mapd.filter(spark_mapd['tenure_mbr_cov'] > 50).show() # filters
spark_mapd.groupBy('rx_enroll').count().show() # Groups by rx_enroll and counts

# COMMAND ----------

# Spark SQL Queries
spark_mapd.createOrReplaceTempView('convert') # temp view
# spark_mapd.createGlobalTempView('convert') # global temp view

sqlDF = spark.sql('SELECT * FROM convert')
sqlDF.show()

# COMMAND ----------

# Spark display df
display(spark_mapd)

# COMMAND ----------

# MAGIC %md **Feature Generation**

# COMMAND ----------

# MAGIC %md Currently using python to do the feature engineering. Need to figure out how to do this in Spark. The below code is a spark parquet file converted to Python df where all the preprocessing is done. When that is finished, converts the file to a spark df
# MAGIC 
# MAGIC See Base Feature Generation - v1.1

# COMMAND ----------

# MAGIC %md **PySpark**

# COMMAND ----------



# COMMAND ----------

# MAGIC %md **Spark ==> Python ==> Spark Example**

# COMMAND ----------

############################
## Spark - Python - Spark ##
############################
# Convert Spark df to Pandas df to use Python EDA
df_mapd = spark_mapd.toPandas()
###################################################################################
# Filter out to only MAPD
df_mapd = df_mapd[df_mapd.ind_pdp == 0]

features = ['id', 'mabh_seg', 'ntwperyr', 'chva', 'tenure_mbr_cov', 'hum_age',
            'rx_allowed_amt_6m', 'rx_cnt_maint_drug_6m', 'rx_cnt_rx_6m',
            'rx_cnt_rhtsrce_6m', 'rx_cnt_tier1_6m', 'rx_cnt_tier2_6m',
            'rx_mbr_resp_amt_6m', 'rx_paid_amt_6m', 'ts_last_login', 'ts_last_call',
            'ind_pdp', 'hwrxloyl', 'rxnum', 'rx_enroll']
###################################################################################
# Numerical Features
numerical_features = ['id', 'ntwperyr', 'chva', 'tenure_mbr_cov', 'hum_age', 'rx_allowed_amt_6m',
                      'rx_cnt_maint_drug_6m', 'rx_cnt_rx_6m', 'rx_cnt_rhtsrce_6m',
                      'rx_cnt_tier1_6m', 'rx_cnt_tier2_6m', 'rx_mbr_resp_amt_6m',
                      'rx_paid_amt_6m', 'ts_last_login', 'ts_last_call',
                      'ind_pdp', 'hwrxloyl', 'rxnum','rx_enroll']

mapd_numerical = df_mapd[numerical_features].copy()
###################################################################################
# Categorical Features
categorical_features = ['id', 'mabh_seg']

mapd_categorical = df_mapd[categorical_features].copy()
###################################################################################
# Create dummy variables for categorical var.
# MAPD beh seg
mapd_bseg_cat = pd.get_dummies(mapd_categorical[['mabh_seg']])
mapd_bseg_cat['id'] = mapd_categorical.loc[:,'id']
###################################################################################
# Merge back to original dataset
df_mapd = pd.merge(mapd_numerical,mapd_bseg_cat,how='left',on='id')
###################################################################################
# Rearrange columns for easier model building
df_mapd = df_mapd[[col for col in df_mapd if col not in ['rx_enroll']] 
       + ['rx_enroll']]

df_mapd.columns = df_mapd.columns.str.lower()

###################################################################################
# Impute
df_mapd['tenure_mbr_cov'].fillna(df_mapd.tenure_mbr_cov.mean(),inplace = True) # New Member
df_mapd['hum_age'].fillna(df_mapd.hum_age.mean(),inplace = True) # New Member

# Imputate AMLK values
df_mapd['ntwperyr'].fillna(df_mapd.ntwperyr.mean(),inplace = True) # Net Worth Per Year
df_mapd['chva'].fillna(df_mapd.chva.mean(),inplace = True) # Census Median Home Value AMLK
df_mapd['hwrxloyl'].fillna(df_mapd.hwrxloyl.mean(),inplace = True) # Rx Pharmacy Loyalty
df_mapd['rxnum'].fillna(df_mapd.rxnum.mean(),inplace = True) # RX - Share of Wallet (0 loyal)

# Clean variables
df_mapd.loc[df_mapd.ntwperyr < 0, 'ntwperyr'] = 0
df_mapd.loc[df_mapd.ts_last_login < 0, 'ts_last_login'] = 0
df_mapd.loc[df_mapd.ts_last_call < 0, 'ts_last_call'] = 0

###################################################################################
# Feature Engineering
# Number of Available scripts to Convert
df_mapd['rx_cntrx_hprx'] = df_mapd.rx_cnt_rx_6m - df_mapd.rx_cnt_rhtsrce_6m
########################################################################################
# Engaged Members
engaged_col = ['MABH_SEG_Support-Seeking Participators'
               ,'MABH_SEG_Health Services Maximizers'
               ,'MABH_SEG_Self-Engaged Optimists'
               ,'MABH_SEG_Auto-pilot Participators']

# Lowercase column names - List comprehensions
engaged_col = [element.lower() for element in engaged_col]
engaged_col

# Create Engaged Members Column
df_mapd['engaged_members'] = df_mapd[engaged_col].any(axis=1)
df_mapd['engaged_members'] = df_mapd.loc[:,'engaged_members'].replace([True,'True'], 1)
df_mapd['engaged_members'] = df_mapd.loc[:,'engaged_members'].replace([False,'False'], 0)
############################################################################################
# Unengaged Members
unengaged_col = ['MABH_SEG_Healthy Self-Sustainers',
               'MABH_SEG_Overwhelmed and Reluctant Reactors',
               'MABH_SEG_Simplicity-Seeking Followers',
               'MABH_SEG_Skeptical Control-Seekers']

# Lowercase column names - List comprehensions
unengaged_col = [element.lower() for element in unengaged_col]
unengaged_col

# Create Unengaged Members Column
df_mapd['unengaged_members'] = df_mapd[unengaged_col].any(axis=1)
df_mapd['unengaged_members'] = df_mapd.loc[:,'unengaged_members'].replace([True], 1)
df_mapd['unengaged_members'] = df_mapd.loc[:,'unengaged_members'].replace([False], 0)
############################################################################################
# No Behavioral Segments
noseg_col =  ['MABH_SEG_NO RECORD']

# Lowercase column names - List comprehensions
noseg_col = [element.lower() for element in noseg_col]
noseg_col

# Create no behvioral segment members columns
df_mapd['no_behseg_members'] = df_mapd[noseg_col].all(axis=1)
df_mapd['no_behseg_members'] = df_mapd.loc[:,'no_behseg_members'].replace([True], 1)
df_mapd['no_behseg_members'] = df_mapd.loc[:,'no_behseg_members'].replace([False], 0)
############################################################################################
# Rearrange columns for easier model building
df_mapd = df_mapd[[col for col in df_mapd if col not in ['rx_enroll']] 
       + ['rx_enroll']]
df_mapd.columns
############################################################################################
df = df_mapd.copy()
final_features = ['ID',
                  'NTWPERYR', 'CHVA',
                  'RXNUM','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE', 
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAINT_DRUG_6M','RX_CNT_RX_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'RX_CNTRX_HPRX',
                  'ENGAGED_MEMBERS',
                  'UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
                  'RX_ENROLL'
                 ]

# Lowercase column names - List comprehensions
final_features = [element.lower() for element in final_features]

df = df[final_features]

# COMMAND ----------

# Only Necessary if you get an error in the code below
# mySchema = StructType([StructField("Col1", LongType(), True),
#                        StructField("Col2", IntegerType(), True),
#                        StructField("Col2", StringType(), True),
# ])

spark_mapd = spark.createDataFrame(df)

# COMMAND ----------

display(spark_mapd)

# COMMAND ----------

# MAGIC %md **Model Generation w/o Pipeline**

# COMMAND ----------

# Filter to columns used for modeling
final_features = ['ID',
                  'NTWPERYR', 'CHVA',
                  'RXNUM','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE', 
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAINT_DRUG_6M','RX_CNT_RX_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'RX_CNTRX_HPRX',
                  'ENGAGED_MEMBERS',
                  'UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
                  'RX_ENROLL'
                 ]

# Lowercase column names - List comprehensions
final_features = [element.lower() for element in final_features]

#Filters your initial dataframe down to important columns
spark_mapd = spark_mapd.select(final_features).cache()

# COMMAND ----------

# Convert True/False to 1/0
# cat_col_recode = spark_mapd.select([col(c).cast("integer") for c in ["engaged_members", "unengaged_members", "no_behseg_members"]])
spark_mapd = spark_mapd.withColumn('engaged_members', f.when(spark_mapd.engaged_members == 'true',1).otherwise(0)).withColumn('unengaged_members', f.when(spark_mapd.unengaged_members == 'true', 1).otherwise(0)).withColumn('no_behseg_members', f.when(spark_mapd.no_behseg_members == 'true', 1).otherwise(0))

# COMMAND ----------

display(spark_mapd)

# COMMAND ----------

spark_mapd = spark_mapd.withColumn('engaged_members', f.when(spark_mapd.engaged_members == 'true',1).otherwise(0))

# COMMAND ----------

# % of Non-null values
nullNumDF = spark_mapd.select(final_features).agg(*[f.count(c).alias(c) for c in final_features]).collect()

# Count of Members
maxMbrCt = float(spark_mapd.count())

# Empty List of Columns with Nulls
listOfColsWNullsNum = []

for x in final_features:
    pctCov = nullNumDF[0][x]/maxMbrCt
    if pctCov < 1:
        listOfColsWNullsNum.append((x,pctCov))

#Displays the list of columns with at least 1 null values and the percentage of NON-NULL values (e.g. 0.99 = 99% not null)
print ("Columns With Nulls:")
for x in listOfColsWNullsNum:
    print (x)

# COMMAND ----------

# Subset to features used for model 
seed = 1990
###########################################################
# Spliting in train and test set. Beware : It sorts the dataset
(traindf_, testdf) = spark_mapd.randomSplit([0.8,0.2],seed)
(traindf, valdf) = traindf_.randomSplit([0.8,0.2],seed)

# Class Distribution for the training and test set
print('TRAIN')
print('Total # Records',traindf.count())
print(traindf.groupBy("rx_enroll").count().take(2))
# print(traindf.select(f.sum(f.when(f.col('rx_enroll') == 1, 1)).alias('rx_enroll == 1')).show(truncate=False))

print('\n','VAL')
print('Total # Records',valdf.count())
print(valdf.groupBy("rx_enroll").count().take(2))

print('\n','TEST')
print('Total # Records',testdf.count())
print(testdf.groupBy("rx_enroll").count().take(2))
###########################################################
# Downsample dataset
# Before Resampling
print('\n','Resampled Training Set: ')
# traindf_zero = traindf.filter("rx_enroll=0.0")
print('Number of class 0 samples before:',traindf.filter("rx_enroll=0.0").count())

# Downsample dataset
traindf_zero = traindf.filter("rx_enroll=0.0")
traindf_one = traindf.filter("rx_enroll=1.0")

traindf_sampleRatio = traindf_one.count() / traindf.count()
traindf_zero_downsample = traindf_zero.sample(withReplacement=False,fraction=traindf_sampleRatio+.001,seed=seed) #fraction = % you want to draw from that sample
traindf_sampled = traindf_one.unionAll(traindf_zero_downsample)

# After Resampling
print('Number of class 0 samples after:',traindf_zero_downsample.count())
print('Number of class 1 samples after:',traindf_one.count())
print(traindf_sampled.groupBy("rx_enroll").count().take(2))

###########################################################
# Remove PGK from model
train = traindf_sampled
val = valdf
test = testdf
traindf = traindf_sampled.drop("id")
valdf = valdf.drop("id")
testdf = testdf.drop("id")
print(train.groupBy("rx_enroll").count().take(2))
print(val.groupBy("rx_enroll").count().take(2))
print(test.groupBy("rx_enroll").count().take(2))
###########################################################
# Features
model_features = ['NTWPERYR', 'CHVA',
                  'RXNUM','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE', 
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAINT_DRUG_6M','RX_CNT_RX_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'RX_CNTRX_HPRX',
                  'ENGAGED_MEMBERS',
                  'UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
                 ]

# Lowercase column names - List comprehensions
model_features = [element.lower() for element in model_features]
###########################################################
# Fit Random Forest Classifier to Training Data
# Index labels, adding metadata to the label column.
# Fit on whole dataset to include all labels in index.
traindf = StringIndexer(inputCol="rx_enroll", outputCol="indexed_rx_enroll").fit(traindf).transform(traindf)

# Feature assembler as a vector
traindf = VectorAssembler(inputCols=model_features,outputCol="features").transform(traindf)

# Model
rf = RandomForestClassifier(labelCol="indexed_rx_enroll", featuresCol="features", numTrees=500, maxDepth=5,featureSubsetStrategy="sqrt",impurity="entropy")

classifier = rf.fit(traindf)
###########################################################
# Predict on the Test Data rf
# Feature assembler as a vector
valdf = VectorAssembler(inputCols=model_features,outputCol="features").transform(testdf)

# Prediction
predictions = classifier.transform(valdf)
 
# Select example rows to display.
# Probability shows of class 0
# predictions.select(col("prediction"),col("probability"),).show(15)
display(predictions)

# COMMAND ----------

# Evaluate Model
# Accuracy
evaluator = MulticlassClassificationEvaluator(labelCol="rx_enroll", predictionCol="prediction", metricName="accuracy")
accuracy = evaluator.evaluate(predictions)
print("Accuracy = %g" % (accuracy))

evaluatorf1 = MulticlassClassificationEvaluator(labelCol="rx_enroll", predictionCol="prediction", metricName="f1")
f1 = evaluatorf1.evaluate(predictions)
print("f1 = %g" % (f1))

evaluatorwp = MulticlassClassificationEvaluator(labelCol="rx_enroll", predictionCol="prediction", metricName="weightedPrecision")
wp = evaluatorwp.evaluate(predictions)
print("weightedPrecision = %g" % (wp))

evaluatorwr = MulticlassClassificationEvaluator(labelCol="rx_enroll", predictionCol="prediction", metricName="weightedRecall")
wr = evaluatorwr.evaluate(predictions)
print("weightedRecall = %g" % (wr))

# # Confusion Matrix
# # Create (prediction, label) pairs
# predictionAndLabel = predictions.select("prediction", "rx_enroll").rdd

# # Generate confusion matrix
# metrics = MulticlassMetrics(predictionAndLabel)
# print(metrics.confusionMatrix())

# COMMAND ----------

# Import packages
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import brier_score_loss
from sklearn.metrics import f1_score
from sklearn.metrics import roc_auc_score, roc_curve, auc

# Convert Spark df to Pandas df to get confusion matrix since I cant figure it out in spark
df_mapd = predictions.toPandas()

# Convert for easy use of old code
y_val = df_mapd.rx_enroll
y_pred = df_mapd.prediction

# Missclassified
print('Number of Misclassified: ',(y_val != y_pred).sum())

###########################################################
# Confusion Matrix
cm = confusion_matrix(y_val, y_pred)
print('[[True Negative, False Positive]')
print('[False Negative, True Positive]]')
print(cm)
###########################################################
# Recall (True Positive / Positive Cases (TP & FN)): True Positive Rate
# print('TRUE POSITIVE RATE (Recall or Sensitivity) =','TP / (TP+FN)')
# print('Accuracy: %.3f' % accuracy_score(y_true=y_test, y_pred=y_pred))
print('Recall: %.3f' % recall_score(y_true=y_val, y_pred=y_pred))
print('Precision: %.3f' % precision_score(y_true=y_val, y_pred=y_pred))

# COMMAND ----------

# MAGIC %md **Model Generation by Pipeline**

# COMMAND ----------

# from pyspark.ml.stat import Correlation
# from pyspark.ml.feature import VectorAssembler
# from pyspark.ml.linalg import Vectors
# from pyspark.ml.classification import RandomForestClassifier


# COMMAND ----------

#######################################
## Explore Corr - CAN SKIP THIS CELL ##
#######################################
# Select df - Drop ID since its a string and wont work
mapd_explore = spark_mapd.drop("id")

# Correlation Matrix - Need to first convert columns into a vector
vector_col = "corr_features"
assembler = VectorAssembler(inputCols=mapd_explore.columns,outputCol=vector_col)
mapd_explore_vector = assembler.transform(mapd_explore).select(vector_col)

# Get Correlation Matrix
matrix = Correlation.corr(mapd_explore_vector,vector_col)
matrix.collect()[0]["pearson({})".format(vector_col)].values
# r1 = Correlation.corr(mapd_explore_vector,vector_col).head()
# print("Pearson correlation matrix:\n" + str(r1[0]))

# COMMAND ----------

# Prepare dataset with different columns
ignoreCols = []
categoricalCols = [] # ['engaged_members','unengaged_members','no_behseg_members']
primaryIDCol = ['id']
targetCol = ['rx_enroll']

# Create a list of Numeric Columns
nonNumCols = ignoreCols + categoricalCols + targetCol + primaryIDCol
numCols = [c for c in spark_mapd.columns if c not in nonNumCols]

# Count of Members
maxMbrCt = float(spark_mapd.count())



# COMMAND ----------

# % of Non-null values
nullNumDF = spark_mapd.select(numCols).agg(*[f.count(c).alias(c) for c in numCols]).collect()

# Empty List of Columns with Nulls
listOfColsWNullsNum = []

for x in numCols:
    pctCov = nullNumDF[0][x]/maxMbrCt
    if pctCov < 1:
        listOfColsWNullsNum.append((x,pctCov))

#Displays the list of columns with at least 1 null values and the percentage of NON-NULL values (e.g. 0.99 = 99% not null)
print ("Numerical")
for x in listOfColsWNullsNum:
    print (x)

# COMMAND ----------

# Filter to columns used for modeling
final_features = ['ID',
                  'NTWPERYR', 'CHVA',
                  'RXNUM','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE', 
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAINT_DRUG_6M','RX_CNT_RX_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'RX_CNTRX_HPRX',
                  'ENGAGED_MEMBERS',
                  'UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
                  'RX_ENROLL'
                 ]

# Lowercase column names - List comprehensions
final_features = [element.lower() for element in final_features]

#Filters your initial dataframe down to important columns
spark_mapd = spark_mapd.select(final_features).cache()

# COMMAND ----------

spark_mapd.printSchema() # shows the schema in tree format

# COMMAND ----------

# Filter to Columns (Aklready converted categorical to numerical so you can skip the One-Hot-Encoding)
ignoreColsSel = [c for c in ignoreCols if c in spark_mapd.columns]
categoricalColsSel = [c for c in categoricalCols if c in spark_mapd.columns]
numColsSel = [c for c in numCols if c in spark_mapd.columns]

# COMMAND ----------

# Convert True/False to 1/0
# cat_col_recode = spark_mapd.select([col(c).cast("integer") for c in ["engaged_members", "unengaged_members", "no_behseg_members"]])
spark_mapd = spark_mapd.withColumn('engaged_members', f.when(spark_mapd.engaged_members == 'true',1).otherwise(0)).withColumn('unengaged_members', f.when(spark_mapd.unengaged_members == 'true', 1).otherwise(0)).withColumn('no_behseg_members', f.when(spark_mapd.no_behseg_members == 'true', 1).otherwise(0))

# COMMAND ----------

##############################################################################
## OHE a CAT_VARIABLE - CAN SKIP THIS CELL SINCE ALREADY CONVERTED ABOVE ##
##############################################################################
# One-Hot Encoding to convert all categorical variables into binary vectors.
stages = [] # stages in our Pipeline
for item in categoricalColsSel:
    # Category Indexing with StringIndexer
    stringIndexer = StringIndexer(inputCol=item, outputCol=item + "Index")
    # Use OneHotEncoder to convert categorical variables into binary SparseVectors
    encoder = OneHotEncoderEstimator(inputCols=[stringIndexer.getOutputCol()], outputCols=[item + "classVec"])
    # Add stages.  These are not run here, but will run all at once later on.
    stages += [stringIndexer, encoder]

label_stringIdx = StringIndexer(inputCol="rx_enroll", outputCol="indexedLabel")
stages += [label_stringIdx]


# COMMAND ----------

# MAGIC %md
# MAGIC NOTE: You would run this if you have a categorical variable, but since I converted True to 1 and False to 0 in the above cell, you can skip this cell. Also note that above in the code I have those columns listed under categorical, but you should probably remove that so it doesn't interfere with any code.

# COMMAND ----------

# Transform all features into a vector using VectorAssembler
assemblerInputs = [c + "classVec" for c in categoricalColsSel] + numColsSel
assembler = VectorAssembler(inputCols=assemblerInputs, outputCol="features")
stages += [assembler]

# COMMAND ----------

partialPipeline = Pipeline().setStages(stages)
pipelineModel = partialPipeline.fit(spark_mapd)   #Should change to name of your input dataframe
preppedDataDF = pipelineModel.transform(spark_mapd)  #Should change to name of your input dataframe

# COMMAND ----------

# MAGIC %md **Scoring Generation**

# COMMAND ----------


