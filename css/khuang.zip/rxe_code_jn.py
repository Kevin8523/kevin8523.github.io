# Data Pre-Process

# spark

# Import Libraries
import hdputils
hdputils.grant_smart_access()

# System Environment
import sys; print(sys.executable); print(sys.version)

# Libraries
import pandas as pd ; print("Pandas Version:",pd.__version__)
import numpy as np ; print("NumPy Version:",np.__version__)
import matplotlib.pyplot as plt
import seaborn as sns

# spark
# # Import Libraries
# import hdputils
# hdputils.grant_smart_access()

# # System Environment
# import sys; print(sys.executable); print(sys.version)

# # Libraries
# import pandas as pd ; print("Pandas Version:",pd.__version__)
# import numpy as np ; print("NumPy Version:",np.__version__)
# import matplotlib.pyplot as plt
# import seaborn as sns

# ask = lambda q: hdputils.doquery(spark, q).toPandas()
# outcome = "consumer_work.mapd_dt_kevin"

# mapd_table = f"""
#     SELECT
#         a.MBR_PERS_GEN_KEY,
#         a.NTWPERYR, a.CHVA,
#         a.RXNUM,a.RXBRAND,a.RXSOWRX,a.HWRXLOYL,
#         a.TENURE, a.AGE,
#         a.RX_ALLOWED_AMT_6M,
#         a.RX_CNT_MAINT_DRUG_6M,a.RX_CNT_RHTSRCE_6M,a.RX_CNT_RX_6M,
#         a.RX_CNT_TIER1_6M, a.RX_CNT_TIER2_6M,
#         a.RX_MBR_RESP_AMT_6M, a.RX_PAID_AMT_6M,
#         a.TS_LAST_LOGIN, a.TS_LAST_CALL,
#         a.IND_SEG_ENGAGED
#     FROM
#         {outcome} a
# """
# mapd_df = ask(mapd_table)
# mapd_df.to_csv('mapd_df.csv',index=False)


# outcome = "consumer_work.pdp_dt_kevin"

# pdp_table = f"""
#     SELECT
#         a.MBR_PERS_GEN_KEY,
#         a.NTWPERYR, a.CHVA,
#         a.RXNUM,a.RXBRAND,a.RXSOWRX,a.HWRXLOYL,
#         a.TENURE, a.AGE,
#         a.RX_ALLOWED_AMT_6M,
#         a.RX_CNT_MAINT_DRUG_6M,a.RX_CNT_RHTSRCE_6M,a.RX_CNT_RX_6M,
#         a.RX_CNT_TIER1_6M, a.RX_CNT_TIER2_6M,
#         a.RX_MBR_RESP_AMT_6M, a.RX_PAID_AMT_6M,
#         a.TS_LAST_LOGIN, a.TS_LAST_CALL,
#         a.IND_SEG_ENGAGED
#     FROM
#         {outcome} a
# """
# pdp_df = ask(pdp_table)

# pdp_df.to_csv('pdp_df.csv',index=False)

ask = lambda q: hdputils.doquery(spark, q).toPandas()

outcome = "consumer_work.mapd_dt_kevin"

mapd_table = f"""
    SELECT
        a.MBR_PERS_GEN_KEY,
        a.NTWPERYR, a.CHVA,
        a.RXNUM,a.RXBRAND,a.RXSOWRX,a.HWRXLOYL,
        a.TENURE, a.AGE,
        a.RX_ALLOWED_AMT_6M,
        a.RX_CNT_MAINT_DRUG_6M,a.RX_CNT_RHTSRCE_6M,a.RX_CNT_RX_6M,
        a.RX_CNT_TIER1_6M, a.RX_CNT_TIER2_6M,
        a.RX_MBR_RESP_AMT_6M, a.RX_PAID_AMT_6M,
        a.TS_LAST_LOGIN, a.TS_LAST_CALL,
        a.IND_SEG_ENGAGED
    FROM
        {outcome} a
"""
mapd_df = ask(mapd_table)

mapd_df.to_csv('mapd_df.csv',index=False)

outcome = "consumer_work.pdp_dt_kevin"

pdp_table = f"""
    SELECT
        a.MBR_PERS_GEN_KEY,
        a.NTWPERYR, a.CHVA,
        a.RXNUM,a.RXBRAND,a.RXSOWRX,a.HWRXLOYL,
        a.TENURE, a.AGE,
        a.RX_ALLOWED_AMT_6M,
        a.RX_CNT_MAINT_DRUG_6M,a.RX_CNT_RHTSRCE_6M,a.RX_CNT_RX_6M,
        a.RX_CNT_TIER1_6M, a.RX_CNT_TIER2_6M,
        a.RX_MBR_RESP_AMT_6M, a.RX_PAID_AMT_6M,
        a.TS_LAST_LOGIN, a.TS_LAST_CALL,
        a.IND_SEG_ENGAGED
    FROM
        {outcome} a
"""
pdp_df = ask(pdp_table)

pdp_df.to_csv('pdp_df.csv',index=False)

# Import dataset to be scored
path = ''
filename = 'mapd_df.csv'
filepath = f'{path}{filename}'
mapd_df = pd.read_csv(filepath, header=0)
mapd_df['IND_MAP'] = 1
mapd_df['IND_PDP'] = 0

# Import dataset to be scored
path = ''
filename = 'pdp_df.csv'
filepath = f'{path}{filename}'
pdp_df = pd.read_csv(filepath, header=0)
pdp_df['IND_MAP'] = 0
pdp_df['IND_PDP'] = 1

pdp_df.head()

# System Environment
import sys; print(sys.executable); print(sys.version)

# Libraries
import pandas as pd ; print("Pandas Version:",pd.__version__)
import numpy as np ; print("NumPy Version:",np.__version__)
import pyreadstat
import pickle
from datetime import date

# Import dataset to be scored
path = ''
filename = 'scoring_data.csv'
filepath = f'{path}{filename}'
prod_data1 = pd.read_csv(filepath, header=0)

# Change all Columns to uppercase
prod_data1.columns = prod_data1.columns.str.upper()

# System Environment
import sys; print(sys.executable); print(sys.version)

# Libraries
import pandas as pd ; print("Pandas Version:",pd.__version__)
import numpy as np ; print("NumPy Version:",np.__version__)
import pyreadstat
import pickle
from datetime import date


# Import dataset to be scored
path = ''
filename = 'scoring_data.csv'
filepath = f'{path}{filename}'
prod_data1 = pd.read_csv(filepath, header=0)

# Change all Columns to uppercase
prod_data1.columns = prod_data1.columns.str.upper()
##################################################################################
# Quick & Dirty Collapse data for duplications
prod_data1 = prod_data1.sort_values(by=['IND_MAPD','IND_PDP'],ascending=False)
prod_data1 = prod_data1.groupby('MBR_PERS_GEN_KEY', as_index=False).first()
prod_data1.MBR_PERS_GEN_KEY.value_counts()
###################################################################################
# Features from SAS Dataset
prod_features = ['MBR_PERS_GEN_KEY','IND_MAPD','IND_PDP',
                  'NTWPERYR', 'CHVA',
                  'RXNUM','RXBRAND','RXSOWRX','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE',
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAIL_ORDER_6M',
                  'RX_CNT_MAINT_DRUG_6M','RX_CNT_RHTSRCE_6M','RX_CNT_RX_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'MABH_SEG','PDPBH_SEG'
                 ]
df = prod_data1[prod_features]
##################################################################################
# Clean Where MAPD & PDP == 1
df['IND_PDP'] = df.IND_PDP.mask(((df.IND_MAPD == 1) & (df.IND_PDP == 1)), 0)


# Numerical Features
number_features = ['MBR_PERS_GEN_KEY'
                         ,'IND_MAPD'
                         ,'IND_PDP'
                         ,'NTWPERYR'
                         ,'CHVA'
                         ,'RXNUM'
                         ,'RXBRAND'
                         ,'RXSOWRX'
                         ,'HWRXLOYL'
                         ,'TENURE_MBR_COV'
                         ,'HUM_AGE'
                         ,'RX_ALLOWED_AMT_6M'
                         ,'RX_CNT_MAIL_ORDER_6M'
                         ,'RX_CNT_MAINT_DRUG_6M'
                         ,'RX_CNT_RHTSRCE_6M'
                         ,'RX_CNT_RX_6M'
                         ,'RX_CNT_TIER1_6M'
                         ,'RX_CNT_TIER2_6M'
                         ,'RX_MBR_RESP_AMT_6M'
                         ,'RX_PAID_AMT_6M'
                         ,'TS_LAST_LOGIN'
                         ,'TS_LAST_CALL'
                  ]

num_var = df[number_features].copy()
####################################################################################
# Categorical Features for dataset
# Split the df to numbers & categorical for quick exploration of features
# member_data.select_dtypes(include=[object]).head() # df.loc[:, df.dtypes == np.float64]

category_features = ['MBR_PERS_GEN_KEY'
                        ,'MABH_SEG'
                        ,'PDPBH_SEG'
                    ]
cat_var = df[category_features].copy()
####################################################################################
#############################
# Clean Categorical Variables
#############################
# Create the Dummy Variables: If doing logistic, be sure to n-1 for dummy variables
# MAPD & PDP BEHAVIORAL SEGMENTATION
# Replaces None/Nan with Other and Nulls
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['C1'], 'Support-Seeking Participators')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['C3','H3'], 'Health Services Maximizers')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H1','C2'], 'Self-Engaged Optimists')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H6','H7','C6'], 'Skeptical Control-Seekers')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H2','C4'], 'Auto-pilot Participators')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H5','C5'], 'Simplicity-Seeking Followers')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H8','C7'], 'Overwhelmed and Reluctant Reactors')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H4'], 'Healthy Self-Sustainers')

cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P1'], 'Proactive Maximizer')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P2'], 'Reactive Engager')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P3'], 'Frugal Participator')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P4'], 'Complacent Follower')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P5'], 'Healthy Independent')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P6'], 'Overwhelmed & Detached')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P7'], 'Agreeably Disengaged')

cat_var['MABH_SEG'] = cat_var.MABH_SEG.fillna('NO RECORD')
cat_var['PDPBH_SEG'] = cat_var.PDPBH_SEG.fillna('NO RECORD')

# MAPD beh seg
mapd_bseg_cat = pd.get_dummies(cat_var[['MABH_SEG']])
mapd_bseg_cat['MBR_PERS_GEN_KEY'] = cat_var.loc[:,'MBR_PERS_GEN_KEY']

# PDP beh seg
pdp_bseg_cat = pd.get_dummies(cat_var[['PDPBH_SEG']])
pdp_bseg_cat['MBR_PERS_GEN_KEY'] = cat_var.loc[:,'MBR_PERS_GEN_KEY']

# Combine Categorical Features
cat_var_sel = ['MBR_PERS_GEN_KEY'
              ,'MABH_SEG'
              ,'PDPBH_SEG']
cat_var_subset = cat_var[cat_var_sel]
cat_var_subset = pd.merge(cat_var_subset,mapd_bseg_cat,how='left',on='MBR_PERS_GEN_KEY')
cat_var_subset = pd.merge(cat_var_subset,pdp_bseg_cat,how='left',on='MBR_PERS_GEN_KEY')
cat_var_subset.head()
################################################################################################
# Select final columns
cat_var_fin = [
    'MBR_PERS_GEN_KEY'
    ,'MABH_SEG_Auto-pilot Participators','MABH_SEG_Health Services Maximizers','MABH_SEG_Healthy Self-Sustainers','MABH_SEG_NO RECORD','MABH_SEG_Overwhelmed and Reluctant Reactors','MABH_SEG_Self-Engaged Optimists','MABH_SEG_Simplicity-Seeking Followers','MABH_SEG_Skeptical Control-Seekers','MABH_SEG_Support-Seeking Participators'
    ,'PDPBH_SEG_Agreeably Disengaged','PDPBH_SEG_Complacent Follower','PDPBH_SEG_Frugal Participator', 'PDPBH_SEG_Healthy Independent','PDPBH_SEG_NO RECORD','PDPBH_SEG_Overwhelmed & Detached','PDPBH_SEG_Proactive Maximizer', 'PDPBH_SEG_Reactive Engager'
]

cat_var = cat_var_subset[cat_var_fin]
####################################################################################
# Join Categorical & Numerical Variables
df = pd.merge(num_var,cat_var,how='left',on='MBR_PERS_GEN_KEY')
####################################################################################
mapd_train = df[df.IND_MAPD == 1].copy()
pdp_train = df[df.IND_PDP == 1].copy()
print(mapd_train.MBR_PERS_GEN_KEY.count())
print(pdp_train.MBR_PERS_GEN_KEY.count())


# Imputate CAT values
mapd_train['TENURE_MBR_COV'].fillna(mapd_train.TENURE_MBR_COV.mean(),inplace = True) # New Member
mapd_train['HUM_AGE'].fillna(mapd_train.HUM_AGE.mean(),inplace = True) # New Member

# Imputate AMLK values
mapd_train['NTWPERYR'].fillna(mapd_train.NTWPERYR.mean(),inplace = True) # Net Worth Per Year
mapd_train['CHVA'].fillna(mapd_train.CHVA.mean(),inplace = True) # Census Median Home Value AMLK
mapd_train['RXNUM'].fillna(mapd_train.RXNUM.mean(),inplace = True) # # of Meds (modeled)
mapd_train['HWRXLOYL'].fillna(mapd_train.HWRXLOYL.mean(),inplace = True) # Rx Pharmacy Loyalty

print('Number of Nulls: ',mapd_train.size - mapd_train.count().sum())
# Fill remaining with 0s
mapd_train = mapd_train.fillna(0)
print('Number of Nulls: ',mapd_train.size - mapd_train.count().sum())
#############################################################################################
# Number of Available scripts to Convert
mapd_train['RX_CNTRX_HPRX'] = mapd_train.RX_CNT_RX_6M - mapd_train.RX_CNT_RHTSRCE_6M
#############################################################################################
# Engaged Members
engaged_col = ['MABH_SEG_Support-Seeking Participators'
               ,'MABH_SEG_Health Services Maximizers'
               ,'MABH_SEG_Self-Engaged Optimists'
               ,'MABH_SEG_Auto-pilot Participators'
#                ,'PDPBH_SEG_Frugal Participator'
#                ,'PDPBH_SEG_Proactive Maximizer'
#                ,'PDPBH_SEG_Reactive Engager'
              ]
mapd_train['ENGAGED_MEMBERS'] = mapd_train[engaged_col].any(axis=1)
mapd_train['ENGAGED_MEMBERS'] = mapd_train.loc[:,'ENGAGED_MEMBERS'].replace([True], 1)
mapd_train['ENGAGED_MEMBERS'] = mapd_train.loc[:,'ENGAGED_MEMBERS'].replace([False], 0)

# Unengaged Members
unengaged_col = ['MABH_SEG_Healthy Self-Sustainers',
               'MABH_SEG_Overwhelmed and Reluctant Reactors',
               'MABH_SEG_Simplicity-Seeking Followers',
               'MABH_SEG_Skeptical Control-Seekers',
#                'PDPBH_SEG_Agreeably Disengaged',
#                'PDPBH_SEG_Complacent Follower',
#                'PDPBH_SEG_Healthy Independent',
#                'PDPBH_SEG_Overwhelmed & Detached'
                ]

mapd_train['UNENGAGED_MEMBERS'] = mapd_train[unengaged_col].any(axis=1)
mapd_train['UNENGAGED_MEMBERS'] = mapd_train.loc[:,'UNENGAGED_MEMBERS'].replace([True], 1)
mapd_train['UNENGAGED_MEMBERS'] = mapd_train.loc[:,'UNENGAGED_MEMBERS'].replace([False], 0)

# No Behavioral Segments
noseg_col = ['MABH_SEG_NO RECORD'
#              ,'PDPBH_SEG_NO RECORD'
            ]
mapd_train['NO_BEHSEG_MEMBERS'] = mapd_train[noseg_col].all(axis=1)
mapd_train['NO_BEHSEG_MEMBERS'] = mapd_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([True], 1)
mapd_train['NO_BEHSEG_MEMBERS'] = mapd_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([False], 0)
#####################################################################################################
mapd_train.loc[mapd_train.NTWPERYR < 0, 'NTWPERYR'] = 0
mapd_train.loc[mapd_train.TS_LAST_LOGIN < 0, 'TS_LAST_LOGIN'] = 0
mapd_train.loc[mapd_train.TS_LAST_CALL < 0, 'TS_LAST_CALL'] = 0



df = mapd_train.copy()
column_order = ['MBR_PERS_GEN_KEY',
                  'NTWPERYR', 'CHVA',
                  'RXNUM','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE',
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAINT_DRUG_6M','RX_CNT_RX_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'RX_CNTRX_HPRX',
                  'ENGAGED_MEMBERS','UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
                 ]
df = df[column_order]
##################################################################################
# Make PGK the index column
df.set_index('MBR_PERS_GEN_KEY', inplace=True)

# Create feature list
features_list = list(df.columns)
###################################################################################
# MAP RF
Decile_0 = 0.658
Decile_1 = 0.596
Decile_2 = 0.548
Decile_3 = 0.504
Decile_4 = 0.460
Decile_5 = 0.418
Decile_6 = 0.370
Decile_7 = 0.318
Decile_8 = 0.250
####################################################################################
# Import the model pickle
rxe_filename = 'rxe_rf_clf_mapd_random_sample.sav'
rxe_model = pickle.load(open(rxe_filename, 'rb'))

# Use the pickle model to score dataaset
y_probas = rxe_model.predict_proba(df) #df.values for XgBoost
y_score = pd.DataFrame(y_probas, columns=['prob_0', 'prob_1'])
y_score = y_score.drop(columns=['prob_0'],axis=1)
y_score.columns = ['rxe_resp_prob']

# Bring PGK back to the df & add scored probabilities
df.reset_index(inplace=True)
df_scored_mapd = pd.concat([df,y_score], axis=1)

# Add Deciles based on test data cutoffs
conditions = [
    (df_scored_mapd['rxe_resp_prob'] <= Decile_8),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_8) & (df_scored_mapd['rxe_resp_prob'] <= Decile_7)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_7) & (df_scored_mapd['rxe_resp_prob'] <= Decile_6)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_6) & (df_scored_mapd['rxe_resp_prob'] <= Decile_5)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_5) & (df_scored_mapd['rxe_resp_prob'] <= Decile_4)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_4) & (df_scored_mapd['rxe_resp_prob'] <= Decile_3)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_3) & (df_scored_mapd['rxe_resp_prob'] <= Decile_2)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_2) & (df_scored_mapd['rxe_resp_prob'] <= Decile_1)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_1) & (df_scored_mapd['rxe_resp_prob'] <= Decile_0)),
    (df_scored_mapd['rxe_resp_prob'] > Decile_0)]
deciles = [9,8,7,6,5,4,3,2,1,0]

# Add deciles to the scored rxe population
df_scored_mapd['rxe_resp_decile'] = np.select(conditions,deciles,default=np.nan)

# Add score date
SCORING_DATE = date.today()
df_scored_mapd['SCORE_DATE'] = SCORING_DATE.strftime('%Y%m%d')

# Rename Columns
df_scored_mapd.rename(columns={'rxe_resp_prob': 'MODEL_SCORE', 'rxe_resp_decile': 'DECILE'}, inplace=True)

# Change dtype of Decile
df_scored_mapd['DECILE'] = df_scored_mapd.DECILE.astype(int)

# Add MAPD indicator
df_scored_mapd['IND_MAPD'] = 1

# Subset to the list of columns for final scoring table
columns_final = ['MBR_PERS_GEN_KEY','IND_MAPD','MODEL_SCORE','DECILE','SCORE_DATE']
df_scored_mapd = df_scored_mapd[columns_final]

# Export to CSV
# May wish to choose path for CSV file by placing in front of file name
df_scored_mapd.to_csv('rxe_model_scored_mapd.csv', encoding='utf-8',index=False)



# Imputate CAT values
pdp_train['TENURE_MBR_COV'].fillna(pdp_train.TENURE_MBR_COV.mean(),inplace = True) # New Member
pdp_train['HUM_AGE'].fillna(pdp_train.HUM_AGE.mean(),inplace = True) # New Member

# Imputate AMLK values
pdp_train['NTWPERYR'].fillna(pdp_train.NTWPERYR.mean(),inplace = True) # Net Worth Per Year
pdp_train['CHVA'].fillna(pdp_train.CHVA.mean(),inplace = True) # Census Median Home Value AMLK
pdp_train['RXBRAND'].fillna(pdp_train.RXBRAND.mean(),inplace = True) # Prefer Brand Meds (0 more likely)
pdp_train['RXSOWRX'].fillna(pdp_train.RXSOWRX.mean(),inplace = True) # RX - Share of Wallet (0 loyal)
pdp_train['HWRXLOYL'].fillna(pdp_train.HWRXLOYL.mean(),inplace = True) # Rx Pharmacy Loyalty

print('Number of Nulls: ',pdp_train.size - pdp_train.count().sum())
# Fill remaining with 0s
pdp_train = pdp_train.fillna(0)
print('Number of Nulls: ',pdp_train.size - pdp_train.count().sum())
#############################################################################################
# Number of Available scripts to Convert
pdp_train['RX_CNTRX_HPRX'] = pdp_train.RX_CNT_RX_6M - pdp_train.RX_CNT_RHTSRCE_6M
#############################################################################################
# Engaged Members
engaged_col = ['PDPBH_SEG_Frugal Participator'
               ,'PDPBH_SEG_Proactive Maximizer'
               ,'PDPBH_SEG_Reactive Engager'
              ]
pdp_train['ENGAGED_MEMBERS'] = pdp_train[engaged_col].any(axis=1)
pdp_train['ENGAGED_MEMBERS'] = pdp_train.loc[:,'ENGAGED_MEMBERS'].replace([True], 1)
pdp_train['ENGAGED_MEMBERS'] = pdp_train.loc[:,'ENGAGED_MEMBERS'].replace([False], 0)

# Unengaged Members
unengaged_col = ['PDPBH_SEG_Agreeably Disengaged',
               'PDPBH_SEG_Complacent Follower',
               'PDPBH_SEG_Healthy Independent',
               'PDPBH_SEG_Overwhelmed & Detached'
                ]

pdp_train['UNENGAGED_MEMBERS'] = pdp_train[unengaged_col].any(axis=1)
pdp_train['UNENGAGED_MEMBERS'] = pdp_train.loc[:,'UNENGAGED_MEMBERS'].replace([True], 1)
pdp_train['UNENGAGED_MEMBERS'] = pdp_train.loc[:,'UNENGAGED_MEMBERS'].replace([False], 0)

# No Behavioral Segments
noseg_col = ['PDPBH_SEG_NO RECORD']
pdp_train['NO_BEHSEG_MEMBERS'] = pdp_train[noseg_col].all(axis=1)
pdp_train['NO_BEHSEG_MEMBERS'] = pdp_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([True], 1)
pdp_train['NO_BEHSEG_MEMBERS'] = pdp_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([False], 0)
#####################################################################################################
pdp_train.loc[pdp_train.NTWPERYR < 0, 'NTWPERYR'] = 0
pdp_train.loc[pdp_train.TS_LAST_LOGIN < 0, 'TS_LAST_LOGIN'] = 0
pdp_train.loc[pdp_train.TS_LAST_CALL < 0, 'TS_LAST_CALL'] = 0



df = pdp_train.copy()
column_order = ['MBR_PERS_GEN_KEY',
                  'NTWPERYR', 'CHVA',
                  'RXBRAND','RXSOWRX','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE',
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAIL_ORDER_6M', 'RX_CNT_MAINT_DRUG_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'RX_CNTRX_HPRX',
                  'ENGAGED_MEMBERS','UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
                 ]
df = df[column_order]
##################################################################################
# Make PGK the index column
df.set_index('MBR_PERS_GEN_KEY', inplace=True)

# Create feature list
features_list = list(df.columns)
###################################################################################
# MAP RF
Decile_0 = 0.682
Decile_1 = 0.592
Decile_2 = 0.518
Decile_3 = 0.454
Decile_4 = 0.400
Decile_5 = 0.350
Decile_6 = 0.298
Decile_7 = 0.238
Decile_8 = 0.156
####################################################################################
# Import the model pickle
rxe_filename = 'rxe_rf_clf_pdp_random_sample.sav'
rxe_model = pickle.load(open(rxe_filename, 'rb'))

# Use the pickle model to score dataaset
y_probas = rxe_model.predict_proba(df) #df.values for XgBoost
y_score = pd.DataFrame(y_probas, columns=['prob_0', 'prob_1'])
y_score = y_score.drop(columns=['prob_0'],axis=1)
y_score.columns = ['rxe_resp_prob']

# Bring PGK back to the df & add scored probabilities
df.reset_index(inplace=True)
df_scored_pdp = pd.concat([df,y_score], axis=1)

# Add Deciles based on test data cutoffs
conditions = [
    (df_scored_pdp['rxe_resp_prob'] <= Decile_8),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_8) & (df_scored_pdp['rxe_resp_prob'] <= Decile_7)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_7) & (df_scored_pdp['rxe_resp_prob'] <= Decile_6)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_6) & (df_scored_pdp['rxe_resp_prob'] <= Decile_5)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_5) & (df_scored_pdp['rxe_resp_prob'] <= Decile_4)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_4) & (df_scored_pdp['rxe_resp_prob'] <= Decile_3)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_3) & (df_scored_pdp['rxe_resp_prob'] <= Decile_2)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_2) & (df_scored_pdp['rxe_resp_prob'] <= Decile_1)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_1) & (df_scored_pdp['rxe_resp_prob'] <= Decile_0)),
    (df_scored_pdp['rxe_resp_prob'] > Decile_0)]
deciles = [9,8,7,6,5,4,3,2,1,0]

# Add deciles to the scored rxe population
df_scored_pdp['rxe_resp_decile'] = np.select(conditions,deciles,default=np.nan)

# Add score date
SCORING_DATE = date.today()
df_scored_pdp['SCORE_DATE'] = SCORING_DATE.strftime('%Y%m%d')

# Rename Columns
df_scored_pdp.rename(columns={'rxe_resp_prob': 'MODEL_SCORE', 'rxe_resp_decile': 'DECILE'}, inplace=True)

# Change dtype of Decile
df_scored_pdp['DECILE'] = df_scored_pdp.DECILE.astype(int)

# Add MAPD indicator
df_scored_pdp['IND_MAPD'] = 0

# Subset to the list of columns for final scoring table
columns_final = ['MBR_PERS_GEN_KEY','IND_MAPD','MODEL_SCORE','DECILE','SCORE_DATE']
df_scored_pdp = df_scored_pdp[columns_final]

# Export to CSV
# May wish to choose path for CSV file by placing in front of file name
df_scored_pdp.to_csv('rxe_model_scored_pdp.csv', encoding='utf-8',index=False)


# Merge
frames = [df_scored_mapd, df_scored_pdp]
result = pd.concat(frames)
result.to_csv('rxe_model_scored_all.csv', encoding='utf-8',index=False)

# System Environment
import sys; print(sys.executable); print(sys.version)

# Libraries
import pandas as pd ; print("Pandas Version:",pd.__version__)
import numpy as np ; print("NumPy Version:",np.__version__)
import pyreadstat
import pickle
from datetime import date


# Import dataset to be scored
path = ''
filename = 'scoring_data.csv'
filepath = f'{path}{filename}'
prod_data1 = pd.read_csv(filepath, header=0)

# Change all Columns to uppercase
prod_data1.columns = prod_data1.columns.str.upper()
##################################################################################
# Quick & Dirty Collapse data for duplications
prod_data1 = prod_data1.sort_values(by=['IND_MAPD','IND_PDP'],ascending=False)
prod_data1 = prod_data1.groupby('MBR_PERS_GEN_KEY', as_index=False).first()
prod_data1.MBR_PERS_GEN_KEY.value_counts()
###################################################################################
# Features from SAS Dataset
prod_features = ['MBR_PERS_GEN_KEY','IND_MAPD','IND_PDP',
                  'NTWPERYR', 'CHVA',
                  'RXNUM','RXBRAND','RXSOWRX','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE',
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAIL_ORDER_6M',
                  'RX_CNT_MAINT_DRUG_6M','RX_CNT_RHTSRCE_6M','RX_CNT_RX_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'MABH_SEG','PDPBH_SEG'
                 ]
df = prod_data1[prod_features]
##################################################################################
# Clean Where MAPD & PDP == 1
df['IND_PDP'] = df.IND_PDP.mask(((df.IND_MAPD == 1) & (df.IND_PDP == 1)), 0)


# Numerical Features
number_features = ['MBR_PERS_GEN_KEY'
                         ,'IND_MAPD'
                         ,'IND_PDP'
                         ,'NTWPERYR'
                         ,'CHVA'
                         ,'RXNUM'
                         ,'RXBRAND'
                         ,'RXSOWRX'
                         ,'HWRXLOYL'
                         ,'TENURE_MBR_COV'
                         ,'HUM_AGE'
                         ,'RX_ALLOWED_AMT_6M'
                         ,'RX_CNT_MAIL_ORDER_6M'
                         ,'RX_CNT_MAINT_DRUG_6M'
                         ,'RX_CNT_RHTSRCE_6M'
                         ,'RX_CNT_RX_6M'
                         ,'RX_CNT_TIER1_6M'
                         ,'RX_CNT_TIER2_6M'
                         ,'RX_MBR_RESP_AMT_6M'
                         ,'RX_PAID_AMT_6M'
                         ,'TS_LAST_LOGIN'
                         ,'TS_LAST_CALL'
                  ]

num_var = df[number_features].copy()
####################################################################################
# Categorical Features for dataset
# Split the df to numbers & categorical for quick exploration of features
# member_data.select_dtypes(include=[object]).head() # df.loc[:, df.dtypes == np.float64]

category_features = ['MBR_PERS_GEN_KEY'
                        ,'MABH_SEG'
                        ,'PDPBH_SEG'
                    ]
cat_var = df[category_features].copy()
####################################################################################
#############################
# Clean Categorical Variables
#############################
# Create the Dummy Variables: If doing logistic, be sure to n-1 for dummy variables
# MAPD & PDP BEHAVIORAL SEGMENTATION
# Replaces None/Nan with Other and Nulls
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['C1'], 'Support-Seeking Participators')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['C3','H3'], 'Health Services Maximizers')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H1','C2'], 'Self-Engaged Optimists')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H6','H7','C6'], 'Skeptical Control-Seekers')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H2','C4'], 'Auto-pilot Participators')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H5','C5'], 'Simplicity-Seeking Followers')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H8','C7'], 'Overwhelmed and Reluctant Reactors')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H4'], 'Healthy Self-Sustainers')

cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P1'], 'Proactive Maximizer')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P2'], 'Reactive Engager')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P3'], 'Frugal Participator')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P4'], 'Complacent Follower')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P5'], 'Healthy Independent')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P6'], 'Overwhelmed & Detached')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P7'], 'Agreeably Disengaged')

cat_var['MABH_SEG'] = cat_var.MABH_SEG.fillna('NO RECORD')
cat_var['PDPBH_SEG'] = cat_var.PDPBH_SEG.fillna('NO RECORD')

# MAPD beh seg
mapd_bseg_cat = pd.get_dummies(cat_var[['MABH_SEG']])
mapd_bseg_cat['MBR_PERS_GEN_KEY'] = cat_var.loc[:,'MBR_PERS_GEN_KEY']

# PDP beh seg
pdp_bseg_cat = pd.get_dummies(cat_var[['PDPBH_SEG']])
pdp_bseg_cat['MBR_PERS_GEN_KEY'] = cat_var.loc[:,'MBR_PERS_GEN_KEY']

# Combine Categorical Features
cat_var_sel = ['MBR_PERS_GEN_KEY'
              ,'MABH_SEG'
              ,'PDPBH_SEG']
cat_var_subset = cat_var[cat_var_sel]
cat_var_subset = pd.merge(cat_var_subset,mapd_bseg_cat,how='left',on='MBR_PERS_GEN_KEY')
cat_var_subset = pd.merge(cat_var_subset,pdp_bseg_cat,how='left',on='MBR_PERS_GEN_KEY')
cat_var_subset.head()
################################################################################################
# Select final columns
cat_var_fin = [
    'MBR_PERS_GEN_KEY'
    ,'MABH_SEG_Auto-pilot Participators','MABH_SEG_Health Services Maximizers','MABH_SEG_Healthy Self-Sustainers','MABH_SEG_NO RECORD','MABH_SEG_Overwhelmed and Reluctant Reactors','MABH_SEG_Self-Engaged Optimists','MABH_SEG_Simplicity-Seeking Followers','MABH_SEG_Skeptical Control-Seekers','MABH_SEG_Support-Seeking Participators'
    ,'PDPBH_SEG_Agreeably Disengaged','PDPBH_SEG_Complacent Follower','PDPBH_SEG_Frugal Participator', 'PDPBH_SEG_Healthy Independent','PDPBH_SEG_NO RECORD','PDPBH_SEG_Overwhelmed & Detached','PDPBH_SEG_Proactive Maximizer', 'PDPBH_SEG_Reactive Engager'
]

cat_var = cat_var_subset[cat_var_fin]
####################################################################################
# Join Categorical & Numerical Variables
df = pd.merge(num_var,cat_var,how='left',on='MBR_PERS_GEN_KEY')
####################################################################################
mapd_train = df[df.IND_MAPD == 1].copy()
pdp_train = df[df.IND_PDP == 1].copy()
print(mapd_train.MBR_PERS_GEN_KEY.count())
print(pdp_train.MBR_PERS_GEN_KEY.count())


# Imputate CAT values
mapd_train['TENURE_MBR_COV'].fillna(mapd_train.TENURE_MBR_COV.mean(),inplace = True) # New Member
mapd_train['HUM_AGE'].fillna(mapd_train.HUM_AGE.mean(),inplace = True) # New Member

# Imputate AMLK values
mapd_train['NTWPERYR'].fillna(mapd_train.NTWPERYR.mean(),inplace = True) # Net Worth Per Year
mapd_train['CHVA'].fillna(mapd_train.CHVA.mean(),inplace = True) # Census Median Home Value AMLK
mapd_train['RXNUM'].fillna(mapd_train.RXNUM.mean(),inplace = True) # # of Meds (modeled)
mapd_train['HWRXLOYL'].fillna(mapd_train.HWRXLOYL.mean(),inplace = True) # Rx Pharmacy Loyalty

print('Number of Nulls: ',mapd_train.size - mapd_train.count().sum())
# Fill remaining with 0s
mapd_train = mapd_train.fillna(0)
print('Number of Nulls: ',mapd_train.size - mapd_train.count().sum())
#############################################################################################
# Number of Available scripts to Convert
mapd_train['RX_CNTRX_HPRX'] = mapd_train.RX_CNT_RX_6M - mapd_train.RX_CNT_RHTSRCE_6M
#############################################################################################
# Engaged Members
engaged_col = ['MABH_SEG_Support-Seeking Participators'
               ,'MABH_SEG_Health Services Maximizers'
               ,'MABH_SEG_Self-Engaged Optimists'
               ,'MABH_SEG_Auto-pilot Participators'
#                ,'PDPBH_SEG_Frugal Participator'
#                ,'PDPBH_SEG_Proactive Maximizer'
#                ,'PDPBH_SEG_Reactive Engager'
              ]
mapd_train['ENGAGED_MEMBERS'] = mapd_train[engaged_col].any(axis=1)
mapd_train['ENGAGED_MEMBERS'] = mapd_train.loc[:,'ENGAGED_MEMBERS'].replace([True], 1)
mapd_train['ENGAGED_MEMBERS'] = mapd_train.loc[:,'ENGAGED_MEMBERS'].replace([False], 0)

# Unengaged Members
unengaged_col = ['MABH_SEG_Healthy Self-Sustainers',
               'MABH_SEG_Overwhelmed and Reluctant Reactors',
               'MABH_SEG_Simplicity-Seeking Followers',
               'MABH_SEG_Skeptical Control-Seekers',
#                'PDPBH_SEG_Agreeably Disengaged',
#                'PDPBH_SEG_Complacent Follower',
#                'PDPBH_SEG_Healthy Independent',
#                'PDPBH_SEG_Overwhelmed & Detached'
                ]

mapd_train['UNENGAGED_MEMBERS'] = mapd_train[unengaged_col].any(axis=1)
mapd_train['UNENGAGED_MEMBERS'] = mapd_train.loc[:,'UNENGAGED_MEMBERS'].replace([True], 1)
mapd_train['UNENGAGED_MEMBERS'] = mapd_train.loc[:,'UNENGAGED_MEMBERS'].replace([False], 0)

# No Behavioral Segments
noseg_col = ['MABH_SEG_NO RECORD'
#              ,'PDPBH_SEG_NO RECORD'
            ]
mapd_train['NO_BEHSEG_MEMBERS'] = mapd_train[noseg_col].all(axis=1)
mapd_train['NO_BEHSEG_MEMBERS'] = mapd_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([True], 1)
mapd_train['NO_BEHSEG_MEMBERS'] = mapd_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([False], 0)
#####################################################################################################
mapd_train.loc[mapd_train.NTWPERYR < 0, 'NTWPERYR'] = 0
mapd_train.loc[mapd_train.TS_LAST_LOGIN < 0, 'TS_LAST_LOGIN'] = 0
mapd_train.loc[mapd_train.TS_LAST_CALL < 0, 'TS_LAST_CALL'] = 0



df = mapd_train.copy()
column_order = ['MBR_PERS_GEN_KEY',
                  'NTWPERYR', 'CHVA',
                  'RXNUM','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE',
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAINT_DRUG_6M','RX_CNT_RX_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'RX_CNTRX_HPRX',
                  'ENGAGED_MEMBERS','UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
                 ]
df = df[column_order]
##################################################################################
# Make PGK the index column
df.set_index('MBR_PERS_GEN_KEY', inplace=True)

# Create feature list
features_list = list(df.columns)
###################################################################################
# MAP RF
Decile_0 = 0.658
Decile_1 = 0.596
Decile_2 = 0.548
Decile_3 = 0.504
Decile_4 = 0.460
Decile_5 = 0.418
Decile_6 = 0.370
Decile_7 = 0.318
Decile_8 = 0.250
####################################################################################
# Import the model pickle
rxe_filename = 'rxe_rf_clf_mapd_random_sample.sav'
rxe_model = pickle.load(open(rxe_filename, 'rb'))

# Use the pickle model to score dataaset
y_probas = rxe_model.predict_proba(df) #df.values for XgBoost
y_score = pd.DataFrame(y_probas, columns=['prob_0', 'prob_1'])
y_score = y_score.drop(columns=['prob_0'],axis=1)
y_score.columns = ['rxe_resp_prob']

# Bring PGK back to the df & add scored probabilities
df.reset_index(inplace=True)
df_scored_mapd = pd.concat([df,y_score], axis=1)

# Add Deciles based on test data cutoffs
conditions = [
    (df_scored_mapd['rxe_resp_prob'] <= Decile_8),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_8) & (df_scored_mapd['rxe_resp_prob'] <= Decile_7)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_7) & (df_scored_mapd['rxe_resp_prob'] <= Decile_6)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_6) & (df_scored_mapd['rxe_resp_prob'] <= Decile_5)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_5) & (df_scored_mapd['rxe_resp_prob'] <= Decile_4)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_4) & (df_scored_mapd['rxe_resp_prob'] <= Decile_3)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_3) & (df_scored_mapd['rxe_resp_prob'] <= Decile_2)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_2) & (df_scored_mapd['rxe_resp_prob'] <= Decile_1)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_1) & (df_scored_mapd['rxe_resp_prob'] <= Decile_0)),
    (df_scored_mapd['rxe_resp_prob'] > Decile_0)]
deciles = [9,8,7,6,5,4,3,2,1,0]

# Add deciles to the scored rxe population
df_scored_mapd['rxe_resp_decile'] = np.select(conditions,deciles,default=np.nan)

# Add score date
SCORING_DATE = date.today()
df_scored_mapd['SCORE_DATE'] = SCORING_DATE.strftime('%Y%m%d')

# Rename Columns
df_scored_mapd.rename(columns={'rxe_resp_prob': 'MODEL_SCORE', 'rxe_resp_decile': 'DECILE'}, inplace=True)

# Change dtype of Decile
df_scored_mapd['DECILE'] = df_scored_mapd.DECILE.astype(int)

# Add MAPD indicator
df_scored_mapd['IND_MAPD'] = 1

# Subset to the list of columns for final scoring table
columns_final = ['MBR_PERS_GEN_KEY','IND_MAPD','MODEL_SCORE','DECILE','SCORE_DATE']
df_scored_mapd = df_scored_mapd[columns_final]

# Export to CSV
# May wish to choose path for CSV file by placing in front of file name
df_scored_mapd.to_csv('rxe_model_scored_mapd.csv', encoding='utf-8',index=False)



# Imputate CAT values
pdp_train['TENURE_MBR_COV'].fillna(pdp_train.TENURE_MBR_COV.mean(),inplace = True) # New Member
pdp_train['HUM_AGE'].fillna(pdp_train.HUM_AGE.mean(),inplace = True) # New Member

# Imputate AMLK values
pdp_train['NTWPERYR'].fillna(pdp_train.NTWPERYR.mean(),inplace = True) # Net Worth Per Year
pdp_train['CHVA'].fillna(pdp_train.CHVA.mean(),inplace = True) # Census Median Home Value AMLK
pdp_train['RXBRAND'].fillna(pdp_train.RXBRAND.mean(),inplace = True) # Prefer Brand Meds (0 more likely)
pdp_train['RXSOWRX'].fillna(pdp_train.RXSOWRX.mean(),inplace = True) # RX - Share of Wallet (0 loyal)
pdp_train['HWRXLOYL'].fillna(pdp_train.HWRXLOYL.mean(),inplace = True) # Rx Pharmacy Loyalty

print('Number of Nulls: ',pdp_train.size - pdp_train.count().sum())
# Fill remaining with 0s
pdp_train = pdp_train.fillna(0)
print('Number of Nulls: ',pdp_train.size - pdp_train.count().sum())
#############################################################################################
# Number of Available scripts to Convert
pdp_train['RX_CNTRX_HPRX'] = pdp_train.RX_CNT_RX_6M - pdp_train.RX_CNT_RHTSRCE_6M
#############################################################################################
# Engaged Members
engaged_col = ['PDPBH_SEG_Frugal Participator'
               ,'PDPBH_SEG_Proactive Maximizer'
               ,'PDPBH_SEG_Reactive Engager'
              ]
pdp_train['ENGAGED_MEMBERS'] = pdp_train[engaged_col].any(axis=1)
pdp_train['ENGAGED_MEMBERS'] = pdp_train.loc[:,'ENGAGED_MEMBERS'].replace([True], 1)
pdp_train['ENGAGED_MEMBERS'] = pdp_train.loc[:,'ENGAGED_MEMBERS'].replace([False], 0)

# Unengaged Members
unengaged_col = ['PDPBH_SEG_Agreeably Disengaged',
               'PDPBH_SEG_Complacent Follower',
               'PDPBH_SEG_Healthy Independent',
               'PDPBH_SEG_Overwhelmed & Detached'
                ]

pdp_train['UNENGAGED_MEMBERS'] = pdp_train[unengaged_col].any(axis=1)
pdp_train['UNENGAGED_MEMBERS'] = pdp_train.loc[:,'UNENGAGED_MEMBERS'].replace([True], 1)
pdp_train['UNENGAGED_MEMBERS'] = pdp_train.loc[:,'UNENGAGED_MEMBERS'].replace([False], 0)

# No Behavioral Segments
noseg_col = ['PDPBH_SEG_NO RECORD']
pdp_train['NO_BEHSEG_MEMBERS'] = pdp_train[noseg_col].all(axis=1)
pdp_train['NO_BEHSEG_MEMBERS'] = pdp_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([True], 1)
pdp_train['NO_BEHSEG_MEMBERS'] = pdp_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([False], 0)
#####################################################################################################
pdp_train.loc[pdp_train.NTWPERYR < 0, 'NTWPERYR'] = 0
pdp_train.loc[pdp_train.TS_LAST_LOGIN < 0, 'TS_LAST_LOGIN'] = 0
pdp_train.loc[pdp_train.TS_LAST_CALL < 0, 'TS_LAST_CALL'] = 0



df = pdp_train.copy()
column_order = ['MBR_PERS_GEN_KEY',
                  'NTWPERYR', 'CHVA',
                  'RXBRAND','RXSOWRX','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE',
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAIL_ORDER_6M', 'RX_CNT_MAINT_DRUG_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'RX_CNTRX_HPRX',
                  'ENGAGED_MEMBERS','UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
                 ]
df = df[column_order]
##################################################################################
# Make PGK the index column
df.set_index('MBR_PERS_GEN_KEY', inplace=True)

# Create feature list
features_list = list(df.columns)
###################################################################################
# MAP RF
Decile_0 = 0.682
Decile_1 = 0.592
Decile_2 = 0.518
Decile_3 = 0.454
Decile_4 = 0.400
Decile_5 = 0.350
Decile_6 = 0.298
Decile_7 = 0.238
Decile_8 = 0.156
####################################################################################
# Import the model pickle
rxe_filename = 'rxe_rf_clf_pdp_random_sample.sav'
rxe_model = pickle.load(open(rxe_filename, 'rb'))

# Use the pickle model to score dataaset
y_probas = rxe_model.predict_proba(df) #df.values for XgBoost
y_score = pd.DataFrame(y_probas, columns=['prob_0', 'prob_1'])
y_score = y_score.drop(columns=['prob_0'],axis=1)
y_score.columns = ['rxe_resp_prob']

# Bring PGK back to the df & add scored probabilities
df.reset_index(inplace=True)
df_scored_pdp = pd.concat([df,y_score], axis=1)

# Add Deciles based on test data cutoffs
conditions = [
    (df_scored_pdp['rxe_resp_prob'] <= Decile_8),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_8) & (df_scored_pdp['rxe_resp_prob'] <= Decile_7)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_7) & (df_scored_pdp['rxe_resp_prob'] <= Decile_6)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_6) & (df_scored_pdp['rxe_resp_prob'] <= Decile_5)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_5) & (df_scored_pdp['rxe_resp_prob'] <= Decile_4)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_4) & (df_scored_pdp['rxe_resp_prob'] <= Decile_3)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_3) & (df_scored_pdp['rxe_resp_prob'] <= Decile_2)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_2) & (df_scored_pdp['rxe_resp_prob'] <= Decile_1)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_1) & (df_scored_pdp['rxe_resp_prob'] <= Decile_0)),
    (df_scored_pdp['rxe_resp_prob'] > Decile_0)]
deciles = [9,8,7,6,5,4,3,2,1,0]

# Add deciles to the scored rxe population
df_scored_pdp['rxe_resp_decile'] = np.select(conditions,deciles,default=np.nan)

# Add score date
SCORING_DATE = date.today()
df_scored_pdp['SCORE_DATE'] = SCORING_DATE.strftime('%Y%m%d')

# Rename Columns
df_scored_pdp.rename(columns={'rxe_resp_prob': 'MODEL_SCORE', 'rxe_resp_decile': 'DECILE'}, inplace=True)

# Change dtype of Decile
df_scored_pdp['DECILE'] = df_scored_pdp.DECILE.astype(int)

# Add MAPD indicator
df_scored_pdp['IND_MAPD'] = 0

# Subset to the list of columns for final scoring table
columns_final = ['MBR_PERS_GEN_KEY','IND_MAPD','MODEL_SCORE','DECILE','SCORE_DATE']
df_scored_pdp = df_scored_pdp[columns_final]

# Export to CSV
# May wish to choose path for CSV file by placing in front of file name
df_scored_pdp.to_csv('rxe_model_scored_pdp.csv', encoding='utf-8',index=False)


# Merge
frames = [df_scored_mapd, df_scored_pdp]
result = pd.concat(frames)
result.to_csv('rxe_model_scored_all.csv', encoding='utf-8',index=False)

# Read in target data
path = 'data/'
filename = 'RxE Leads with Contact and Shipping 0619.csv'
filepath = f'{path}{filename}'
print(filepath)
df5 = pd.read_csv(filepath,header=0,usecols=[0,1,2,3,4,5,6],
                  names = ['LEAD_ID','LEAD_TYPE','POPULATION_IND',
                           'MEMBER_ID','CONTACT_DATE','MEMBER_ENROLLMENT','RX_ENROLLMENTS'])


# Convert Columns to uppercase
df5.columns = df5.columns.str.upper()
# Add Date for data pull
df5['CONTACT_DATE'] = df5.CONTACT_DATE.mask(df5.CONTACT_DATE.isnull(), '2019-06-01')

df5 = df5.sort_values(by=['MEMBER_ENROLLMENT','RX_ENROLLMENTS'],ascending=False)
df5 = df5.groupby('MEMBER_ID', as_index=False).first()
##########################################
# Read in target data
path = 'data/'
filename = 'RxE Leads with Contact and Shipping 0519.csv'
filepath = f'{path}{filename}'
print(filepath)
df4 = pd.read_csv(filepath,header=0,usecols=[0,1,2,3,4,5,6],
                  names = ['LEAD_ID','LEAD_TYPE','POPULATION_IND',
                           'MEMBER_ID','CONTACT_DATE','MEMBER_ENROLLMENT','RX_ENROLLMENTS'])

# Convert Columns to uppercase
df4.columns = df4.columns.str.upper()
# Add Date for data pull
df4['CONTACT_DATE'] = df4.CONTACT_DATE.mask(df4.CONTACT_DATE.isnull(), '2019-05-01')

df4 = df4.sort_values(by=['MEMBER_ENROLLMENT','RX_ENROLLMENTS'],ascending=False)
df4 = df4.groupby('MEMBER_ID', as_index=False).first()
##########################################

# Read in target data
path = 'data/'
filename = 'RxE Leads with Contact and Shipping 0419.csv'
filepath = f'{path}{filename}'
print(filepath)
df3 = pd.read_csv(filepath,header=0,usecols=[0,1,2,3,4,5,6],
                  names = ['LEAD_ID','LEAD_TYPE','POPULATION_IND',
                           'MEMBER_ID','CONTACT_DATE','MEMBER_ENROLLMENT','RX_ENROLLMENTS'])

# Convert Columns to uppercase
df3.columns = df3.columns.str.upper()
# Add Date for data pull
df3['CONTACT_DATE'] = df3.CONTACT_DATE.mask(df3.CONTACT_DATE.isnull(), '2019-04-01')

# # Quick & Dirty Collapse data for duplications
df3 = df3.sort_values(by=['MEMBER_ENROLLMENT','RX_ENROLLMENTS'],ascending=False)
df3 = df3.groupby('MEMBER_ID', as_index=False).first()
##########################################
# Read in target data
path = 'data/'
filename = 'RxE Leads with Contact and Shipping 0319.csv'
filepath = f'{path}{filename}'
print(filepath)
df2 = pd.read_csv(filepath,header=0,usecols=[0,1,2,3,4,5,6],
                  names = ['LEAD_ID','LEAD_TYPE','POPULATION_IND',
                           'MEMBER_ID','CONTACT_DATE','MEMBER_ENROLLMENT','RX_ENROLLMENTS'])

# Convert Columns to uppercase
df2.columns = df2.columns.str.upper()
# Add Date for data pull
df2['CONTACT_DATE'] = df2.CONTACT_DATE.mask(df2.CONTACT_DATE.isnull(), '2019-03-01')

# # Quick & Dirty Collapse data for duplications
df2 = df2.sort_values(by=['MEMBER_ENROLLMENT','RX_ENROLLMENTS'],ascending=False)
df2 = df2.groupby('MEMBER_ID', as_index=False).first()
##########################################
# Read in target data
path = 'data/'
filename = 'RxE Leads with Contact and Shipping 0219.csv'
filepath = f'{path}{filename}'
print(filepath)
df1 = pd.read_csv(filepath,header=0,usecols=[0,1,2,3,4,5,6],
                  names = ['LEAD_ID','LEAD_TYPE','POPULATION_IND',
                           'MEMBER_ID','CONTACT_DATE','MEMBER_ENROLLMENT','RX_ENROLLMENTS'])

# Convert Columns to uppercase
df1.columns = df1.columns.str.upper()
# Add Date for data pull
df1['CONTACT_DATE'] = df1.CONTACT_DATE.mask(df1.CONTACT_DATE.isnull(), '2019-02-01')

# # Quick & Dirty Collapse data for duplications
df1 = df1.sort_values(by=['MEMBER_ENROLLMENT','RX_ENROLLMENTS'],ascending=False)
df1 = df1.groupby('MEMBER_ID', as_index=False).first()
##########################################
# Merge
frames = [df1, df2, df3, df4, df5]
result = pd.concat(frames)

# # Quick & Dirty Collapse data for duplications
result = result.sort_values(by=['MEMBER_ENROLLMENT','RX_ENROLLMENTS'],ascending=False)
result = result.groupby('MEMBER_ID', as_index=False).first()
##########################################
# Indicator for Rx Enrollment
result['RX_ENROLL'] = result['RX_ENROLLMENTS']
result['RX_ENROLL'] = result.RX_ENROLL.mask(result.RX_ENROLL> 0, 1)

# Data Exploration

# Distn for Unique Members with NULL CONTACT DATES
print(result.MEMBER_ID.count(),'\n')
print(result.loc[:,'LEAD_TYPE'].value_counts() / result.loc[:,'LEAD_TYPE'].count()*100,'\n')
print(result.loc[:,'POPULATION_IND'].value_counts() / result.loc[:,'POPULATION_IND'].count()*100,'\n')
print(result.loc[:,'MEMBER_ENROLLMENT'].value_counts() / result.loc[:,'MEMBER_ENROLLMENT'].count()*100,'\n')
print(result.loc[:,'RX_ENROLL'].value_counts() / result.loc[:,'RX_ENROLL'].count()*100,'\n')


# Distn for Unique Members with NULL CONTACT DATES
print(result.MEMBER_ID.count(),'\n')
print(result.loc[:,'LEAD_TYPE'].value_counts() )
print(result.loc[:,'POPULATION_IND'].value_counts() )
print(result.loc[:,'MEMBER_ENROLLMENT'].value_counts() )
print(result.loc[:,'RX_ENROLL'].value_counts() )


# # Distn for Unique members with NULL RX_ENROLL labeled 0
# result_rx_null = result

# result_rx_null['RX_ENROLLMENTS'] = result_rx_null.loc[:,'RX_ENROLLMENTS'].replace([None,'nan'], 0)
# result_rx_null['RX_ENROLL'] = result_rx_null.loc[:,'RX_ENROLL'].replace([None,'nan'], 0)
# print(result_rx_null.MEMBER_ID.count(),'\n')
# print(result_rx_null.loc[:,'LEAD_TYPE'].value_counts() / result_rx_null.loc[:,'LEAD_TYPE'].count()*100,'\n')
# print(result_rx_null.loc[:,'POPULATION_IND'].value_counts() / result_rx_null.loc[:,'POPULATION_IND'].count()*100,'\n')
# print(result_rx_null.loc[:,'MEMBER_ENROLLMENT'].value_counts() / result_rx_null.loc[:,'MEMBER_ENROLLMENT'].count()*100,'\n')
# print(result_rx_null.loc[:,'RX_ENROLL'].value_counts() / result_rx_null.loc[:,'RX_ENROLL'].count()*100,'\n')

# Distn for Removing NULL Contact Dates
# Already cleaned the data in the data pre process step, so we can use
# result as result_clean
result_clean = result # [result.CONTACT_DATE.notnull()]

print(result_clean.MEMBER_ID.count(),'\n')
print(result_clean.loc[:,'LEAD_TYPE'].value_counts() / result_clean.loc[:,'LEAD_TYPE'].count()*100,'\n')
print(result_clean.loc[:,'POPULATION_IND'].value_counts() / result_clean.loc[:,'POPULATION_IND'].count()*100,'\n')
print(result_clean.loc[:,'MEMBER_ENROLLMENT'].value_counts() / result_clean.loc[:,'MEMBER_ENROLLMENT'].count()*100,'\n')
print(result_clean.loc[:,'RX_ENROLL'].value_counts() / result_clean.loc[:,'RX_ENROLL'].count()*100,'\n')

# Distn for Removing NULL Contact Dates & Changing NULL for RX_ENROLL to 0
# Indicator for Rx Conv
result_clean['MEMBER_ENROLLMENT'] = result_clean.loc[:,'MEMBER_ENROLLMENT'].replace([None,'nan'], 0)
result_clean['RX_ENROLLMENTS'] = result_clean.loc[:,'RX_ENROLLMENTS'].replace([None,'nan'], 0)
result_clean['RX_ENROLL'] = result_clean.loc[:,'RX_ENROLL'].replace([None,'nan'], 0)

print(result_clean.MEMBER_ID.count(),'\n')
print(result_clean.loc[:,'LEAD_TYPE'].value_counts() / result_clean.loc[:,'LEAD_TYPE'].count()*100,'\n')
print(result_clean.loc[:,'POPULATION_IND'].value_counts() / result_clean.loc[:,'POPULATION_IND'].count()*100,'\n')
print(result_clean.loc[:,'MEMBER_ENROLLMENT'].value_counts() / result_clean.loc[:,'MEMBER_ENROLLMENT'].count()*100,'\n')
print(result_clean.loc[:,'RX_ENROLL'].value_counts() / result_clean.loc[:,'RX_ENROLL'].count()*100,'\n')

# Add Month Value for easy Indexing
result_clean['CONTACT_DATE'] = pd.to_datetime(result_clean['CONTACT_DATE'], errors='coerce')
result_clean['MONTH'] = result_clean['CONTACT_DATE'].dt.month

# Random Sample for Modeling

result_sample = result_clean
result_sample.MEMBER_ID.count()

# Random Sample of data #10k 0 & 1
result_rand_sample = result_sample.sample(1500000, random_state = 26)

print(result_rand_sample.MEMBER_ID.count(),'\n')
print(result_rand_sample.loc[:,'LEAD_TYPE'].value_counts() / result_rand_sample.loc[:,'LEAD_TYPE'].count()*100,'\n')
print(result_rand_sample.loc[:,'POPULATION_IND'].value_counts() / result_rand_sample.loc[:,'POPULATION_IND'].count()*100,'\n')
print(result_rand_sample.loc[:,'MEMBER_ENROLLMENT'].value_counts() / result_rand_sample.loc[:,'MEMBER_ENROLLMENT'].count()*100,'\n')
print(result_rand_sample.loc[:,'RX_ENROLL'].value_counts() / result_rand_sample.loc[:,'RX_ENROLL'].count()*100,'\n')
# print(result_rand_sample.MEMBER_ID.count(),'\n')
# print(result_rand_sample.LEAD_TYPE.value_counts(),'\n')
# print(result_rand_sample.POPULATION_IND.value_counts(),'\n')
# print(result_rand_sample.MEMBER_ENROLLMENT.value_counts(),'\n')
# print(result_rand_sample.RX_ENROLL.value_counts(),'\n')

# Save file to CSV
# result_rand_sample.to_csv('pgk_model.csv',index=False)
# result.to_csv('pgk_original.csv',index=False)

# SAS CODE

SAS Code done in SAS instead of Python to utilize batch jobs to run overnight to bring in the different features.
- See file "get_model_data"

# Pre-Process for Model Training

# System Environment
import sys; print(sys.executable); print(sys.version)

# Libraries
import pandas as pd ; print("Pandas Version:",pd.__version__)
import numpy as np ; print("NumPy Version:",np.__version__)
from sklearn.model_selection import train_test_split
# from imblearn.over_sampling import SMOTE
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import KFold
from sklearn.model_selection import cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import ExtraTreesClassifier
from xgboost import XGBClassifier
# from sklearn.tree import DecisionTreeClassifier
# from sklearn.tree import export_graphviz
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import brier_score_loss
from sklearn.metrics import f1_score
from sklearn.metrics import roc_auc_score, roc_curve, auc
from sklearn.utils import resample
# from scipy.stats import kstest
# from scipy.stats import ks_2samp
import pickle
import matplotlib.pyplot as plt
import seaborn as sns

# Read in target data
path = 'data/'
filename = 'pgk_clean_random_sample.csv'
filepath = f'{path}{filename}'
print(filepath)
target = pd.read_csv(filepath,header=0)

# Convert Columns to uppercase
target.columns = target.columns.str.upper()

# # Quick & Dirty Collapse data for duplications
target = target.sort_values(by=['MEMBER_ENROLLMENT','RX_ENROLLMENTS'],ascending=False)
target = target.groupby('MBR_PERS_GEN_KEY', as_index=False).first()

target = target.sort_values(by='CONTACT_DATE')

# Quick look at data
target.head()

###########################################################################
# Read in features data
path = 'data/'
filename = 'pgk_clean_random_sample_feature_list.csv'
filepath = f'{path}{filename}'
print(filepath)
target_features = pd.read_csv(filepath,header=0)

# Convert Columns to uppercase
target_features.columns = target_features.columns.str.upper()

# Quick & Dirty Collapse data for duplications
target_features = target_features.sort_values(by=['IND_MAPD','IND_PDP'],ascending=False)
target_features = target_features.groupby('MBR_PERS_GEN_KEY', as_index=False).first()
target_features.MBR_PERS_GEN_KEY.value_counts()

# Quick look at data
target_features.head()
###########################################################################
# Join Data
df = pd.merge(target,target_features,how='left',on='MBR_PERS_GEN_KEY')

# Clean dataset
df['LOB2'] = df.loc[:,'LOB2'].replace(['MA + MEDSUP','GRP MAPD'], 'MAPD')
df['LOB2'] = df.loc[:,'LOB2'].replace(['PDP + MEDSUP','GRP PDP'], 'PDP')
df['LOB2'] = df.loc[:,'LOB2'].replace([None,'nan'], 'NULL')
df['LOB2'] = df.loc[:,'LOB2'].replace(['SG','LG','Medr Other','Hum1','MEDSUP'], 'OTHER')

# Subset to just MAPD & PDP - Drop NULL/OTHERS
df = df[(df.LOB2 == 'MAPD') | (df.LOB2 == 'PDP')]
df = df[(df.POPULATION_IND == 'YSAV') | (df.POPULATION_IND == 'NPRC') | (df.POPULATION_IND == 'NSAV')]

# # Convert LOB2 to Numeric for Modeling
# df_cat = pd.get_dummies(df[['LOB2']])
# df = pd.concat([df,df_cat],axis=1)

# Drop the unnesscary columns
# axis=1: Columns ; axis=0: Rows
# If doing logistic, be sure to n-1 for dummy variables
# df.drop(['LOB2'],axis=1,inplace=True)
df.head()

# Rearrange columns for easier model building
df = df[[col for col in df if col not in ['MEMBER_ENROLLMENT','RX_ENROLLMENTS','RX_ENROLL']]
       + ['MEMBER_ENROLLMENT','RX_ENROLLMENTS','RX_ENROLL']]
##############################################################################
# To separate each month of data
hp_month = target[['MBR_PERS_GEN_KEY','MONTH']]

##########################################
# Read in features data
path = 'data/'
filename = 'rxe_get_model_data_feb_hp.csv'
filepath = f'{path}{filename}'
print(filepath)
feb = pd.read_csv(filepath,header=0)

# Convert Columns to uppercase
feb.columns = feb.columns.str.upper()

# Clean dataset
feb['LOB2'] = feb.loc[:,'LOB2'].replace(['MA + MEDSUP','GRP MAPD'], 'MAPD')
feb['LOB2'] = feb.loc[:,'LOB2'].replace(['PDP + MEDSUP','GRP PDP'], 'PDP')
feb['LOB2'] = feb.loc[:,'LOB2'].replace([None,'nan'], 'NULL')
feb['LOB2'] = feb.loc[:,'LOB2'].replace(['SG','LG','Medr Other','Hum1','MEDSUP'], 'OTHER')

# Subset to just MAPD & PDP - Drop NULL/OTHERS
feb = feb[(feb.LOB2 == 'MAPD') | (feb.LOB2 == 'PDP')]

# # Quick & Dirty Collapse data for duplications
feb = feb.sort_values(by=['LOB2'],ascending=False)
feb = feb.groupby('MBR_PERS_GEN_KEY', as_index=False).first()
# feb.MBR_PERS_GEN_KEY.value_counts()

feb_hp = pd.merge(feb,hp_month,how='left',on='MBR_PERS_GEN_KEY')
feb_hp = feb_hp[feb_hp.MONTH == 2]

##########################################
# Read in features data
path = 'data/'
filename = 'rxe_get_model_data_mar_hp.csv'
filepath = f'{path}{filename}'
print(filepath)
mar = pd.read_csv(filepath,header=0)

# Convert Columns to uppercase
mar.columns = mar.columns.str.upper()

# Clean dataset
mar['LOB2'] = mar.loc[:,'LOB2'].replace(['MA + MEDSUP','GRP MAPD'], 'MAPD')
mar['LOB2'] = mar.loc[:,'LOB2'].replace(['PDP + MEDSUP','GRP PDP'], 'PDP')
mar['LOB2'] = mar.loc[:,'LOB2'].replace([None,'nan'], 'NULL')
mar['LOB2'] = mar.loc[:,'LOB2'].replace(['SG','LG','Medr Other','Hum1','MEDSUP'], 'OTHER')

# Subset to just MAPD & PDP - Drop NULL/OTHERS
mar = mar[(mar.LOB2 == 'MAPD') | (mar.LOB2 == 'PDP')]

# # Quick & Dirty Collapse data for duplications
mar = mar.sort_values(by=['LOB2'],ascending=False)
mar = mar.groupby('MBR_PERS_GEN_KEY', as_index=False).first()
# mar.MBR_PERS_GEN_KEY.value_counts()

mar_hp = pd.merge(mar,hp_month,how='left',on='MBR_PERS_GEN_KEY')
mar_hp = mar_hp[mar_hp.MONTH == 3]

##########################################
# Read in features data
path = 'data/'
filename = 'rxe_get_model_data_apr_hp.csv'
filepath = f'{path}{filename}'
print(filepath)
apr = pd.read_csv(filepath,header=0)

# Convert Columns to uppercase
apr.columns = apr.columns.str.upper()

# Clean dataset
apr['LOB2'] = apr.loc[:,'LOB2'].replace(['MA + MEDSUP','GRP MAPD'], 'MAPD')
apr['LOB2'] = apr.loc[:,'LOB2'].replace(['PDP + MEDSUP','GRP PDP'], 'PDP')
apr['LOB2'] = apr.loc[:,'LOB2'].replace([None,'nan'], 'NULL')
apr['LOB2'] = apr.loc[:,'LOB2'].replace(['SG','LG','Medr Other','Hum1','MEDSUP'], 'OTHER')

# Subset to just MAPD & PDP - Drop NULL/OTHERS
apr = apr[(apr.LOB2 == 'MAPD') | (apr.LOB2 == 'PDP')]

# # Quick & Dirty Collapse data for duplications
apr = apr.sort_values(by=['LOB2'],ascending=False)
apr = apr.groupby('MBR_PERS_GEN_KEY', as_index=False).first()
# apr.MBR_PERS_GEN_KEY.value_counts()

apr_hp = pd.merge(apr,hp_month,how='left',on='MBR_PERS_GEN_KEY')
apr_hp = apr_hp[apr_hp.MONTH == 4]

##########################################
# Read in features data
path = 'data/'
filename = 'rxe_get_model_data_may_hp.csv'
filepath = f'{path}{filename}'
print(filepath)
may = pd.read_csv(filepath,header=0)

# Convert Columns to uppercase
may.columns = may.columns.str.upper()

# Clean dataset
may['LOB2'] = may.loc[:,'LOB2'].replace(['MA + MEDSUP','GRP MAPD'], 'MAPD')
may['LOB2'] = may.loc[:,'LOB2'].replace(['PDP + MEDSUP','GRP PDP'], 'PDP')
may['LOB2'] = may.loc[:,'LOB2'].replace([None,'nan'], 'NULL')
may['LOB2'] = may.loc[:,'LOB2'].replace(['SG','LG','Medr Other','Hum1','MEDSUP'], 'OTHER')

# Subset to just MAPD & PDP - Drop NULL/OTHERS
may = may[(may.LOB2 == 'MAPD') | (may.LOB2 == 'PDP')]

# # Quick & Dirty Collapse data for duplications
may = may.sort_values(by=['LOB2'],ascending=False)
may = may.groupby('MBR_PERS_GEN_KEY', as_index=False).first()
# may.MBR_PERS_GEN_KEY.value_counts()

may_hp = pd.merge(may,hp_month,how='left',on='MBR_PERS_GEN_KEY')
may_hp = may_hp[may_hp.MONTH == 5]

##########################################
# Read in features data
path = 'data/'
filename = 'rxe_get_model_data_may_hp.csv' # Since time of run we wouldnt have June, we would use May again
filepath = f'{path}{filename}'
print(filepath)
jun = pd.read_csv(filepath,header=0)

# Convert Columns to uppercase
jun.columns = jun.columns.str.upper()

# Clean dataset
jun['LOB2'] = jun.loc[:,'LOB2'].replace(['MA + MEDSUP','GRP MAPD'], 'MAPD')
jun['LOB2'] = jun.loc[:,'LOB2'].replace(['PDP + MEDSUP','GRP PDP'], 'PDP')
jun['LOB2'] = jun.loc[:,'LOB2'].replace([None,'nan'], 'NULL')
jun['LOB2'] = jun.loc[:,'LOB2'].replace(['SG','LG','Medr Other','Hum1','MEDSUP'], 'OTHER')

# Subset to just MAPD & PDP - Drop NULL/OTHERS
jun = jun[(jun.LOB2 == 'MAPD') | (jun.LOB2 == 'PDP')]

# # Quick & Dirty Collapse data for duplications
jun = jun.sort_values(by=['LOB2'],ascending=False)
jun = jun.groupby('MBR_PERS_GEN_KEY', as_index=False).first()
# jun.MBR_PERS_GEN_KEY.value_counts()

# Grab just the available months
jun_hp = pd.merge(jun,hp_month,how='left',on='MBR_PERS_GEN_KEY')
jun_hp = jun_hp[jun_hp.MONTH == 6]

##########################################
# Merge
hp_frames = [feb_hp, mar_hp, apr_hp, may_hp, jun_hp]
hp_result = pd.concat(hp_frames)

# Quick & Dirty Collapse data for duplications
hp_result = hp_result.sort_values(by=['LOB2'],ascending=False)
hp_result = hp_result.groupby('MBR_PERS_GEN_KEY', as_index=False).first()

hp_columns = ['MBR_PERS_GEN_KEY', 'RX_ALLOWED_AMT_6M', 'RX_CNT_GENERIC_6M',
              'RX_CNT_MAIL_ORDER_6M', 'RX_CNT_MAINT_DRUG_6M',
              'RX_CNT_RHTSRCE_6M', 'RX_CNT_RX_6M', 'RX_CNT_TIER1_6M',
              'RX_CNT_TIER2_6M', 'RX_CNT_TIER3_6M', 'RX_CNT_TIER4_6M',
              'RX_CNT_UNIQ_PHARM_6M', 'RX_MBR_RESP_AMT_6M', 'RX_PAID_AMT_6M',
              'CNT_MAIN_DRUG_6M', 'MAIN_DRUG_TAG_6M', 'IND_RTSOURCE_6M',
              'RTSOURCE_ONLY_6M', 'GENERIC_ONLY_6M', 'MAINT_DRUG_ONLY_6M',
              'TS_LAST_LOGIN', 'TS_LAST_CALL', 'CNT_INQ_6M', 'CNT_CALLS_6M',
              'IND_CALLS_6M', 'IND_INQ_6M']

hp_result = hp_result[hp_columns]
################################################################################
# Join Data
df = pd.merge(df,hp_result,how='left',on='MBR_PERS_GEN_KEY')

# Rearrange columns for easier model building
df = df[[col for col in df if col not in ['MEMBER_ENROLLMENT','RX_ENROLLMENTS','RX_ENROLL']]
       + ['MEMBER_ENROLLMENT','RX_ENROLLMENTS','RX_ENROLL']]

df.head()
################################################################################
df.to_csv('pgk_clean_random_sample_data_joined.csv',index=False)

# Uncomment the code of above to create the CSV file for this cell.
# Read in features data
path = 'data/'
filename = 'pgk_clean_random_sample_data_joined.csv'
filepath = f'{path}{filename}'
print(filepath)
df = pd.read_csv(filepath,header=0)

# Convert Columns to uppercase
df.columns = df.columns.str.upper()

# Quick look at data
df.head()

# Full dataset Distn
print('ALL')
print(df.MBR_PERS_GEN_KEY.count(),'\n')
print(df.loc[:,'LEAD_TYPE'].value_counts() / df.loc[:,'LEAD_TYPE'].count()*100,'\n')
print(df.loc[:,'POPULATION_IND'].value_counts() / df.loc[:,'POPULATION_IND'].count()*100,'\n')
print(df.loc[:,'RX_ENROLL'].value_counts() / df.loc[:,'RX_ENROLL'].count()*100,'\n')

# MAPD Distn (Rough)
print('MAPD')
df_mapd = df[df.LOB2 == 'MAPD']
print(df_mapd.MBR_PERS_GEN_KEY.count(),'\n')
print(df_mapd.loc[:,'LEAD_TYPE'].value_counts() / df_mapd.loc[:,'LEAD_TYPE'].count()*100,'\n')
print(df_mapd.loc[:,'POPULATION_IND'].value_counts() / df_mapd.loc[:,'POPULATION_IND'].count()*100,'\n')
print(df_mapd.loc[:,'RX_ENROLL'].value_counts() / df_mapd.loc[:,'RX_ENROLL'].count()*100,'\n')

# PDP Distn (Rough)
df_pdp = df[df.LOB2 == 'PDP']
print('PDP')
print(df_pdp.MBR_PERS_GEN_KEY.count(),'\n')
print(df_pdp.loc[:,'LEAD_TYPE'].value_counts() / df_pdp.loc[:,'LEAD_TYPE'].count()*100,'\n')
print(df_pdp.loc[:,'POPULATION_IND'].value_counts() / df_pdp.loc[:,'POPULATION_IND'].count()*100,'\n')
print(df_pdp.loc[:,'RX_ENROLL'].value_counts() / df_pdp.loc[:,'RX_ENROLL'].count()*100,'\n')

# Numerical Features
number_features = ['MBR_PERS_GEN_KEY','LEAD_TYPE','POPULATION_IND'
                         ,'IND_MAPD'
                         ,'IND_PDP'
                         ,'NTWPERYR'
                         ,'CHVA'
                         ,'MR_M'
                         ,'RXNUM'
                         ,'RXBRAND'
                         ,'RXMAINT'
                         ,'RXADHM'
                         ,'RXSUPP'
                         ,'RXADHS'
                         ,'RXNCDRUG_A'
                         ,'RXNCDRUG_C'
                         ,'RXNCDRUG_D'
                         ,'RXNCDRUG_N'
                         ,'RXSOWRX'
                         ,'RXPURCHA_D'
                         ,'RXPURCHA_G'
                         ,'RXPURCHA_M'
                         ,'RXPURCHA_R'
                         ,'HWRXLOYL'
                         ,'TENURE_MBR_COV'
                         ,'HUM_AGE'
                         ,'RX_ALLOWED_AMT_6M'
                         ,'RX_CNT_GENERIC_6M'
                         ,'RX_CNT_MAIL_ORDER_6M'
                         ,'RX_CNT_MAINT_DRUG_6M'
                         ,'RX_CNT_RHTSRCE_6M'
                         ,'RX_CNT_RX_6M'
                         ,'RX_CNT_TIER1_6M'
                         ,'RX_CNT_TIER2_6M'
                         ,'RX_CNT_TIER3_6M'
                         ,'RX_CNT_TIER4_6M'
                         ,'RX_CNT_UNIQ_PHARM_6M'
                         ,'RX_MBR_RESP_AMT_6M'
                         ,'RX_PAID_AMT_6M'
                         ,'CNT_MAIN_DRUG_6M'
                         ,'MAIN_DRUG_TAG_6M'
                         ,'IND_RTSOURCE_6M'
                         ,'RTSOURCE_ONLY_6M'
                         ,'GENERIC_ONLY_6M'
                         ,'MAINT_DRUG_ONLY_6M'
                         ,'TS_LAST_LOGIN'
                         ,'TS_LAST_CALL'
                         ,'CNT_INQ_6M'
                         ,'CNT_CALLS_6M'
                         ,'IND_CALLS_6M'
                         ,'IND_INQ_6M'
                         ,'MONTH'
                         ,'RX_ENROLL']

num_var = df[number_features].copy()
##############################################################################
# Categorical Features for dataset
# Split the df to numbers & categorical for quick exploration of features
# member_data.select_dtypes(include=[object]).head() # df.loc[:, df.dtypes == np.float64]

category_features = ['MBR_PERS_GEN_KEY'
                        ,'GENDER'
                        ,'MABH_SEG'
                        ,'PDPBH_SEG'
                        ,'AEP_STATUS'
                        ,'PRODUCT2019'
                        ,'PRODUCT2018'
                        ,'PLANTYPE2019'
                        ,'PLANTYPE2018'
                        ,'N2NCY'
                        ,'CHANPR1']
cat_var = df[category_features].copy()
##############################################################################
#############################
# Clean Categorical Variables
#############################
# Create the Dummy Variables: If doing logistic, be sure to n-1 for dummy variables

# IND_FEMALE
cat_var['IND_FEMALE'] = cat_var.loc[:,'GENDER'].replace(['F'], 1)
cat_var['IND_FEMALE'] = cat_var.loc[:,'IND_FEMALE'].replace(['M'], 0)

# IND_MALE
cat_var['IND_MALE'] = cat_var.loc[:,'GENDER'].replace(['M'], 1)
cat_var['IND_MALE'] = cat_var.loc[:,'IND_MALE'].replace(['F'], 0)

# MAPD & PDP BEHAVIORAL SEGMENTATION
# Replaces None/Nan with Other and Nulls
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['C1'], 'Support-Seeking Participators')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['C3','H3'], 'Health Services Maximizers')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H1','C2'], 'Self-Engaged Optimists')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H6','H7','C6'], 'Skeptical Control-Seekers')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H2','C4'], 'Auto-pilot Participators')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H5','C5'], 'Simplicity-Seeking Followers')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H8','C7'], 'Overwhelmed and Reluctant Reactors')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H4'], 'Healthy Self-Sustainers')

cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P1'], 'Proactive Maximizer')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P2'], 'Reactive Engager')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P3'], 'Frugal Participator')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P4'], 'Complacent Follower')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P5'], 'Healthy Independent')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P6'], 'Overwhelmed & Detached')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P7'], 'Agreeably Disengaged')

cat_var['MABH_SEG'] = cat_var.MABH_SEG.fillna('NO RECORD')
cat_var['PDPBH_SEG'] = cat_var.PDPBH_SEG.fillna('NO RECORD')

# cat_var['IND_ENGAGED'] = cat_var.loc[:,'BH_SEG'].replace(['Support-Seeking Participators'
#                                                           ,'Health Services Maximizers'
#                                                           ,'Self-Engaged Optimists'
#                                                           ,'Auto-pilot Participators'
#                                                           ,'Frugal Participator'
#                                                           ,'Proactive Maximizer'
#                                                           ,'Reactive Engager'], 1)

# cat_var['IND_NO_BH_SEG'] = cat_var.loc[:,'BH_SEG'].replace(['NO RECORD'], 1)

# MAPD beh seg
mapd_bseg_cat = pd.get_dummies(cat_var[['MABH_SEG']])
mapd_bseg_cat['MBR_PERS_GEN_KEY'] = cat_var.loc[:,'MBR_PERS_GEN_KEY']

# PDP beh seg
pdp_bseg_cat = pd.get_dummies(cat_var[['PDPBH_SEG']])
pdp_bseg_cat['MBR_PERS_GEN_KEY'] = cat_var.loc[:,'MBR_PERS_GEN_KEY']

# New Member
cat_var['IND_NEW'] = cat_var.loc[:,'AEP_STATUS'].replace(['New Sale'], 1)
cat_var['IND_NEW'] = cat_var.loc[:,'IND_NEW'].replace(['Stayed','Term'], 0)

# Renewal Member
cat_var['IND_RENEW'] = cat_var.loc[:,'AEP_STATUS'].replace(['Stayed'], 1)
cat_var['IND_RENEW'] = cat_var.loc[:,'IND_NEW'].replace(['New Sale','Term'], 0)

# Plan Type
plantype_cat = pd.get_dummies(cat_var[['PLANTYPE2019']])
plantype_cat['MBR_PERS_GEN_KEY'] = cat_var.loc[:,'MBR_PERS_GEN_KEY']

# Nielsen County Size
nielsen_cat = pd.get_dummies(cat_var[['N2NCY']])
nielsen_cat['MBR_PERS_GEN_KEY'] = cat_var.loc[:,'MBR_PERS_GEN_KEY']

# Channel Preference
chanpref_cat = pd.get_dummies(cat_var[['CHANPR1']])
chanpref_cat['MBR_PERS_GEN_KEY'] = cat_var.loc[:,'MBR_PERS_GEN_KEY']

# Combine Categorical Features
cat_var_sel = ['MBR_PERS_GEN_KEY'
              ,'IND_FEMALE'
              ,'IND_MALE'
              ,'MABH_SEG'
              ,'PDPBH_SEG'
              ,'IND_NEW'
              ,'IND_RENEW']
cat_var_subset = cat_var[cat_var_sel]
cat_var_subset = pd.merge(cat_var_subset,mapd_bseg_cat,how='left',on='MBR_PERS_GEN_KEY')
cat_var_subset = pd.merge(cat_var_subset,pdp_bseg_cat,how='left',on='MBR_PERS_GEN_KEY')
cat_var_subset = pd.merge(cat_var_subset,plantype_cat,how='left',on='MBR_PERS_GEN_KEY')
cat_var_subset = pd.merge(cat_var_subset,nielsen_cat,how='left',on='MBR_PERS_GEN_KEY')
cat_var_subset = pd.merge(cat_var_subset,chanpref_cat,how='left',on='MBR_PERS_GEN_KEY')
cat_var_subset.head()
########################################################################################
# Select final columns
cat_var_fin = [
    'MBR_PERS_GEN_KEY'
    ,'IND_FEMALE','IND_MALE'
    ,'IND_NEW','IND_RENEW'
    ,'MABH_SEG_Auto-pilot Participators','MABH_SEG_Health Services Maximizers','MABH_SEG_Healthy Self-Sustainers','MABH_SEG_NO RECORD','MABH_SEG_Overwhelmed and Reluctant Reactors','MABH_SEG_Self-Engaged Optimists','MABH_SEG_Simplicity-Seeking Followers','MABH_SEG_Skeptical Control-Seekers','MABH_SEG_Support-Seeking Participators'
    ,'PDPBH_SEG_Agreeably Disengaged','PDPBH_SEG_Complacent Follower','PDPBH_SEG_Frugal Participator', 'PDPBH_SEG_Healthy Independent','PDPBH_SEG_NO RECORD','PDPBH_SEG_Overwhelmed & Detached','PDPBH_SEG_Proactive Maximizer', 'PDPBH_SEG_Reactive Engager'
    ,'PLANTYPE2019_ENH', 'PLANTYPE2019_HMO', 'PLANTYPE2019_LPPO','PLANTYPE2019_NWM', 'PLANTYPE2019_PFFS', 'PLANTYPE2019_PRF','PLANTYPE2019_RPPO'
    ,'N2NCY_A', 'N2NCY_B', 'N2NCY_C', 'N2NCY_D'
    ,'CHANPR1_C', 'CHANPR1_E', 'CHANPR1_M', 'CHANPR1_P', 'CHANPR1_T','CHANPR1_W']

cat_var = cat_var_subset[cat_var_fin]
########################################################################################
# Join Categorical & Numerical Variables
df = pd.merge(num_var,cat_var,how='left',on='MBR_PERS_GEN_KEY')


# Rearrange columns for easier model building
df = df[[col for col in df if col not in ['MONTH','RX_ENROLL']]
       + ['MONTH','RX_ENROLL']]
########################################################################################
df_train = df
mapd_train = df_train[df_train.IND_MAPD == 1].copy()
pdp_train = df_train[df_train.IND_PDP == 1].copy()
print(mapd_train.MBR_PERS_GEN_KEY.count())
print(pdp_train.MBR_PERS_GEN_KEY.count())

# MAPD MODEL - IMPUTATION & FEATURE ENGINEERING

# Imputate CAT values
mapd_train['IND_NEW'].fillna(mapd_train.IND_NEW.max(),inplace = True) # New Member
mapd_train['TENURE_MBR_COV'].fillna(mapd_train.TENURE_MBR_COV.mean(),inplace = True) # New Member
mapd_train['HUM_AGE'].fillna(mapd_train.HUM_AGE.mean(),inplace = True) # New Member

# Imputate AMLK values
mapd_train['NTWPERYR'].fillna(mapd_train.NTWPERYR.mean(),inplace = True) # Net Worth Per Year
mapd_train['CHVA'].fillna(mapd_train.CHVA.mean(),inplace = True) # Census Median Home Value AMLK
mapd_train['MR_M'].fillna(mapd_train.MR_M.max(),inplace = True) # Mail Order Multiple **Maybe use mean?
mapd_train['RXNUM'].fillna(mapd_train.RXNUM.mean(),inplace = True) # # of Meds (modeled)
mapd_train['RXBRAND'].fillna(mapd_train.RXBRAND.mean(),inplace = True) # Prefer Brand Meds (0 more likely)
mapd_train['RXMAINT'].fillna(mapd_train.RXMAINT.mean(),inplace = True) # Use Maint Med (0 more likely)
mapd_train['RXADHM'].fillna(mapd_train.RXADHM.mean(),inplace = True) # Adh to Maint Med (0 more likely)
mapd_train['RXSUPP'].fillna(mapd_train.RXSUPP.mean(),inplace = True) # Use Vit/Sup (0 more likely)
mapd_train['RXADHS'].fillna(mapd_train.RXADHS.mean(),inplace = True) # Adh to Vit/Sup (0 more likely)
mapd_train['RXNCDRUG_A'].fillna(mapd_train.RXNCDRUG_A.max(),inplace = True) # KBM Non-Comp Prefer Alternative **Maybe use mean?
mapd_train['RXNCDRUG_C'].fillna(mapd_train.RXNCDRUG_C.max(),inplace = True) # KBM Non-Comp Cost of Med
mapd_train['RXNCDRUG_D'].fillna(mapd_train.RXNCDRUG_D.max(),inplace = True) # KBM Non-Comp Dislike Med
mapd_train['RXNCDRUG_N'].fillna(mapd_train.RXNCDRUG_N.max(),inplace = True) # KBM Non-Compilance Just Dont
mapd_train['RXSOWRX'].fillna(mapd_train.RXSOWRX.mean(),inplace = True) # RX - Share of Wallet (0 loyal)
mapd_train['RXPURCHA_D'].fillna(mapd_train.RXPURCHA_D.max(),inplace = True) # KBM Purchase  Drug Store
mapd_train['RXPURCHA_G'].fillna(mapd_train.RXPURCHA_G.max(),inplace = True) # KBM Purchase Grocery Store
mapd_train['RXPURCHA_M'].fillna(mapd_train.RXPURCHA_M.max(),inplace = True) # KBM Purchase  Mail Order
mapd_train['RXPURCHA_R'].fillna(mapd_train.RXPURCHA_R.max(),inplace = True) # KBM Purchase Retail Store
mapd_train['HWRXLOYL'].fillna(mapd_train.HWRXLOYL.mean(),inplace = True) # Rx Pharmacy Loyalty

print('Number of Nulls: ',mapd_train.size - mapd_train.count().sum())
# Fill remaining with 0s
mapd_train = mapd_train.fillna(0)
print('Number of Nulls: ',mapd_train.size - mapd_train.count().sum())
#################################################################################################
# Number of Available scripts to Convert
mapd_train['RX_CNTRX_HPRX'] = mapd_train.RX_CNT_RX_6M - mapd_train.RX_CNT_RHTSRCE_6M

# Indicator for Rx Conv
mapd_train.loc[mapd_train.RX_CNTRX_HPRX > 0, 'RX_SAVE_IND'] = 1
mapd_train['RX_SAVE_IND'] = mapd_train.loc[:,'RX_SAVE_IND'].replace([None,'nan'], 0)
#################################################################################################
# Engaged Members
engaged_col = ['MABH_SEG_Support-Seeking Participators'
               ,'MABH_SEG_Health Services Maximizers'
               ,'MABH_SEG_Self-Engaged Optimists'
               ,'MABH_SEG_Auto-pilot Participators'
#                ,'PDPBH_SEG_Frugal Participator'
#                ,'PDPBH_SEG_Proactive Maximizer'
#                ,'PDPBH_SEG_Reactive Engager'
              ]
mapd_train['ENGAGED_MEMBERS'] = mapd_train[engaged_col].any(axis=1)
mapd_train['ENGAGED_MEMBERS'] = mapd_train.loc[:,'ENGAGED_MEMBERS'].replace([True], 1)
mapd_train['ENGAGED_MEMBERS'] = mapd_train.loc[:,'ENGAGED_MEMBERS'].replace([False], 0)

# Unengaged Members
unengaged_col = ['MABH_SEG_Healthy Self-Sustainers',
               'MABH_SEG_Overwhelmed and Reluctant Reactors',
               'MABH_SEG_Simplicity-Seeking Followers',
               'MABH_SEG_Skeptical Control-Seekers',
#                'PDPBH_SEG_Agreeably Disengaged',
#                'PDPBH_SEG_Complacent Follower',
#                'PDPBH_SEG_Healthy Independent',
#                'PDPBH_SEG_Overwhelmed & Detached'
                ]

mapd_train['UNENGAGED_MEMBERS'] = mapd_train[unengaged_col].any(axis=1)
mapd_train['UNENGAGED_MEMBERS'] = mapd_train.loc[:,'UNENGAGED_MEMBERS'].replace([True], 1)
mapd_train['UNENGAGED_MEMBERS'] = mapd_train.loc[:,'UNENGAGED_MEMBERS'].replace([False], 0)

# No Behavioral Segments
noseg_col = ['MABH_SEG_NO RECORD'
#              ,'PDPBH_SEG_NO RECORD'
            ]
mapd_train['NO_BEHSEG_MEMBERS'] = mapd_train[noseg_col].all(axis=1)
mapd_train['NO_BEHSEG_MEMBERS'] = mapd_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([True], 1)
mapd_train['NO_BEHSEG_MEMBERS'] = mapd_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([False], 0)
#################################################################################################
mapd_train.loc[mapd_train.NTWPERYR < 0, 'NTWPERYR'] = 0
mapd_train.loc[mapd_train.TS_LAST_LOGIN < 0, 'TS_LAST_LOGIN'] = 0
mapd_train.loc[mapd_train.TS_LAST_CALL < 0, 'TS_LAST_CALL'] = 0
#################################################################################################
# # Optional Step: log transform the features to help combat the skew of
# # certain features to create a normal distribution.
# mapd_train['NTWPERYR'] = np.log10(mapd_train['NTWPERYR']+1)
# mapd_train['CHVA'] = np.log10(mapd_train['CHVA']+1)
# mapd_train['RXNUM'] = np.log10(mapd_train['RXNUM']+1)
# mapd_train['HWRXLOYL'] = np.log10(mapd_train['HWRXLOYL']+1)
# mapd_train['TENURE_MBR_COV'] = np.log10(mapd_train['TENURE_MBR_COV']+1)
# mapd_train['HUM_AGE'] = np.log10(mapd_train['HUM_AGE']+1)
# mapd_train['RX_ALLOWED_AMT_6M'] = np.log10(mapd_train['RX_ALLOWED_AMT_6M']+1)
# mapd_train['RX_CNT_MAINT_DRUG_6M'] = np.log10(mapd_train['RX_CNT_MAINT_DRUG_6M']+1)
# mapd_train['RX_CNT_RX_6M'] = np.log10(mapd_train['RX_CNT_RX_6M']+1)
# mapd_train['RX_CNT_TIER1_6M'] = np.log10(mapd_train['RX_CNT_TIER1_6M']+1)
# mapd_train['RX_CNT_TIER2_6M'] = np.log10(mapd_train['RX_CNT_TIER2_6M']+1)
# mapd_train['RX_MBR_RESP_AMT_6M'] = np.log10(mapd_train['RX_MBR_RESP_AMT_6M']+1)
# mapd_train['RX_PAID_AMT_6M'] = np.log10(mapd_train['RX_PAID_AMT_6M']+1)
# mapd_train['TS_LAST_LOGIN'] = np.log10(mapd_train['TS_LAST_LOGIN']+1)
# mapd_train['TS_LAST_CALL'] = np.log10(mapd_train['TS_LAST_CALL']+1)
# mapd_train['RX_CNTRX_HPRX'] = np.log10(mapd_train['RX_CNTRX_HPRX']+1)
# mapd_train = mapd_train.fillna(0)
#################################################################################################
# Rearrange columns for easier model building
mapd_train = mapd_train[[col for col in mapd_train if col not in ['MONTH','RX_ENROLL']]
       + ['MONTH','RX_ENROLL']]
mapd_train.columns

# MAPD MODEL TRAINING

df = mapd_train.copy()
final_features = ['MBR_PERS_GEN_KEY',
                  'NTWPERYR', 'CHVA',
                  'RXNUM','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE',
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAINT_DRUG_6M','RX_CNT_RX_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'RX_CNTRX_HPRX',
                  'ENGAGED_MEMBERS',
                  'UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
                  'RX_ENROLL'
                 ]
df = df[final_features]

# Subset to features used for model
seed = 1990
X = df.iloc[:,:-1].values
y = df.iloc[:,-1].values
###########################################################
# Split to training & test
X_, X_test, y_, y_test = train_test_split(X, y, test_size = 0.2,random_state = seed)
X_train, X_val, y_train, y_val = train_test_split(X_, y_, test_size = 0.2,random_state = seed)


# Class Distribution for the training and test set
print('TRAIN')
print(np.unique(y_train))
print(np.bincount(y_train))
print('PCT',(y_train==1).sum()/(y_train.shape[0])*100)

print('\n','VAL')
print(np.unique(y_val))
print(np.bincount(y_val))
print('PCT',(y_val==1).sum()/(y_val.shape[0])*100)

print('\n','TEST')
print(np.unique(y_test))
print(np.bincount(y_test))
print('PCT',(y_test==1).sum()/(y_test.shape[0])*100)
###########################################################
# Downsample dataset
# Before Resampling
print('Number of class 0 samples before:',X_train[y_train == 0].shape[0])

# Downsample dataset
X_sampled, y_sampled = resample(X_train[y_train == 0], y_train[y_train == 0]
                                    ,n_samples = X_train[y_train == 1].shape[0]
                                    ,replace = True, random_state=seed)

# After Resampling
print('Number of class 0 samples after:',X_sampled.shape[0])
###########################################################
# Balanced Dataset
X_train = np.vstack((X_train[y_train == 1], X_sampled))
y_train = np.hstack((y_train[y_train == 1], y_sampled))

# Confirm Downsample
zero_ = np.ones(y_train.shape[0]) # Create 0 array
print('class ditrubution: ',np.mean(zero_ == y_train) * 100) # Class 0

# Class Distribution for the training and test set
print('TRAIN')
print(np.unique(y_train))
print(np.bincount(y_train))
print('PCT',(y_train==1).sum()/(y_train.shape[0])*100)

print('\n','VALIDATION')
print(np.unique(y_val))
print(np.bincount(y_val))
print('PCT',(y_val==1).sum()/(y_val.shape[0])*100)
###########################################################
# Remove PGK from model
train = X_train
val = X_val
# test = X_test
X_train = X_train[:,1:]
X_val = X_val[:,1:]
# X_test = X_test[:,1:]
print(X_train.shape)
print(X_val.shape)
#print(X_test.shape)
###########################################################
# Fit Random Forest Classifier to Training Data
classifier = RandomForestClassifier(n_estimators=500,
                                    max_features = 'sqrt', # sqrt(num_of_features)
                                    criterion ='entropy', #gini samples per leaf = 30
#                                     class_weight = 'balanced',
                                    random_state=seed)

classifier.fit(X_train,y_train)

# Probabilities
y_probas = classifier.predict_proba(X_val[:, :])
# classifier.predict(X_test_std[:10, :]) # Predict on n records
# classifier.predict(X_test_std[0, :].reshape(1,-1)) # Predict on 1 record

# Predict on Validation Set
y_pred = classifier.predict(X_val)

# Missclassified
print('Number of Misclassified: ',(y_val != y_pred).sum())

# Score on Validation set
print('Validation set score: ',classifier.score(X_val,y_val))
###########################################################
# Confusion Matrix
cm = confusion_matrix(y_val, y_pred)
print('[[True Negative, False Positive]')
print('[False Negative, True Positive]]')
print(cm)
###########################################################
# Recall (True Positive / Positive Cases (TP & FN)): True Positive Rate
# print('TRUE POSITIVE RATE (Recall or Sensitivity) =','TP / (TP+FN)')
# print('Accuracy: %.3f' % accuracy_score(y_true=y_test, y_pred=y_pred))
print('Recall: %.3f' % recall_score(y_true=y_val, y_pred=y_pred))
print('Precision: %.3f' % precision_score(y_true=y_val, y_pred=y_pred))

# False Postive Rate and True Positive Rate for all thresholds
fpr, tpr, threshold = roc_curve(y_val, y_probas[:,1])
roc_auc = auc(fpr,tpr)
roc_auc
print('AUC: %.3f' % roc_auc)

# f1_score(y_val, y_pred)
# classifier.classes_
print('Brier Score: %.4f' % brier_score_loss(y_val, y_probas[:,1]))

# Test Set Score
# Data Prep
test = X_test
X_test = X_test[:,1:]

# Probabilities
y_probas = classifier.predict_proba(X_test[:, :])
# classifier.predict(X_test_std[:10, :]) # Predict on n records
# classifier.predict(X_test_std[0, :].reshape(1,-1)) # Predict on 1 record

# Predict on Test Set
y_pred = classifier.predict(X_test)

# Missclassified
print('Number of Misclassified: ',(y_test != y_pred).sum())

# Score on Test set
print('Test set score: ',classifier.score(X_test,y_test))

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
print('[[True Negative, False Positive]')
print('[False Negative, True Positive]]')
print(cm)

# Recall (True Positive / Positive Cases (TP & FN)): True Positive Rate
# print('TRUE POSITIVE RATE (Recall or Sensitivity) =','TP / (TP+FN)')
# print('Accuracy: %.3f' % accuracy_score(y_true=y_test, y_pred=y_pred))
print('Recall: %.3f' % recall_score(y_true=y_test, y_pred=y_pred))
print('Precision: %.3f' % precision_score(y_true=y_test, y_pred=y_pred))

# False Postive Rate and True Positive Rate for all thresholds
fpr, tpr, threshold = roc_curve(y_test, y_probas[:,1])
roc_auc = auc(fpr,tpr)
roc_auc
print('AUC: %.3f' % roc_auc)
print('Brier Score: %.4f' % brier_score_loss(y_test, y_probas[:,1]))

# Pickle model
filename = 'rxe_rf_clf_mapd_random_sample.sav'
pickle.dump(classifier, open(filename, 'wb'))


# Decile Cutoffs

colnames = ['MBR_PERS_GEN_KEY',
                  'NTWPERYR', 'CHVA',
                  'RXNUM','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE',
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAINT_DRUG_6M','RX_CNT_RX_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'RX_CNTRX_HPRX',
                  'ENGAGED_MEMBERS','UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
                 ]

results = pd.DataFrame(test,columns = colnames)
results['MBR_PERS_GEN_KEY'] = test[:,0].astype(np.int64)
results['y_actual'] = y_test
results['y_probas'] = y_probas[:,1]
results['y_preds'] = y_pred
results.head(5)
#################################################################################
# Results sorted by Probability Predicted
results['decile']= pd.qcut(results.y_probas, 10
       ,labels=[9,8,7,6,5,4,3,2,1,0])
results_sort = results.sort_values(by='y_probas',ascending=False).reset_index()
results_sort = results_sort.drop(['index'], axis=1)
results_sort.head(5)
#################################################################################
# Decile Cut offs
for decile in range(9):
    print('-',decile,end=")")
    print('\033[1m'+ 'Decile ' + str(decile) +'\033[0m',end=": ")
    print(results_sort[results_sort.decile == decile].y_probas.min())



# PDP MODEL - IMPUTATION & FEATURE ENGINEERING

# Imputate CAT values
pdp_train['IND_NEW'].fillna(pdp_train.IND_NEW.max(),inplace = True) # New Member
pdp_train['TENURE_MBR_COV'].fillna(pdp_train.TENURE_MBR_COV.mean(),inplace = True) # New Member
pdp_train['HUM_AGE'].fillna(pdp_train.HUM_AGE.mean(),inplace = True) # New Member

# Imputate AMLK values
pdp_train['NTWPERYR'].fillna(pdp_train.NTWPERYR.mean(),inplace = True) # Net Worth Per Year
pdp_train['CHVA'].fillna(pdp_train.CHVA.mean(),inplace = True) # Census Median Home Value AMLK
pdp_train['MR_M'].fillna(pdp_train.MR_M.max(),inplace = True) # Mail Order Multiple **Maybe use mean?
pdp_train['RXNUM'].fillna(pdp_train.RXNUM.mean(),inplace = True) # # of Meds (modeled)
pdp_train['RXBRAND'].fillna(pdp_train.RXBRAND.mean(),inplace = True) # Prefer Brand Meds (0 more likely)
pdp_train['RXMAINT'].fillna(pdp_train.RXMAINT.mean(),inplace = True) # Use Maint Med (0 more likely)
pdp_train['RXADHM'].fillna(pdp_train.RXADHM.mean(),inplace = True) # Adh to Maint Med (0 more likely)
pdp_train['RXSUPP'].fillna(pdp_train.RXSUPP.mean(),inplace = True) # Use Vit/Sup (0 more likely)
pdp_train['RXADHS'].fillna(pdp_train.RXADHS.mean(),inplace = True) # Adh to Vit/Sup (0 more likely)
pdp_train['RXNCDRUG_A'].fillna(pdp_train.RXNCDRUG_A.max(),inplace = True) # KBM Non-Comp Prefer Alternative **Maybe use mean?
pdp_train['RXNCDRUG_C'].fillna(pdp_train.RXNCDRUG_C.max(),inplace = True) # KBM Non-Comp Cost of Med
pdp_train['RXNCDRUG_D'].fillna(pdp_train.RXNCDRUG_D.max(),inplace = True) # KBM Non-Comp Dislike Med
pdp_train['RXNCDRUG_N'].fillna(pdp_train.RXNCDRUG_N.max(),inplace = True) # KBM Non-Compilance Just Dont
pdp_train['RXSOWRX'].fillna(pdp_train.RXSOWRX.mean(),inplace = True) # RX - Share of Wallet (0 loyal)
pdp_train['RXPURCHA_D'].fillna(pdp_train.RXPURCHA_D.max(),inplace = True) # KBM Purchase  Drug Store
pdp_train['RXPURCHA_G'].fillna(pdp_train.RXPURCHA_G.max(),inplace = True) # KBM Purchase Grocery Store
pdp_train['RXPURCHA_M'].fillna(pdp_train.RXPURCHA_M.max(),inplace = True) # KBM Purchase  Mail Order
pdp_train['RXPURCHA_R'].fillna(pdp_train.RXPURCHA_R.max(),inplace = True) # KBM Purchase Retail Store
pdp_train['HWRXLOYL'].fillna(pdp_train.HWRXLOYL.mean(),inplace = True) # Rx Pharmacy Loyalty

print('Number of Nulls: ',pdp_train.size - pdp_train.count().sum())
# Fill remaining with 0s
pdp_train = pdp_train.fillna(0)
print('Number of Nulls: ',pdp_train.size - pdp_train.count().sum())
###################################################################################################
# Number of Available scripts to Convert
pdp_train['RX_CNTRX_HPRX'] = pdp_train.RX_CNT_RX_6M - pdp_train.RX_CNT_RHTSRCE_6M

# Indicator for Rx Conv
pdp_train.loc[pdp_train.RX_CNTRX_HPRX > 0, 'RX_SAVE_IND'] = 1
pdp_train['RX_SAVE_IND'] = pdp_train.loc[:,'RX_SAVE_IND'].replace([None,'nan'], 0)
####################################################################################################
# Engaged Members
engaged_col = ['PDPBH_SEG_Frugal Participator'
               ,'PDPBH_SEG_Proactive Maximizer'
               ,'PDPBH_SEG_Reactive Engager'
              ]
pdp_train['ENGAGED_MEMBERS'] = pdp_train[engaged_col].any(axis=1)
pdp_train['ENGAGED_MEMBERS'] = pdp_train.loc[:,'ENGAGED_MEMBERS'].replace([True], 1)
pdp_train['ENGAGED_MEMBERS'] = pdp_train.loc[:,'ENGAGED_MEMBERS'].replace([False], 0)

# Unengaged Members
unengaged_col = ['PDPBH_SEG_Agreeably Disengaged',
               'PDPBH_SEG_Complacent Follower',
               'PDPBH_SEG_Healthy Independent',
               'PDPBH_SEG_Overwhelmed & Detached'
                ]

pdp_train['UNENGAGED_MEMBERS'] = pdp_train[unengaged_col].any(axis=1)
pdp_train['UNENGAGED_MEMBERS'] = pdp_train.loc[:,'UNENGAGED_MEMBERS'].replace([True], 1)
pdp_train['UNENGAGED_MEMBERS'] = pdp_train.loc[:,'UNENGAGED_MEMBERS'].replace([False], 0)

# No Behavioral Segments
noseg_col = ['PDPBH_SEG_NO RECORD']
pdp_train['NO_BEHSEG_MEMBERS'] = pdp_train[noseg_col].all(axis=1)
pdp_train['NO_BEHSEG_MEMBERS'] = pdp_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([True], 1)
pdp_train['NO_BEHSEG_MEMBERS'] = pdp_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([False], 0)
################################################################################################
pdp_train.loc[pdp_train.NTWPERYR < 0, 'NTWPERYR'] = 0
pdp_train.loc[pdp_train.TS_LAST_LOGIN < 0, 'TS_LAST_LOGIN'] = 0
pdp_train.loc[pdp_train.TS_LAST_CALL < 0, 'TS_LAST_CALL'] = 0

# # Optional Step: log transform the features to help combat the skew of
# # certain features to create a normal distribution.
# # pdp_train['NTWPERYR'] = np.log10(pdp_train['NTWPERYR']+1)
# # pdp_train['CHVA'] = np.log10(pdp_train['CHVA']+1)
# # pdp_train['TENURE_MBR_COV'] = np.log10(pdp_train['TENURE_MBR_COV']+1)
# # pdp_train['HUM_AGE'] = np.log10(pdp_train['HUM_AGE']+1)
# pdp_train['RX_ALLOWED_AMT_6M'] = np.log10(pdp_train['RX_ALLOWED_AMT_6M']+1)
# pdp_train['RX_MBR_RESP_AMT_6M'] = np.log10(pdp_train['RX_MBR_RESP_AMT_6M']+1)
# pdp_train['RX_PAID_AMT_6M'] = np.log10(pdp_train['RX_PAID_AMT_6M']+1)
# # pdp_train['TS_LAST_LOGIN'] = np.log10(pdp_train['TS_LAST_LOGIN']+1)
# # pdp_train['TS_LAST_CALL'] = np.log10(pdp_train['TS_LAST_CALL']+1)
# pdp_train['RX_CNTRX_HPRX'] = np.log10(pdp_train['RX_CNTRX_HPRX']+1)
# pdp_train = pdp_train.fillna(0)
###############################################################################################
# Rearrange columns for easier model building
pdp_train = pdp_train[[col for col in pdp_train if col not in ['MONTH','RX_ENROLL']]
       + ['MONTH','RX_ENROLL']]
pdp_train.columns

# PDP MODEL TRAINING

df = pdp_train.copy()
final_features = ['MBR_PERS_GEN_KEY',
                  'NTWPERYR', 'CHVA',
                  'RXBRAND','RXSOWRX','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE',
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAIL_ORDER_6M', 'RX_CNT_MAINT_DRUG_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'RX_CNTRX_HPRX',
                  'ENGAGED_MEMBERS','UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
                  'RX_ENROLL'
                 ]
df = df[final_features]

# Subset to features used for model
seed = 1990
X = df.iloc[:,:-1].values
y = df.iloc[:,-1].values
###########################################################
# Split to training & test
X_, X_test, y_, y_test = train_test_split(X, y, test_size = 0.15,random_state = seed)
X_train, X_val, y_train, y_val = train_test_split(X_, y_, test_size = 0.15,random_state = seed)


# Class Distribution for the training and test set
print('TRAIN')
print(np.unique(y_train))
print(np.bincount(y_train))
print('PCT',(y_train==1).sum()/(y_train.shape[0])*100)

print('\n','VAL')
print(np.unique(y_val))
print(np.bincount(y_val))
print('PCT',(y_val==1).sum()/(y_val.shape[0])*100)

print('\n','TEST')
print(np.unique(y_test))
print(np.bincount(y_test))
print('PCT',(y_test==1).sum()/(y_test.shape[0])*100)
###########################################################
# Downsample dataset
# Before Resampling
print('Number of class 0 samples before:',X_train[y_train == 0].shape[0])

# Downsample dataset
X_sampled, y_sampled = resample(X_train[y_train == 0], y_train[y_train == 0]
                                    ,n_samples = X_train[y_train == 1].shape[0]
                                    ,replace = True, random_state=seed)

# After Resampling
print('Number of class 0 samples after:',X_sampled.shape[0])
###########################################################
# Balanced Dataset
X_train = np.vstack((X_train[y_train == 1], X_sampled))
y_train = np.hstack((y_train[y_train == 1], y_sampled))

# Confirm Downsample
zero_ = np.ones(y_train.shape[0]) # Create 0 array
print('class ditrubution: ',np.mean(zero_ == y_train) * 100) # Class 0

# Class Distribution for the training and test set
print('TRAIN')
print(np.unique(y_train))
print(np.bincount(y_train))
print('PCT',(y_train==1).sum()/(y_train.shape[0])*100)

print('\n','VALIDATION')
print(np.unique(y_val))
print(np.bincount(y_val))
print('PCT',(y_val==1).sum()/(y_val.shape[0])*100)
###########################################################
# Remove PGK from model
train = X_train
val = X_val
# test = X_test
X_train = X_train[:,1:]
X_val = X_val[:,1:]
# X_test = X_test[:,1:]
print(X_train.shape)
print(X_val.shape)
#print(X_test.shape)
###########################################################
# Fit Random Forest Classifier to Training Data
classifier = RandomForestClassifier(n_estimators=500,
                                    max_features = 'sqrt', # sqrt(num_of_features)
                                    criterion ='entropy', #gini samples per leaf = 30
#                                     class_weight = 'balanced',
                                    random_state=seed)

classifier.fit(X_train,y_train)

# Probabilities
y_probas = classifier.predict_proba(X_val[:, :])
# classifier.predict(X_test_std[:10, :]) # Predict on n records
# classifier.predict(X_test_std[0, :].reshape(1,-1)) # Predict on 1 record

# Predict on Validation Set
y_pred = classifier.predict(X_val)

# Missclassified
print('Number of Misclassified: ',(y_val != y_pred).sum())

# Score on Validation set
print('Validation set score: ',classifier.score(X_val,y_val))
###########################################################
# Confusion Matrix
cm = confusion_matrix(y_val, y_pred)
print('[[True Negative, False Positive]')
print('[False Negative, True Positive]]')
print(cm)
###########################################################
# Recall (True Positive / Positive Cases (TP & FN)): True Positive Rate
# print('TRUE POSITIVE RATE (Recall or Sensitivity) =','TP / (TP+FN)')
# print('Accuracy: %.3f' % accuracy_score(y_true=y_test, y_pred=y_pred))
print('Recall: %.3f' % recall_score(y_true=y_val, y_pred=y_pred))
print('Precision: %.3f' % precision_score(y_true=y_val, y_pred=y_pred))

# False Postive Rate and True Positive Rate for all thresholds
fpr, tpr, threshold = roc_curve(y_val, y_probas[:,1])
roc_auc = auc(fpr,tpr)
roc_auc
print('AUC: %.3f' % roc_auc)

# f1_score(y_val, y_pred)
# classifier.classes_
print('Brier Score: %.4f' % brier_score_loss(y_val, y_probas[:,1]))

# Test Set Score
# Data Prep
test = X_test
X_test = X_test[:,1:]

# Probabilities
y_probas = classifier.predict_proba(X_test[:, :])
# classifier.predict(X_test_std[:10, :]) # Predict on n records
# classifier.predict(X_test_std[0, :].reshape(1,-1)) # Predict on 1 record

# Predict on Test Set
y_pred = classifier.predict(X_test)

# Missclassified
print('Number of Misclassified: ',(y_test != y_pred).sum())

# Score on Test set
print('Test set score: ',classifier.score(X_test,y_test))

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
print('[[True Negative, False Positive]')
print('[False Negative, True Positive]]')
print(cm)

# Recall (True Positive / Positive Cases (TP & FN)): True Positive Rate
# print('TRUE POSITIVE RATE (Recall or Sensitivity) =','TP / (TP+FN)')
# print('Accuracy: %.3f' % accuracy_score(y_true=y_test, y_pred=y_pred))
print('Recall: %.3f' % recall_score(y_true=y_test, y_pred=y_pred))
print('Precision: %.3f' % precision_score(y_true=y_test, y_pred=y_pred))

# False Postive Rate and True Positive Rate for all thresholds
fpr, tpr, threshold = roc_curve(y_test, y_probas[:,1])
roc_auc = auc(fpr,tpr)
roc_auc
print('AUC: %.3f' % roc_auc)
print('Brier Score: %.4f' % brier_score_loss(y_val, y_probas[:,1]))

# Pickle model
filename = 'rxe_rf_clf_pdp_random_sample.sav'
pickle.dump(classifier, open(filename, 'wb'))


# Decile Cutoffs

colnames = ['MBR_PERS_GEN_KEY',
                  'NTWPERYR', 'CHVA',
                  'RXBRAND','RXSOWRX','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE',
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAIL_ORDER_6M', 'RX_CNT_MAINT_DRUG_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'RX_CNTRX_HPRX',
                  'ENGAGED_MEMBERS','UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
                 ]

results = pd.DataFrame(test,columns = colnames)
results['MBR_PERS_GEN_KEY'] = test[:,0].astype(np.int64)
results['y_actual'] = y_test
results['y_probas'] = y_probas[:,1]
results['y_preds'] = y_pred
results.head(5)
#################################################################################
# Results sorted by Probability Predicted
results['decile']= pd.qcut(results.y_probas, 10
       ,labels=[9,8,7,6,5,4,3,2,1,0])
results_sort = results.sort_values(by='y_probas',ascending=False).reset_index()
results_sort = results_sort.drop(['index'], axis=1)
results_sort.head(5)
#################################################################################
# Decile Cut offs
for decile in range(9):
    print('-',decile,end=")")
    print('\033[1m'+ 'Decile ' + str(decile) +'\033[0m',end=": ")
    print(results_sort[results_sort.decile == decile].y_probas.min())

# Scoring Code: Data Prep

SAS Code done in SAS instead of Python to utilize batch jobs to run overnight to bring in the different features.
- See file "get_model_data"

# Scoring Code: PreProcessing

# System Environment
import sys; print(sys.executable); print(sys.version)

# Libraries
import pandas as pd ; print("Pandas Version:",pd.__version__)
import numpy as np ; print("NumPy Version:",np.__version__)
import pyreadstat
import pickle

# # Import dataset to be scored
# path = ''
# filename = 'DATA_TO_BE_SCORED.sas7bdat'
# filepath = f'{path}{filename}'
# df, meta = pyreadstat.read_sas7bdat(filepath)

# # Change all Columns to uppercase
# df.columns = df.columns.str.upper()

# # Make PGK the index column
# df.set_index('MBR_PERS_GEN_KEY', inplace=True)
#################################################################################
# Uncomment code above this if SAS dataset
# Adhoc Scoring
# Import dataset to be scored
path = ''
filename = 'rxe_eda_retrain_apr.csv'
filepath = f'{path}{filename}'
prod_data1 = pd.read_csv(filepath, header=0)

# Change all Columns to uppercase
prod_data1.columns = prod_data1.columns.str.upper()
##################################################################################
# Quick & Dirty Collapse data for duplications
prod_data1 = prod_data1.sort_values(by=['IND_MAPD','IND_PDP'],ascending=False)
prod_data1 = prod_data1.groupby('MBR_PERS_GEN_KEY', as_index=False).first()
prod_data1.MBR_PERS_GEN_KEY.value_counts()
##################################################################################
# Features from SAS Dataset
prod_features = ['MBR_PERS_GEN_KEY','IND_MAPD','IND_PDP',
                  'NTWPERYR', 'CHVA',
                  'RXNUM','RXBRAND','RXSOWRX','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE',
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAIL_ORDER_6M',
                  'RX_CNT_MAINT_DRUG_6M','RX_CNT_RHTSRCE_6M','RX_CNT_RX_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'MABH_SEG','PDPBH_SEG'
                 ]
df = prod_data1[prod_features]

# Numerical Features
number_features = ['MBR_PERS_GEN_KEY'
                         ,'IND_MAPD'
                         ,'IND_PDP'
                         ,'NTWPERYR'
                         ,'CHVA'
                         ,'RXNUM'
                         ,'RXBRAND'
                         ,'RXSOWRX'
                         ,'HWRXLOYL'
                         ,'TENURE_MBR_COV'
                         ,'HUM_AGE'
                         ,'RX_ALLOWED_AMT_6M'
                         ,'RX_CNT_MAIL_ORDER_6M'
                         ,'RX_CNT_MAINT_DRUG_6M'
                         ,'RX_CNT_RHTSRCE_6M'
                         ,'RX_CNT_RX_6M'
                         ,'RX_CNT_TIER1_6M'
                         ,'RX_CNT_TIER2_6M'
                         ,'RX_MBR_RESP_AMT_6M'
                         ,'RX_PAID_AMT_6M'
                         ,'TS_LAST_LOGIN'
                         ,'TS_LAST_CALL'
                  ]

num_var = df[number_features].copy()
####################################################################################
# Categorical Features for dataset
# Split the df to numbers & categorical for quick exploration of features
# member_data.select_dtypes(include=[object]).head() # df.loc[:, df.dtypes == np.float64]

category_features = ['MBR_PERS_GEN_KEY'
                        ,'MABH_SEG'
                        ,'PDPBH_SEG'
                    ]
cat_var = df[category_features].copy()
####################################################################################
#############################
# Clean Categorical Variables
#############################
# Create the Dummy Variables: If doing logistic, be sure to n-1 for dummy variables
# MAPD & PDP BEHAVIORAL SEGMENTATION
# Replaces None/Nan with Other and Nulls
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['C1'], 'Support-Seeking Participators')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['C3','H3'], 'Health Services Maximizers')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H1','C2'], 'Self-Engaged Optimists')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H6','H7','C6'], 'Skeptical Control-Seekers')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H2','C4'], 'Auto-pilot Participators')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H5','C5'], 'Simplicity-Seeking Followers')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H8','C7'], 'Overwhelmed and Reluctant Reactors')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H4'], 'Healthy Self-Sustainers')

cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P1'], 'Proactive Maximizer')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P2'], 'Reactive Engager')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P3'], 'Frugal Participator')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P4'], 'Complacent Follower')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P5'], 'Healthy Independent')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P6'], 'Overwhelmed & Detached')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P7'], 'Agreeably Disengaged')

cat_var['MABH_SEG'] = cat_var.MABH_SEG.fillna('NO RECORD')
cat_var['PDPBH_SEG'] = cat_var.PDPBH_SEG.fillna('NO RECORD')

# MAPD beh seg
mapd_bseg_cat = pd.get_dummies(cat_var[['MABH_SEG']])
mapd_bseg_cat['MBR_PERS_GEN_KEY'] = cat_var.loc[:,'MBR_PERS_GEN_KEY']

# PDP beh seg
pdp_bseg_cat = pd.get_dummies(cat_var[['PDPBH_SEG']])
pdp_bseg_cat['MBR_PERS_GEN_KEY'] = cat_var.loc[:,'MBR_PERS_GEN_KEY']

# Combine Categorical Features
cat_var_sel = ['MBR_PERS_GEN_KEY'
              ,'MABH_SEG'
              ,'PDPBH_SEG']
cat_var_subset = cat_var[cat_var_sel]
cat_var_subset = pd.merge(cat_var_subset,mapd_bseg_cat,how='left',on='MBR_PERS_GEN_KEY')
cat_var_subset = pd.merge(cat_var_subset,pdp_bseg_cat,how='left',on='MBR_PERS_GEN_KEY')
cat_var_subset.head()
################################################################################################
# Select final columns
cat_var_fin = [
    'MBR_PERS_GEN_KEY'
    ,'MABH_SEG_Auto-pilot Participators','MABH_SEG_Health Services Maximizers','MABH_SEG_Healthy Self-Sustainers','MABH_SEG_NO RECORD','MABH_SEG_Overwhelmed and Reluctant Reactors','MABH_SEG_Self-Engaged Optimists','MABH_SEG_Simplicity-Seeking Followers','MABH_SEG_Skeptical Control-Seekers','MABH_SEG_Support-Seeking Participators'
    ,'PDPBH_SEG_Agreeably Disengaged','PDPBH_SEG_Complacent Follower','PDPBH_SEG_Frugal Participator', 'PDPBH_SEG_Healthy Independent','PDPBH_SEG_NO RECORD','PDPBH_SEG_Overwhelmed & Detached','PDPBH_SEG_Proactive Maximizer', 'PDPBH_SEG_Reactive Engager'
]

cat_var = cat_var_subset[cat_var_fin]
####################################################################################
# Join Categorical & Numerical Variables
df = pd.merge(num_var,cat_var,how='left',on='MBR_PERS_GEN_KEY')
####################################################################################
mapd_train = df[df.IND_MAPD == 1].copy()
pdp_train = df[df.IND_PDP == 1].copy()
print(mapd_train.MBR_PERS_GEN_KEY.count())
print(pdp_train.MBR_PERS_GEN_KEY.count())

# Scoring Code: MAPD - Imputation & Feature Engineering

# Imputate CAT values
mapd_train['TENURE_MBR_COV'].fillna(mapd_train.TENURE_MBR_COV.mean(),inplace = True) # New Member
mapd_train['HUM_AGE'].fillna(mapd_train.HUM_AGE.mean(),inplace = True) # New Member

# Imputate AMLK values
mapd_train['NTWPERYR'].fillna(mapd_train.NTWPERYR.mean(),inplace = True) # Net Worth Per Year
mapd_train['CHVA'].fillna(mapd_train.CHVA.mean(),inplace = True) # Census Median Home Value AMLK
mapd_train['RXNUM'].fillna(mapd_train.RXNUM.mean(),inplace = True) # # of Meds (modeled)
mapd_train['HWRXLOYL'].fillna(mapd_train.HWRXLOYL.mean(),inplace = True) # Rx Pharmacy Loyalty

print('Number of Nulls: ',mapd_train.size - mapd_train.count().sum())
# Fill remaining with 0s
mapd_train = mapd_train.fillna(0)
print('Number of Nulls: ',mapd_train.size - mapd_train.count().sum())
#############################################################################################
# Number of Available scripts to Convert
mapd_train['RX_CNTRX_HPRX'] = mapd_train.RX_CNT_RX_6M - mapd_train.RX_CNT_RHTSRCE_6M
#############################################################################################
# Engaged Members
engaged_col = ['MABH_SEG_Support-Seeking Participators'
               ,'MABH_SEG_Health Services Maximizers'
               ,'MABH_SEG_Self-Engaged Optimists'
               ,'MABH_SEG_Auto-pilot Participators'
#                ,'PDPBH_SEG_Frugal Participator'
#                ,'PDPBH_SEG_Proactive Maximizer'
#                ,'PDPBH_SEG_Reactive Engager'
              ]
mapd_train['ENGAGED_MEMBERS'] = mapd_train[engaged_col].any(axis=1)
mapd_train['ENGAGED_MEMBERS'] = mapd_train.loc[:,'ENGAGED_MEMBERS'].replace([True], 1)
mapd_train['ENGAGED_MEMBERS'] = mapd_train.loc[:,'ENGAGED_MEMBERS'].replace([False], 0)

# Unengaged Members
unengaged_col = ['MABH_SEG_Healthy Self-Sustainers',
               'MABH_SEG_Overwhelmed and Reluctant Reactors',
               'MABH_SEG_Simplicity-Seeking Followers',
               'MABH_SEG_Skeptical Control-Seekers',
#                'PDPBH_SEG_Agreeably Disengaged',
#                'PDPBH_SEG_Complacent Follower',
#                'PDPBH_SEG_Healthy Independent',
#                'PDPBH_SEG_Overwhelmed & Detached'
                ]

mapd_train['UNENGAGED_MEMBERS'] = mapd_train[unengaged_col].any(axis=1)
mapd_train['UNENGAGED_MEMBERS'] = mapd_train.loc[:,'UNENGAGED_MEMBERS'].replace([True], 1)
mapd_train['UNENGAGED_MEMBERS'] = mapd_train.loc[:,'UNENGAGED_MEMBERS'].replace([False], 0)

# No Behavioral Segments
noseg_col = ['MABH_SEG_NO RECORD'
#              ,'PDPBH_SEG_NO RECORD'
            ]
mapd_train['NO_BEHSEG_MEMBERS'] = mapd_train[noseg_col].all(axis=1)
mapd_train['NO_BEHSEG_MEMBERS'] = mapd_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([True], 1)
mapd_train['NO_BEHSEG_MEMBERS'] = mapd_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([False], 0)
#####################################################################################################
mapd_train.loc[mapd_train.NTWPERYR < 0, 'NTWPERYR'] = 0
mapd_train.loc[mapd_train.TS_LAST_LOGIN < 0, 'TS_LAST_LOGIN'] = 0
mapd_train.loc[mapd_train.TS_LAST_CALL < 0, 'TS_LAST_CALL'] = 0

# Scoring Code: MAPD - SCORE POPULATION

df = mapd_train.copy()
column_order = ['MBR_PERS_GEN_KEY',
                  'NTWPERYR', 'CHVA',
                  'RXNUM','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE',
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAINT_DRUG_6M','RX_CNT_RX_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'RX_CNTRX_HPRX',
                  'ENGAGED_MEMBERS','UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
                 ]
df = df[column_order]
##################################################################################
# Make PGK the index column
df.set_index('MBR_PERS_GEN_KEY', inplace=True)

# Create feature list
features_list = list(df.columns)
###################################################################################
# MAP RF
Decile_0 = 0.658
Decile_1 = 0.596
Decile_2 = 0.548
Decile_3 = 0.504
Decile_4 = 0.460
Decile_5 = 0.418
Decile_6 = 0.370
Decile_7 = 0.318
Decile_8 = 0.250
####################################################################################
# Import the model pickle
rxe_filename = 'rxe_rf_clf_mapd_random_sample.sav'
rxe_model = pickle.load(open(rxe_filename, 'rb'))

# Use the pickle model to score dataaset
y_probas = rxe_model.predict_proba(df) #df.values for XgBoost
y_score = pd.DataFrame(y_probas, columns=['prob_0', 'prob_1'])
y_score = y_score.drop(columns=['prob_0'],axis=1)
y_score.columns = ['rxe_resp_prob']

# Bring PGK back to the df & add scored probabilities
df.reset_index(inplace=True)
df_scored = pd.concat([df,y_score], axis=1)

# Add Deciles based on test data cutoffs
conditions = [
    (df_scored['rxe_resp_prob'] <= Decile_8),
    ((df_scored['rxe_resp_prob'] > Decile_8) & (df_scored['rxe_resp_prob'] <= Decile_7)),
    ((df_scored['rxe_resp_prob'] > Decile_7) & (df_scored['rxe_resp_prob'] <= Decile_6)),
    ((df_scored['rxe_resp_prob'] > Decile_6) & (df_scored['rxe_resp_prob'] <= Decile_5)),
    ((df_scored['rxe_resp_prob'] > Decile_5) & (df_scored['rxe_resp_prob'] <= Decile_4)),
    ((df_scored['rxe_resp_prob'] > Decile_4) & (df_scored['rxe_resp_prob'] <= Decile_3)),
    ((df_scored['rxe_resp_prob'] > Decile_3) & (df_scored['rxe_resp_prob'] <= Decile_2)),
    ((df_scored['rxe_resp_prob'] > Decile_2) & (df_scored['rxe_resp_prob'] <= Decile_1)),
    ((df_scored['rxe_resp_prob'] > Decile_1) & (df_scored['rxe_resp_prob'] <= Decile_0)),
    (df_scored['rxe_resp_prob'] > Decile_0)]
deciles = [9,8,7,6,5,4,3,2,1,0]

# Add deciles to the scored rxe population
df_scored['rxe_resp_decile'] = np.select(conditions,deciles,default=np.nan)

# Add score date
df_scored['SCORE_DATE'] = 20190729

# Rename Columns
df_scored.rename(columns={'rxe_resp_prob': 'MODEL_SCORE', 'rxe_resp_decile': 'DECILE'}, inplace=True)

# Change dtype of Decile
df_scored['DECILE'] = df_scored.DECILE.astype(int)

# Subset to the list of columns for final scoring table
columns_final = ['MBR_PERS_GEN_KEY','MODEL_SCORE','DECILE','SCORE_DATE']
df_scored = df_scored[columns_final]

# Export to CSV
# May wish to choose path for CSV file by placing in front of file name
df_scored.to_csv('rxe_model_scored_mapd.csv', encoding='utf-8',index=True)

# Scoring Code: PDP - Imputation & Feature Engineering

column_order = ['MBR_PERS_GEN_KEY',
                  'NTWPERYR', 'CHVA',
                  'RXBRAND','RXSOWRX','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE',
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAIL_ORDER_6M', 'RX_CNT_MAINT_DRUG_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'RX_CNTRX_HPRX',
                  'ENGAGED_MEMBERS','UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
                 ]

# Imputate CAT values
pdp_train['TENURE_MBR_COV'].fillna(pdp_train.TENURE_MBR_COV.mean(),inplace = True) # New Member
pdp_train['HUM_AGE'].fillna(pdp_train.HUM_AGE.mean(),inplace = True) # New Member

# Imputate AMLK values
pdp_train['NTWPERYR'].fillna(pdp_train.NTWPERYR.mean(),inplace = True) # Net Worth Per Year
pdp_train['CHVA'].fillna(pdp_train.CHVA.mean(),inplace = True) # Census Median Home Value AMLK
pdp_train['RXBRAND'].fillna(pdp_train.RXBRAND.mean(),inplace = True) # Prefer Brand Meds (0 more likely)
pdp_train['RXSOWRX'].fillna(pdp_train.RXSOWRX.mean(),inplace = True) # RX - Share of Wallet (0 loyal)
pdp_train['HWRXLOYL'].fillna(pdp_train.HWRXLOYL.mean(),inplace = True) # Rx Pharmacy Loyalty

print('Number of Nulls: ',pdp_train.size - pdp_train.count().sum())
# Fill remaining with 0s
pdp_train = pdp_train.fillna(0)
print('Number of Nulls: ',pdp_train.size - pdp_train.count().sum())
#############################################################################################
# Number of Available scripts to Convert
pdp_train['RX_CNTRX_HPRX'] = pdp_train.RX_CNT_RX_6M - pdp_train.RX_CNT_RHTSRCE_6M
#############################################################################################
# Engaged Members
engaged_col = ['PDPBH_SEG_Frugal Participator'
               ,'PDPBH_SEG_Proactive Maximizer'
               ,'PDPBH_SEG_Reactive Engager'
              ]
pdp_train['ENGAGED_MEMBERS'] = pdp_train[engaged_col].any(axis=1)
pdp_train['ENGAGED_MEMBERS'] = pdp_train.loc[:,'ENGAGED_MEMBERS'].replace([True], 1)
pdp_train['ENGAGED_MEMBERS'] = pdp_train.loc[:,'ENGAGED_MEMBERS'].replace([False], 0)

# Unengaged Members
unengaged_col = ['PDPBH_SEG_Agreeably Disengaged',
               'PDPBH_SEG_Complacent Follower',
               'PDPBH_SEG_Healthy Independent',
               'PDPBH_SEG_Overwhelmed & Detached'
                ]

pdp_train['UNENGAGED_MEMBERS'] = pdp_train[unengaged_col].any(axis=1)
pdp_train['UNENGAGED_MEMBERS'] = pdp_train.loc[:,'UNENGAGED_MEMBERS'].replace([True], 1)
pdp_train['UNENGAGED_MEMBERS'] = pdp_train.loc[:,'UNENGAGED_MEMBERS'].replace([False], 0)

# No Behavioral Segments
noseg_col = ['PDPBH_SEG_NO RECORD']
pdp_train['NO_BEHSEG_MEMBERS'] = pdp_train[noseg_col].all(axis=1)
pdp_train['NO_BEHSEG_MEMBERS'] = pdp_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([True], 1)
pdp_train['NO_BEHSEG_MEMBERS'] = pdp_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([False], 0)
#####################################################################################################
pdp_train.loc[pdp_train.NTWPERYR < 0, 'NTWPERYR'] = 0
pdp_train.loc[pdp_train.TS_LAST_LOGIN < 0, 'TS_LAST_LOGIN'] = 0
pdp_train.loc[pdp_train.TS_LAST_CALL < 0, 'TS_LAST_CALL'] = 0

# Scoring Code: PDP - SCORE POPULATION

df = pdp_train.copy()
column_order = ['MBR_PERS_GEN_KEY',
                  'NTWPERYR', 'CHVA',
                  'RXBRAND','RXSOWRX','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE',
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAIL_ORDER_6M', 'RX_CNT_MAINT_DRUG_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'RX_CNTRX_HPRX',
                  'ENGAGED_MEMBERS','UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
                 ]
df = df[column_order]
##################################################################################
# Make PGK the index column
df.set_index('MBR_PERS_GEN_KEY', inplace=True)

# Create feature list
features_list = list(df.columns)
###################################################################################
# MAP RF
Decile_0 = 0.682
Decile_1 = 0.592
Decile_2 = 0.518
Decile_3 = 0.454
Decile_4 = 0.400
Decile_5 = 0.350
Decile_6 = 0.298
Decile_7 = 0.238
Decile_8 = 0.156
####################################################################################
# Import the model pickle
rxe_filename = 'rxe_rf_clf_pdp_random_sample.sav'
rxe_model = pickle.load(open(rxe_filename, 'rb'))

# Use the pickle model to score dataaset
y_probas = rxe_model.predict_proba(df) #df.values for XgBoost
y_score = pd.DataFrame(y_probas, columns=['prob_0', 'prob_1'])
y_score = y_score.drop(columns=['prob_0'],axis=1)
y_score.columns = ['rxe_resp_prob']

# Bring PGK back to the df & add scored probabilities
df.reset_index(inplace=True)
df_scored = pd.concat([df,y_score], axis=1)

# Add Deciles based on test data cutoffs
conditions = [
    (df_scored['rxe_resp_prob'] <= Decile_8),
    ((df_scored['rxe_resp_prob'] > Decile_8) & (df_scored['rxe_resp_prob'] <= Decile_7)),
    ((df_scored['rxe_resp_prob'] > Decile_7) & (df_scored['rxe_resp_prob'] <= Decile_6)),
    ((df_scored['rxe_resp_prob'] > Decile_6) & (df_scored['rxe_resp_prob'] <= Decile_5)),
    ((df_scored['rxe_resp_prob'] > Decile_5) & (df_scored['rxe_resp_prob'] <= Decile_4)),
    ((df_scored['rxe_resp_prob'] > Decile_4) & (df_scored['rxe_resp_prob'] <= Decile_3)),
    ((df_scored['rxe_resp_prob'] > Decile_3) & (df_scored['rxe_resp_prob'] <= Decile_2)),
    ((df_scored['rxe_resp_prob'] > Decile_2) & (df_scored['rxe_resp_prob'] <= Decile_1)),
    ((df_scored['rxe_resp_prob'] > Decile_1) & (df_scored['rxe_resp_prob'] <= Decile_0)),
    (df_scored['rxe_resp_prob'] > Decile_0)]
deciles = [9,8,7,6,5,4,3,2,1,0]

# Add deciles to the scored rxe population
df_scored['rxe_resp_decile'] = np.select(conditions,deciles,default=np.nan)

# Add score date
df_scored['SCORE_DATE'] = 20190729

# Rename Columns
df_scored.rename(columns={'rxe_resp_prob': 'MODEL_SCORE', 'rxe_resp_decile': 'DECILE'}, inplace=True)

# Change dtype of Decile
df_scored['DECILE'] = df_scored.DECILE.astype(int)

# Subset to the list of columns for final scoring table
columns_final = ['MBR_PERS_GEN_KEY','MODEL_SCORE','DECILE','SCORE_DATE']
df_scored = df_scored[columns_final]

# Export to CSV
# May wish to choose path for CSV file by placing in front of file name
df_scored.to_csv('rxe_model_scored_pdp.csv', encoding='utf-8',index=True)



