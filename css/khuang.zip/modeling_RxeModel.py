# Databricks notebook source
# MAGIC %md # Modeling with SparkML
# MAGIC 
# MAGIC ### Requirements
# MAGIC 
# MAGIC 1. You have access to data and workspaces within Humana's Microsoft Azure cloud in a Pre-Production resource group.
# MAGIC 2. A Databricks Workspace exists with at least one Cluster created to attach your notebook to compute resources.
# MAGIC 3. A Key Vault and DB Secret Scope have been created for use with your Databricks Workspace.
# MAGIC 4. Necessary secret keys exist in the Key Vault associated with your Databricks Workspace.
# MAGIC 5. You have defined your modeling target and features, with both stored in an ADLS Gen 2 Storage Account
# MAGIC 
# MAGIC ### Goals  
# MAGIC 1. Use a prepared set of features and target to model with SparkML
# MAGIC 2. Run and track experiments through Azure Machine Learning Services
# MAGIC 3. Select and register the best model, tagging it with key information
# MAGIC 
# MAGIC ### Standard Conventions
# MAGIC 1. Coding standards in compliance with PEP8
# MAGIC 2. Exception: Constants follow same format as variable names
# MAGIC 3. All items the user is expected to change within existing code will appear in ALL_CAPS_WITH_UNDERSCORES

# COMMAND ----------

# MAGIC %md # Process
# MAGIC 1. Make sure everything is named correctly
# MAGIC 2. modeling_spline_surgery.py
# MAGIC train
# MAGIC   * 
# MAGIC score::batch - what we want to run in production - 
# MAGIC   * clincal_score_output.py - Process of output
# MAGIC   * feature_engineering.py - Selecting and pulling features
# MAGIC   * score - taking those features and scoring and moves it to staging location
# MAGIC   * validate_scores - Make sure staging location of score is correct, moves it out to be published
# MAGIC shared
# MAGIC   * What we have for training & production - Custom Scripts for feature engineering
# MAGIC   * things that you will share
# MAGIC   * model_registration.py - register spark model - Form ws connection, path model saved out to, name of model, dictionary of tags, string descriptions :: Move it from alds to local file system - returns the name and version of model::Download model and move 

# COMMAND ----------

# Put the schema together where it has just whats needed for that models

# COMMAND ----------

# MAGIC %md ### Initialization Steps  
# MAGIC 1. Load Packages  
# MAGIC 2. Display DB Secret Scopes  
# MAGIC 3. Set config parameters for connecting to a storage account

# COMMAND ----------

# Ensure the correct versions of needed libraries are available
dbutils.library.installPyPI("azureml_sdk", version="1.0.76", extras="databricks")
dbutils.library.restartPython()

# COMMAND ----------

# Loads Basic Packages

from pyspark.sql.types import *
from pyspark.sql.functions import udf
from pyspark.sql.functions import col
from pyspark.sql import functions as f

import sys; print('Python Version:',sys.version)
import numpy as np; print("Numpy Version:",np.__version__)
import pandas as pd; print("Pandas Version:",pd.__version__)
import matplotlib.pyplot as plt
import seaborn as sns

import time
from datetime import datetime
import re
from calendar import monthrange
from dateutil.relativedelta import relativedelta
from pyspark.sql.window import Window

import os
import logging
import shutil

import azureml.core
from azureml.core import Workspace
from azureml.core.run import Run
from azureml.core.experiment import Experiment
from azureml.core.authentication import ServicePrincipalAuthentication
from azureml.core.model import Model

from pyspark.ml import Pipeline
from pyspark.ml.feature import OneHotEncoderEstimator
from pyspark.ml.feature import StringIndexer
from pyspark.ml.feature import VectorAssembler
from pyspark.ml.feature import VectorSlicer
from pyspark.ml.feature import Imputer
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.classification import LogisticRegression
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.tuning import ParamGridBuilder
from pyspark.ml.tuning import CrossValidator
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.ml.tuning import ParamGridBuilder, CrossValidator
from pyspark.ml.evaluation import MulticlassClassificationEvaluator # Evaluation df
from pyspark.mllib.evaluation import MulticlassMetrics # Confusion Matrix rdd
from pyspark.mllib.evaluation import MultilabelMetrics

# Creates the class needed to return error messages when pre-requisites are not met
class HaltException(Exception): pass

# Check core SDK version number
print("SDK version:", azureml.core.VERSION)

# COMMAND ----------

#Lists names of secret scopes and keys within them that are active for this Databricks Workspace

# Hi Kevin! This code outputs the key names --> your scope is "dha-mlp-cods-credential" and the names are listed below for each one

# So for Keys Available for example it might say client-id
# Does that mean the client-id is in that variable?  Yes, that's what should go in the "YOUR_KEY_NAME"  --> so for service_principal_id = client-id and service_principal_password = client-secret.  Others are self-explanatory
print("Secret Scopes:")
for x in dbutils.secrets.listScopes():
  print(x.name)
  print ("    Keys Available:")
  for y in dbutils.secrets.list(x.name):
    print ("    " + y.key)

# COMMAND ----------

# Required config settings to enable proper use of Credential PassThrough to connect to storage account
spark.conf.set("fs.azure.account.auth.type", "CustomAccessToken")
spark.conf.set("fs.azure.account.custom.token.provider.class", spark.conf.get("spark.databricks.passthrough.adls.gen2.tokenProviderClassName"))

# COMMAND ----------

# Key constants to define

# MLP storage account
storage_acct_name = "dha0mlp0prod"

# Computed constants
adls_source_path = "abfss://tempdata@" + storage_acct_name + ".dfs.core.windows.net"
adls_raw_path = "abfss://raw@" + storage_acct_name + ".dfs.core.windows.net"
adls_ref_path = "abfss://reference@" + storage_acct_name + ".dfs.core.windows.net"
adls_xformed_path = "abfss://transformed@" + storage_acct_name + ".dfs.core.windows.net"
adls_results_path = "abfss://results@" + storage_acct_name + ".dfs.core.windows.net"
target_adls_fs = adls_results_path

#Use this to specify your write path underneath transformed
target_folder_path = "/lvl1/models/rxe-model-v1/20190630-rxe"

random_seed_val = 12345   #Can change to whatever you want - will be used throughout this notebook


# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## Link to Guide for SparkML Documenation
# MAGIC 
# MAGIC https://spark.apache.org/docs/latest/ml-guide.html

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## Load and Prepare Feature Data

# COMMAND ----------

sav_date = datetime.today().strftime("%Y%m%d")
#Load your data into memory - assumes it exists in an ADLS Gen 2 Storage Account or a Blob Storage Account
mbrs_df = spark.read.parquet(adls_xformed_path + "/lvl1/models/medr-rxe-model-v1/model-target-population/20190630-rxe-mbrs").select("sdr_person_id","unique_id","fin_sub_cd","rx_enroll").cache()
# mbrs_df = spark.read.parquet(adls_xformed_path + "/lvl1/models/rxe-model-v1/20190630-rxe-mbrs").select("sdr_person_id","unique_id","fin_sub_cd","rx_enroll").cache()

# model_mbr_char_df = spark.read.parquet(adls_xformed_path + target_folder_path + "-feat-mbr-char").cache()
model_mbr_char_df = spark.read.parquet(target_adls_fs + "/lvl1/models/rxe-model-v1/select-feat/" + "20191212").cache()



# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## Save Schema Output

# COMMAND ----------

# Identify PDP categories: pdp_fin_sub_vals - ['MDG','MDI','MDL','HMI']      
prod_ind_df = mbrs_df.withColumn('fin_sub_cd', f.when((mbrs_df.fin_sub_cd == 'MDG') | 
                                        (mbrs_df.fin_sub_cd == 'MDI') | 
                                        (mbrs_df.fin_sub_cd == 'MDL') | 
                                        (mbrs_df.fin_sub_cd == 'HMI') ,0).otherwise(1))

# Rename Column
prod_ind_df = prod_ind_df.withColumnRenamed("fin_sub_cd", "ind_mapd")

prod_ind_feat = ['unique_id', 'sdr_person_id','ind_mapd']
prod_ind_df = prod_ind_df.select(prod_ind_feat).cache()

# COMMAND ----------

# Join target variable back to orignal df
schema_model_mbr_char_df = (model_mbr_char_df.join(prod_ind_df,["sdr_person_id","unique_id"],'left_outer').cache())

# COMMAND ----------

# MAGIC %run ../shared/schema_output

# COMMAND ----------

# # Save the schema of the selected features
# model_data_schema_json = model_mbr_char_df.schema.json()
# with open("./schema.json", "w") as schema_json:
#   schema_json.write(model_data_schema_json)
# run.upload_file("outputs/schema.json", "./schema.json")


# Save the schema to ADLS
schema_adls_path = adls_xformed_path + "/lvl1/models/rxe-model-v1/feat-schema/"
# schema_adls_path = target_adls_fs + "/lvl1/models/rxe-model-v1/feat-schema/"
schema_filename = "selected-features.json"
output_schema(schema_model_mbr_char_df, schema_adls_path, schema_filename)

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md ### Prep for Modeling & Data Imputation 

# COMMAND ----------

# Identify PDP categories: pdp_fin_sub_vals - ['MDG','MDI','MDL','HMI']      
mbrs_df = mbrs_df.withColumn('fin_sub_cd', f.when((mbrs_df.fin_sub_cd == 'MDG') | 
                                        (mbrs_df.fin_sub_cd == 'MDI') | 
                                        (mbrs_df.fin_sub_cd == 'MDL') | 
                                        (mbrs_df.fin_sub_cd == 'HMI') ,0).otherwise(1))

# Rename Column
mbrs_df = mbrs_df.withColumnRenamed("fin_sub_cd", "ind_mapd")

# COMMAND ----------

# Join target variable back to orignal df
model_mbr_char_df = (model_mbr_char_df.join(mbrs_df,["sdr_person_id","unique_id"],'left_outer').cache())

# COMMAND ----------

mapd_model_mbr_char_df = model_mbr_char_df.filter(col("ind_mapd") == 1)
pdp_model_mbr_char_df = model_mbr_char_df.filter(col("ind_mapd") == 0)

# COMMAND ----------

# MAGIC %md ##### Data Imputation 

# COMMAND ----------

mapd_model_mbr_char_df = (mapd_model_mbr_char_df.withColumn("cons_ntwperyr", mapd_model_mbr_char_df['cons_ntwperyr'].cast('float'))
                                                .withColumn('cons_chva', mapd_model_mbr_char_df['cons_chva'].cast('float'))
                                                .withColumn('cons_rxnum', mapd_model_mbr_char_df['cons_rxnum'].cast('float'))
                                                .withColumn('cons_rxbrand', mapd_model_mbr_char_df['cons_rxbrand'].cast('float'))
                                                .withColumn('cons_rxsowrx', mapd_model_mbr_char_df['cons_rxsowrx'].cast('float'))
                                                .withColumn('cons_hwrxloyl', mapd_model_mbr_char_df['cons_hwrxloyl'].cast('float')))
mapd_imputer = Imputer(inputCols=['cons_ntwperyr', 'cons_chva', 'cons_rxnum','cons_rxbrand','cons_rxsowrx','cons_hwrxloyl']
                  ,outputCols=['cons_ntwperyr', 'cons_chva', 'cons_rxnum','cons_rxbrand','cons_rxsowrx', 'cons_hwrxloyl'])
mapd_imputer = mapd_imputer.setStrategy("mean").fit(mapd_model_mbr_char_df)
mapd_model_mbr_char_df = mapd_imputer.transform(mapd_model_mbr_char_df)
# Change nulls to 0 - mbr_respons_amt_pmpm & ded_paid_amt_pmpm

# COMMAND ----------

# save imputer
imputer_name = "mapd"
imputer_path = adls_xformed_path + "/lvl1/models/rxe-model-v1/imputation/" + imputer_name
# imputer_path = target_adls_fs + "/lvl1/models/rxe-model-v1/imputation/" + imputer_name

mapd_imputer.write().overwrite().save(imputer_path)

# COMMAND ----------

pdp_model_mbr_char_df = (pdp_model_mbr_char_df.withColumn("cons_ntwperyr", pdp_model_mbr_char_df['cons_ntwperyr'].cast('float'))
                                              .withColumn('cons_chva', pdp_model_mbr_char_df['cons_chva'].cast('float'))
                                              .withColumn('cons_rxnum', pdp_model_mbr_char_df['cons_rxnum'].cast('float'))
                                              .withColumn('cons_rxbrand', pdp_model_mbr_char_df['cons_rxbrand'].cast('float'))
                                              .withColumn('cons_rxsowrx', pdp_model_mbr_char_df['cons_rxsowrx'].cast('float'))
                                              .withColumn('cons_hwrxloyl', pdp_model_mbr_char_df['cons_hwrxloyl'].cast('float')))
pdp_imputer = Imputer(inputCols=['cons_ntwperyr', 'cons_chva', 'cons_rxnum','cons_rxbrand','cons_rxsowrx','cons_hwrxloyl']
                  ,outputCols=['cons_ntwperyr', 'cons_chva', 'cons_rxnum','cons_rxbrand','cons_rxsowrx', 'cons_hwrxloyl'])
pdp_imputer = pdp_imputer.setStrategy("mean").fit(pdp_model_mbr_char_df)
pdp_model_mbr_char_df = pdp_imputer.transform(pdp_model_mbr_char_df)

# COMMAND ----------

# save imputer
imputer_name = "pdp"
imputer_path = adls_xformed_path + "/lvl1/models/rxe-model-v1/imputation/" + imputer_name
# imputer_path = target_adls_fs + "/lvl1/models/rxe-model-v1/imputation/" + imputer_name

pdp_imputer.write().overwrite().save(imputer_path)

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# Parameters

# HINT: You can use list comprehensions based on field name prefixes or other unique aspects to generate the column list you need
# ASSUMPTION: any remaining columns not listed here are numeric

ignore_cols = ["sdr_person_id",'unique_id','src_platform_cd','mco_contract_nbr','plan_benefit_package_id','ind_mapd']
categorical_cols = []
target_col = "rx_enroll"
primary_id_col = "unique_id"

#Filter down to selected variables
categorical_cols = [c for c in mapd_model_mbr_char_df.columns if c not in categorical_cols]
# Creates list of Numeric Cols based on balance of columns available
non_num_cols = ignore_cols + categorical_cols + [target_col, primary_id_col]
num_cols = [c for c in mapd_model_mbr_char_df.columns if c not in non_num_cols]

# Count of Members
maxMbrCt = float(model_mbr_char_df.count())

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md
# MAGIC ## Model Build - MAPD

# COMMAND ----------

# MAGIC %md ##### Ad-Hoc Build

# COMMAND ----------

# Filter to columns used for modeling
final_features = ['sdr_person_id', #'unique_id',
                  'cons_ntwperyr', 'cons_chva',
                  'cons_rxnum','cons_hwrxloyl',
                  'pre_month_total', 'est_age', 
                  'ded_paid_amt_pmpm',
                  'rx_maint_pmpm_ct','rx_overall_pmpm_ct',
                  'rx_tier_1_pmpm_ct', 'rx_tier_2_pmpm_ct',
                  'mbr_respons_amt_pmpm','rx_overall_pmpm_cost',
                  'days_since_last_login', # 'TS_LAST_CALL',
                  'rx_cntrx_hprx_pmpm',
                  'bhseg_engaged_mbrs_ind',
                  'bhseg_unengaged_mbrs_ind', 'bhseg_norecord_ind',
                  'rx_enroll'
                 ]

# Lowercase column names - List comprehensions
final_features = [element.lower() for element in final_features]

#Filters your initial dataframe down to important columns
spark_mapd = mapd_model_mbr_char_df.select(final_features).cache()

# COMMAND ----------

# spark_mapd.printSchema() # shows the schema in tree format

# COMMAND ----------

# % of Non-null values
nullNumDF = spark_mapd.select(final_features).agg(*[f.count(c).alias(c) for c in final_features]).collect()

# Count of Members
maxMbrCt = float(spark_mapd.count())

# Empty List of Columns with Nulls
listOfColsWNullsNum = []

for x in final_features:
    pctCov = nullNumDF[0][x]/maxMbrCt
    if pctCov < 1:
        listOfColsWNullsNum.append((x,pctCov))

#Displays the list of columns with at least 1 null values and the percentage of NON-NULL values (e.g. 0.99 = 99% not null)
print ("Columns With Nulls:")
for x in listOfColsWNullsNum:
    print (x)

# COMMAND ----------

# Drop Nulls if necessary
spark_mapd = spark_mapd.na.drop()

# COMMAND ----------

# # Subset to features used for model 
# seed = 21
# ###########################################################
# # Spliting in train and test set. Beware : It sorts the dataset
# (traindf_, testdf) = spark_mapd.randomSplit([0.85,0.15],seed)
# (traindf, valdf) = traindf_.randomSplit([0.85,0.15],seed)

# # Class Distribution for the training and test set
# print('TRAIN')
# print('Total # Records',traindf.count())
# print(traindf.groupBy("rx_enroll").count().take(2))
# # print(traindf.select(f.sum(f.when(f.col('rx_enroll') == 1, 1)).alias('rx_enroll == 1')).show(truncate=False))

# print('\n','VAL')
# print('Total # Records',valdf.count())
# print(valdf.groupBy("rx_enroll").count().take(2))

# print('\n','TEST')
# print('Total # Records',testdf.count())
# print(testdf.groupBy("rx_enroll").count().take(2))
# ###########################################################
# # Downsample dataset
# # Before Resampling
# print('\n','Resampled Training Set: ')
# # traindf_zero = traindf.filter("rx_enroll=0.0")
# print('Number of class 0 samples before:',traindf.filter("rx_enroll=0.0").count())

# # Downsample dataset
# traindf_zero = traindf.filter("rx_enroll=0.0")
# traindf_one = traindf.filter("rx_enroll=1.0")

# traindf_sampleRatio = traindf_one.count() / traindf.count()
# traindf_zero_downsample = traindf_zero.sample(withReplacement=False,fraction=traindf_sampleRatio+.001,seed=seed) #fraction = % you want to draw from that sample
# traindf_sampled = traindf_one.unionAll(traindf_zero_downsample)

# # After Resampling
# print('Number of class 0 samples after:',traindf_zero_downsample.count())
# print('Number of class 1 samples after:',traindf_one.count())
# print(traindf_sampled.groupBy("rx_enroll").count().take(2))

# ###########################################################
# # Remove PGK from model
# train = traindf_sampled
# val = valdf
# test = testdf
# traindf = traindf_sampled.drop("sdr_person_id")
# valdf = valdf.drop("sdr_person_id")
# testdf = testdf.drop("sdr_person_id")
# print(train.groupBy("rx_enroll").count().take(2))
# print(val.groupBy("rx_enroll").count().take(2))
# print(test.groupBy("rx_enroll").count().take(2))
# ###########################################################
# # Features
# model_features = ['cons_ntwperyr', 'cons_chva',
#                   'cons_rxnum','cons_hwrxloyl',
#                   'pre_month_total', 'est_age', 
#                   'ded_paid_amt_pmpm',
#                   'rx_maint_pmpm_ct','rx_overall_pmpm_ct',
#                   'rx_tier_1_pmpm_ct', 'rx_tier_2_pmpm_ct',
#                   'mbr_respons_amt_pmpm','rx_overall_pmpm_cost',
#                   'days_since_last_login', # 'TS_LAST_CALL',
#                   'rx_cntrx_hprx_pmpm',
#                   'bhseg_engaged_mbrs_ind',
#                   'bhseg_unengaged_mbrs_ind', 'bhseg_norecord_ind',
#                  ]

# # Lowercase column names - List comprehensions
# model_features = [element.lower() for element in model_features]
# ###########################################################
# # Fit Random Forest Classifier to Training Data
# # Index labels, adding metadata to the label column.
# # Fit on whole dataset to include all labels in index.
# traindf = StringIndexer(inputCol="rx_enroll", outputCol="indexed_rx_enroll").fit(traindf).transform(traindf)

# # Feature assembler as a vector
# traindf = VectorAssembler(inputCols=model_features,outputCol="features").transform(traindf)

# # Model
# mapd_rf = RandomForestClassifier(labelCol="indexed_rx_enroll", featuresCol="features", numTrees=500, maxDepth=5,featureSubsetStrategy="sqrt",impurity="entropy")

# mapd_classifier = mapd_rf.fit(traindf)
# ###########################################################
# # Predict on the Test Data rf
# # Feature assembler as a vector
# testdf = VectorAssembler(inputCols=model_features,outputCol="features").transform(testdf)

# # Prediction
# predictions_mapd = mapd_classifier.transform(testdf)

# # Split out the conversion and non-conversion columns
# split1_udf = udf(lambda value: value[0].item(), FloatType())
# split2_udf = udf(lambda value: value[1].item(), FloatType())
# predictions_mapd = predictions_mapd.withColumn('non_convert', split1_udf('probability')).withColumn('convert', split2_udf('probability'))  

# # Select example rows to display.
# # Probability shows of class 0
# # predictions.select(col("prediction"),col("probability"),).show(15)
# display(predictions_mapd)

# COMMAND ----------

# MAGIC %md ##### Pipeline

# COMMAND ----------

random_seed_val=21
seed=21

# Features
model_features = ['cons_ntwperyr', 'cons_chva',
                  'cons_rxnum','cons_hwrxloyl',
                  'pre_month_total', 'est_age', 
                  'ded_paid_amt_pmpm',
                  'rx_maint_pmpm_ct','rx_overall_pmpm_ct',
                  'rx_tier_1_pmpm_ct', 'rx_tier_2_pmpm_ct',
                  'mbr_respons_amt_pmpm','rx_overall_pmpm_cost',
                  'days_since_last_login', # 'TS_LAST_CALL',
                  'rx_cntrx_hprx_pmpm',
                  'bhseg_engaged_mbrs_ind',
                  'bhseg_unengaged_mbrs_ind', 'bhseg_norecord_ind',
                 ]

# Lowercase column names - List comprehensions
model_features = [element.lower() for element in model_features]
###########################################################
# Fit on whole dataset to include all labels in index.
labelIndexer = StringIndexer(inputCol="rx_enroll", outputCol="label")

#Next is to vectorize the columns: feature transformer that merges multiple columns into a vector column:
assembler1 =  VectorAssembler(inputCols=model_features,outputCol="features")

# # Scale all numeric fields between [0,1]
# scaler = (MinMaxScaler(inputCol="features", outputCol="scaledFeatures"))

mapd_rf = RandomForestClassifier(labelCol="label", featuresCol="features", numTrees=500,featureSubsetStrategy="sqrt",impurity="entropy")

# Chain indexer and in a Pipeline
pipeline = Pipeline(stages=[labelIndexer] + [assembler1,mapd_rf])
###########################################################
# Performance of model
(traindf, testdf) = spark_mapd.randomSplit([0.8, 0.2], seed=21)

# Class Distribution for the training and test set
print('TRAIN')
print('Total # Records',traindf.count())
print(traindf.groupBy("rx_enroll").count().take(2))
# print(traindf.select(f.sum(f.when(f.col('rx_enroll') == 1, 1)).alias('rx_enroll == 1')).show(truncate=False))

print('\n','TEST')
print('Total # Records',testdf.count())
print(testdf.groupBy("rx_enroll").count().take(2))
###########################################################
# Downsample dataset
# Before Resampling
print('\n','Resampled Training Set: ')
# traindf_zero = traindf.filter("rx_enroll=0.0")
print('Number of class 0 samples before:',traindf.filter("rx_enroll=0.0").count())

# Downsample dataset
traindf_zero = traindf.filter("rx_enroll=0.0")
traindf_one = traindf.filter("rx_enroll=1.0")

traindf_sampleRatio = traindf_one.count() / traindf.count()
traindf_zero_downsample = traindf_zero.sample(withReplacement=False,fraction=traindf_sampleRatio+.001,seed=seed) #fraction = % you want to draw from that sample
traindf_sampled = traindf_one.unionAll(traindf_zero_downsample)

# After Resampling
print('Number of class 0 samples after:',traindf_zero_downsample.count())
print('Number of class 1 samples after:',traindf_one.count())
print(traindf_sampled.groupBy("rx_enroll").count().take(2))
###########################################################
# Update Training data to be downsampled
traindf = traindf_sampled
testdf = testdf
print(traindf.groupBy("rx_enroll").count().take(2))
print(testdf.groupBy("rx_enroll").count().take(2))
###########################################################
# Train model. 
mapd_classifier = pipeline.fit(traindf)
predictions_mapd = mapd_classifier.transform(testdf)
# model_train_RF = mapd_classifier.transform(traindf)
###########################################################
# Split out the conversion and non-conversion columns
split1_udf = udf(lambda value: value[0].item(), FloatType())
split2_udf = udf(lambda value: value[1].item(), FloatType())
predictions_mapd = predictions_mapd.withColumn('non_convert', split1_udf('probability')).withColumn('convert', split2_udf('probability'))  

display(predictions_mapd)

# COMMAND ----------

# MAGIC %md ##### Performance of MAPD

# COMMAND ----------

# Evaluate Model
# Accuracy
evaluator = MulticlassClassificationEvaluator(labelCol="rx_enroll", predictionCol="prediction", metricName="accuracy")
accuracy = evaluator.evaluate(predictions_mapd)
print("Accuracy = %g" % (accuracy))

evaluatorf1 = MulticlassClassificationEvaluator(labelCol="rx_enroll", predictionCol="prediction", metricName="f1")
f1 = evaluatorf1.evaluate(predictions_mapd)
print("f1 = %g" % (f1))

evaluatorwp = MulticlassClassificationEvaluator(labelCol="rx_enroll", predictionCol="prediction", metricName="weightedPrecision")
wp = evaluatorwp.evaluate(predictions_mapd)
print("weightedPrecision = %g" % (wp))

evaluatorwr = MulticlassClassificationEvaluator(labelCol="rx_enroll", predictionCol="prediction", metricName="weightedRecall")
wr = evaluatorwr.evaluate(predictions_mapd)
print("weightedRecall = %g" % (wr))

# # Confusion Matrix
# # Create (prediction, label) pairs
# predictionAndLabel = predictions.select("prediction", "rx_enroll").rdd

# # Generate confusion matrix
# metrics = MulticlassMetrics(predictionAndLabel)
# print(metrics.confusionMatrix())

# COMMAND ----------

# Import packages
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import brier_score_loss
from sklearn.metrics import f1_score
from sklearn.metrics import roc_auc_score, roc_curve, auc

# Convert Spark df to Pandas df to get confusion matrix since I cant figure it out in spark
df_mapd = predictions_mapd.toPandas()

# Convert for easy use of old code
y_val = df_mapd.rx_enroll
y_pred = df_mapd.prediction

# Missclassified
print('Number of Misclassified: ',(y_val != y_pred).sum())

###########################################################
# Confusion Matrix
cm = confusion_matrix(y_val, y_pred)
print('[[True Negative, False Positive]')
print('[False Negative, True Positive]]')
print(cm)
###########################################################
# Recall (True Positive / Positive Cases (TP & FN)): True Positive Rate
# print('TRUE POSITIVE RATE (Recall or Sensitivity) =','TP / (TP+FN)')
print('Accuracy: %.3f' % accuracy_score(y_true=y_val, y_pred=y_pred))
print('Recall: %.3f' % recall_score(y_true=y_val, y_pred=y_pred))
print('Precision: %.3f' % precision_score(y_true=y_val, y_pred=y_pred))

# COMMAND ----------

# Deciles
colnames = ['sdr_person_id',
            'cons_ntwperyr', 'cons_chva',
            'cons_rxnum','cons_hwrxloyl',
            'pre_month_total', 'est_age', 
            'ded_paid_amt_pmpm',
            'rx_maint_pmpm_ct','rx_overall_pmpm_ct',
            'rx_tier_1_pmpm_ct', 'rx_tier_2_pmpm_ct',
            'mbr_respons_amt_pmpm','rx_overall_pmpm_cost',
            'days_since_last_login', # 'TS_LAST_CALL',
            'rx_cntrx_hprx_pmpm',
            'bhseg_engaged_mbrs_ind',
            'bhseg_unengaged_mbrs_ind', 'bhseg_norecord_ind',
           ]

test = testdf.toPandas()

results = pd.DataFrame(test,columns = colnames)
# results['sdr_person_id'] = test[:,0].astype(np.int64)
results['y_actual'] = y_val
results['y_probas'] = df_mapd.convert
results['y_preds'] = y_pred
results.head(5)
#################################################################################
# Results sorted by Probability Predicted
results['decile']= pd.qcut(results.y_probas, 10
       ,labels=[9,8,7,6,5,4,3,2,1,0])
results_sort = results.sort_values(by='y_probas',ascending=False).reset_index()
results_sort = results_sort.drop(['index'], axis=1)
results_sort.head(5)
#################################################################################
# Decile Cut offs
for decile in range(9):
    print('-',decile,end=")")
    print('\033[1m'+ 'Decile ' + str(decile) +'\033[0m',end=": ")
    print(results_sort[results_sort.decile == decile].y_probas.min())

# COMMAND ----------

# Save out testdf results
pred_target_df_columns = ['y_probas','y_actual','sdr_person_id']
mapd_pred_target_df = results_sort[pred_target_df_columns]

# Convert back to spark
mapd_pred_target_df = spark.createDataFrame(mapd_pred_target_df)
mapd_pred_target_df.count()
mapd_pred_target_df.filter(col('y_actual')==1).count()

# Output the test scores
(mapd_pred_target_df
 .write
 .mode("overwrite")
 .option("header", "true")
 .format("parquet")
 .save(adls_xformed_path + "/lvl1/models/rxe-model-v1/training-scores"))

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md
# MAGIC ## Model Build - PDP
# MAGIC 
# MAGIC Built Model

# COMMAND ----------

# Filter to columns used for modeling
final_features = ['sdr_person_id', # 'unique_id',
                  'cons_ntwperyr', 'cons_chva',
                  'cons_rxbrand','cons_rxsowrx','cons_hwrxloyl',
                  'pre_month_total', 'est_age', 
                  'ded_paid_amt_pmpm',
                  'rx_mail_pmpm_ct',
                  'rx_maint_pmpm_ct',
                  'rx_tier_1_pmpm_ct', 'rx_tier_2_pmpm_ct',
                  'mbr_respons_amt_pmpm','rx_overall_pmpm_cost',
                  'days_since_last_login', # 'TS_LAST_CALL',
                  'rx_cntrx_hprx_pmpm',
                  'bhseg_engaged_mbrs_ind',
                  'bhseg_unengaged_mbrs_ind', 'bhseg_norecord_ind',
                  'rx_enroll'
                 ]

# Lowercase column names - List comprehensions
final_features = [element.lower() for element in final_features]

#Filters your initial dataframe down to important columns
spark_pdp = pdp_model_mbr_char_df.select(final_features).cache()

# COMMAND ----------

# spark_pdp.printSchema() # shows the schema in tree format

# COMMAND ----------

# % of Non-null values
nullNumDF = spark_pdp.select(final_features).agg(*[f.count(c).alias(c) for c in final_features]).collect()

# Count of Members
maxMbrCt = float(spark_pdp.count())

# Empty List of Columns with Nulls
listOfColsWNullsNum = []

for x in final_features:
    pctCov = nullNumDF[0][x]/maxMbrCt
    if pctCov < 1:
        listOfColsWNullsNum.append((x,pctCov))

#Displays the list of columns with at least 1 null values and the percentage of NON-NULL values (e.g. 0.99 = 99% not null)
print ("Columns With Nulls:")
for x in listOfColsWNullsNum:
    print (x)

# COMMAND ----------

# Drop Nulls if necessary
spark_pdp = spark_pdp.na.drop()

# COMMAND ----------

# # Subset to features used for model 
# seed = 21
# ###########################################################
# # Spliting in train and test set. Beware : It sorts the dataset
# (traindf_, testdf) = spark_pdp.randomSplit([0.85,0.15],seed)
# (traindf, valdf) = traindf_.randomSplit([0.85,0.15],seed)

# # Class Distribution for the training and test set
# print('TRAIN')
# print('Total # Records',traindf.count())
# print(traindf.groupBy("rx_enroll").count().take(2))
# # print(traindf.select(f.sum(f.when(f.col('rx_enroll') == 1, 1)).alias('rx_enroll == 1')).show(truncate=False))

# print('\n','VAL')
# print('Total # Records',valdf.count())
# print(valdf.groupBy("rx_enroll").count().take(2))

# print('\n','TEST')
# print('Total # Records',testdf.count())
# print(testdf.groupBy("rx_enroll").count().take(2))
# ###########################################################
# # Downsample dataset
# # Before Resampling
# print('\n','Resampled Training Set: ')
# # traindf_zero = traindf.filter("rx_enroll=0.0")
# print('Number of class 0 samples before:',traindf.filter("rx_enroll=0.0").count())

# # Downsample dataset
# traindf_zero = traindf.filter("rx_enroll=0.0")
# traindf_one = traindf.filter("rx_enroll=1.0")

# traindf_sampleRatio = traindf_one.count() / traindf.count()
# traindf_zero_downsample = traindf_zero.sample(withReplacement=False,fraction=traindf_sampleRatio+.001,seed=seed) #fraction = % you want to draw from that sample
# traindf_sampled = traindf_one.unionAll(traindf_zero_downsample)

# # After Resampling
# print('Number of class 0 samples after:',traindf_zero_downsample.count())
# print('Number of class 1 samples after:',traindf_one.count())
# print(traindf_sampled.groupBy("rx_enroll").count().take(2))

# ###########################################################
# # Remove PGK from model
# train = traindf_sampled
# val = valdf
# test = testdf
# traindf = traindf_sampled.drop("sdr_person_id")
# valdf = valdf.drop("sdr_person_id")
# testdf = testdf.drop("sdr_person_id")
# print(train.groupBy("rx_enroll").count().take(2))
# print(val.groupBy("rx_enroll").count().take(2))
# print(test.groupBy("rx_enroll").count().take(2))
# ###########################################################
# # Features
# model_features = ['cons_ntwperyr', 'cons_chva',
#                   'cons_rxbrand','cons_rxsowrx','cons_hwrxloyl',
#                   'pre_month_total', 'est_age', 
#                   'ded_paid_amt_pmpm',
#                   'rx_mail_pmpm_ct',
#                   'rx_maint_pmpm_ct',
#                   'rx_tier_1_pmpm_ct', 'rx_tier_2_pmpm_ct',
#                   'mbr_respons_amt_pmpm','rx_overall_pmpm_cost',
#                   'days_since_last_login', # 'TS_LAST_CALL',
#                   'rx_cntrx_hprx_pmpm',
#                   'bhseg_engaged_mbrs_ind',
#                   'bhseg_unengaged_mbrs_ind', 'bhseg_norecord_ind',
#                  ]

# # Lowercase column names - List comprehensions
# model_features = [element.lower() for element in model_features]
# ###########################################################
# # Fit Random Forest Classifier to Training Data
# # Index labels, adding metadata to the label column.
# # Fit on whole dataset to include all labels in index.
# traindf = StringIndexer(inputCol="rx_enroll", outputCol="indexed_rx_enroll").fit(traindf).transform(traindf)

# # Feature assembler as a vector
# traindf = VectorAssembler(inputCols=model_features,outputCol="features").transform(traindf)

# # Model
# pdp_rf = RandomForestClassifier(labelCol="indexed_rx_enroll", featuresCol="features", numTrees=500,featureSubsetStrategy="sqrt",impurity="entropy")

# pdp_classifier = pdp_rf.fit(traindf)
# ###########################################################
# # Predict on the Test Data rf
# # Feature assembler as a vector
# testdf = VectorAssembler(inputCols=model_features,outputCol="features").transform(testdf)

# # Prediction
# predictions_pdp = pdp_classifier.transform(testdf)
 
  
# # Split out the conversion and non-conversion columns
# split1_udf = udf(lambda value: value[0].item(), FloatType())
# split2_udf = udf(lambda value: value[1].item(), FloatType())
# predictions_pdp = predictions_pdp.withColumn('non_convert', split1_udf('probability')).withColumn('convert', split2_udf('probability'))  
  
# # Select example rows to display.
# # Probability shows of class 0
# # predictions.select(col("prediction"),col("probability"),).show(15)
# display(predictions_pdp)

# COMMAND ----------

# MAGIC %md ##### Pipeline

# COMMAND ----------

random_seed_val=21
seed=21

# Features
model_features = [#'sdr_person_id', # 'unique_id',
                  'cons_ntwperyr', 'cons_chva',
                  'cons_rxbrand','cons_rxsowrx','cons_hwrxloyl',
                  'pre_month_total', 'est_age', 
                  'ded_paid_amt_pmpm',
                  'rx_mail_pmpm_ct',
                  'rx_maint_pmpm_ct',
                  'rx_tier_1_pmpm_ct', 'rx_tier_2_pmpm_ct',
                  'mbr_respons_amt_pmpm','rx_overall_pmpm_cost',
                  'days_since_last_login', # 'TS_LAST_CALL',
                  'rx_cntrx_hprx_pmpm',
                  'bhseg_engaged_mbrs_ind',
                  'bhseg_unengaged_mbrs_ind', 'bhseg_norecord_ind',
                 ]



# Lowercase column names - List comprehensions
model_features = [element.lower() for element in model_features]
###########################################################
# Fit on whole dataset to include all labels in index.
labelIndexer = StringIndexer(inputCol="rx_enroll", outputCol="label")

#Next is to vectorize the columns: feature transformer that merges multiple columns into a vector column:
assembler1 =  VectorAssembler(inputCols=model_features,outputCol="features")

# # Scale all numeric fields between [0,1]
# scaler = (MinMaxScaler(inputCol="features", outputCol="scaledFeatures"))

pdp_rf = RandomForestClassifier(labelCol="label", featuresCol="features", numTrees=500,featureSubsetStrategy="sqrt",impurity="entropy")

# Chain indexer and in a Pipeline
pipeline = Pipeline(stages=[labelIndexer] + [assembler1,pdp_rf])
###########################################################
# Performance of model
(traindf, testdf) = spark_pdp.randomSplit([0.8, 0.2], seed=21)

# Class Distribution for the training and test set
print('TRAIN')
print('Total # Records',traindf.count())
print(traindf.groupBy("rx_enroll").count().take(2))
# print(traindf.select(f.sum(f.when(f.col('rx_enroll') == 1, 1)).alias('rx_enroll == 1')).show(truncate=False))

print('\n','TEST')
print('Total # Records',testdf.count())
print(testdf.groupBy("rx_enroll").count().take(2))
###########################################################
# Downsample dataset
# Before Resampling
print('\n','Resampled Training Set: ')
# traindf_zero = traindf.filter("rx_enroll=0.0")
print('Number of class 0 samples before:',traindf.filter("rx_enroll=0.0").count())

# Downsample dataset
traindf_zero = traindf.filter("rx_enroll=0.0")
traindf_one = traindf.filter("rx_enroll=1.0")

traindf_sampleRatio = traindf_one.count() / traindf.count()
traindf_zero_downsample = traindf_zero.sample(withReplacement=False,fraction=traindf_sampleRatio+.001,seed=seed) #fraction = % you want to draw from that sample
traindf_sampled = traindf_one.unionAll(traindf_zero_downsample)

# After Resampling
print('Number of class 0 samples after:',traindf_zero_downsample.count())
print('Number of class 1 samples after:',traindf_one.count())
print(traindf_sampled.groupBy("rx_enroll").count().take(2))
###########################################################
# Update Training data to be downsampled
traindf = traindf_sampled
testdf = testdf
print(traindf.groupBy("rx_enroll").count().take(2))
print(testdf.groupBy("rx_enroll").count().take(2))
###########################################################
# Train model. 
pdp_classifier = pipeline.fit(traindf)
predictions_pdp = pdp_classifier.transform(testdf)
# model_train_RF = mapd_classifier.transform(traindf)
###########################################################
# Split out the conversion and non-conversion columns
split1_udf = udf(lambda value: value[0].item(), FloatType())
split2_udf = udf(lambda value: value[1].item(), FloatType())
predictions_pdp = predictions_pdp.withColumn('non_convert', split1_udf('probability')).withColumn('convert', split2_udf('probability'))  

display(predictions_pdp)

# COMMAND ----------

# MAGIC %md ##### Performance of PDP

# COMMAND ----------

# Evaluate Model
# Accuracy
evaluator = MulticlassClassificationEvaluator(labelCol="rx_enroll", predictionCol="prediction", metricName="accuracy")
accuracy = evaluator.evaluate(predictions_pdp)
print("Accuracy = %g" % (accuracy))

evaluatorf1 = MulticlassClassificationEvaluator(labelCol="rx_enroll", predictionCol="prediction", metricName="f1")
f1 = evaluatorf1.evaluate(predictions_pdp)
print("f1 = %g" % (f1))

evaluatorwp = MulticlassClassificationEvaluator(labelCol="rx_enroll", predictionCol="prediction", metricName="weightedPrecision")
wp = evaluatorwp.evaluate(predictions_pdp)
print("weightedPrecision = %g" % (wp))

evaluatorwr = MulticlassClassificationEvaluator(labelCol="rx_enroll", predictionCol="prediction", metricName="weightedRecall")
wr = evaluatorwr.evaluate(predictions_pdp)
print("weightedRecall = %g" % (wr))

# # Confusion Matrix
# # Create (prediction, label) pairs
# predictionAndLabel = predictions.select("prediction", "rx_enroll").rdd

# # Generate confusion matrix
# metrics = MulticlassMetrics(predictionAndLabel)
# print(metrics.confusionMatrix())

# COMMAND ----------

# Import packages
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_score
from sklearn.metrics import recall_score
from sklearn.metrics import brier_score_loss
from sklearn.metrics import f1_score
from sklearn.metrics import roc_auc_score, roc_curve, auc

# Convert Spark df to Pandas df to get confusion matrix since I cant figure it out in spark
df_pdp = predictions_pdp.toPandas()

# Convert for easy use of old code
y_val = df_pdp.rx_enroll
y_pred = df_pdp.prediction

# Missclassified
print('Number of Misclassified: ',(y_val != y_pred).sum())

###########################################################
# Confusion Matrix
cm = confusion_matrix(y_val, y_pred)
print('[[True Negative, False Positive]')
print('[False Negative, True Positive]]')
print(cm)
###########################################################
# Recall (True Positive / Positive Cases (TP & FN)): True Positive Rate
# print('TRUE POSITIVE RATE (Recall or Sensitivity) =','TP / (TP+FN)')
print('Accuracy: %.3f' % accuracy_score(y_true=y_val, y_pred=y_pred))
print('Recall: %.3f' % recall_score(y_true=y_val, y_pred=y_pred))
print('Precision: %.3f' % precision_score(y_true=y_val, y_pred=y_pred))

# COMMAND ----------

# Deciles
colnames = ['sdr_person_id',
            'cons_ntwperyr', 'cons_chva',
            'cons_rxbrand','cons_rxsowrx','cons_hwrxloyl',
            'pre_month_total', 'est_age', 
            'ded_paid_amt_pmpm',
            'rx_mail_pmpm_ct',
            'rx_maint_pmpm_ct',
            'rx_tier_1_pmpm_ct', 'rx_tier_2_pmpm_ct',
            'mbr_respons_amt_pmpm','rx_overall_pmpm_cost',
            'days_since_last_login', # 'TS_LAST_CALL',
            'rx_cntrx_hprx_pmpm',
            'bhseg_engaged_mbrs_ind',
            'bhseg_unengaged_mbrs_ind', 'bhseg_norecord_ind',
           ]

test = testdf.toPandas()

results = pd.DataFrame(test,columns = colnames)
# results['sdr_person_id'] = test[:,0].astype(np.int64)
results['y_actual'] = y_val
results['y_probas'] = df_pdp.convert
results['y_preds'] = y_pred
results.head(5)
#################################################################################
# Results sorted by Probability Predicted
results['decile']= pd.qcut(results.y_probas, 10
       ,labels=[9,8,7,6,5,4,3,2,1,0])
results_sort = results.sort_values(by='y_probas',ascending=False).reset_index()
results_sort = results_sort.drop(['index'], axis=1)
results_sort.head(5)
#################################################################################
# Decile Cut offs
for decile in range(9):
    print('-',decile,end=")")
    print('\033[1m'+ 'Decile ' + str(decile) +'\033[0m',end=": ")
    print(results_sort[results_sort.decile == decile].y_probas.min())

# COMMAND ----------

# Save out testdf results
pred_target_df_columns = ['y_probas','y_actual','sdr_person_id']
pdp_pred_target_df = results_sort[pred_target_df_columns]

# Convert back to spark
pdp_pred_target_df = spark.createDataFrame(pdp_pred_target_df)
pdp_pred_target_df.count()
pdp_pred_target_df.filter(col('y_actual')==1).count()

# Output the test scores
(pdp_pred_target_df
 .write
 .mode("overwrite")
 .option("header", "true")
 .format("parquet")
 .save(adls_xformed_path + "/lvl1/models/rxe-model-v1/training-scores"))

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md ### Connect to Azure ML Workspace

# COMMAND ----------

# Parameters for connecting to the AML Services Workspace and Creating the Experiment

subscription_id = dbutils.secrets.get(scope = "dha-mlp-cods-credential", key = "subscription-id")

# These are specific to the AML Workspace you are using
resource_group = "dha-mlp-d-cods-prod-rg"
workspace_name = "dha-mlp-d-cods-prod-mls" # "dha-mlp-d-cods-prod-databricks"
workspace_region = "eastus2"

# Authentication required to access AML Services Workspace
svc_pr = ServicePrincipalAuthentication(tenant_id = dbutils.secrets.get(scope = "dha-mlp-cods-credential", key = "tenant-id"),
                                        service_principal_id = dbutils.secrets.get(scope = "dha-mlp-cods-credential", key = "client-id"),
                                        service_principal_password = dbutils.secrets.get(scope = "dha-mlp-cods-credential", key = "client-secret"))

ws = Workspace(workspace_name = workspace_name,
               subscription_id = subscription_id,
               resource_group = resource_group,
               auth = svc_pr)

# Enable diagnostics collection
from azureml.telemetry import set_diagnostics_collection
set_diagnostics_collection(send_diagnostics=True)

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# MAGIC %md ### Save & Register the Model

# COMMAND ----------

# MAGIC %run ../shared/model_registration

# COMMAND ----------

rf_model_name = "mdr_rxe_mapd_model.mml" # in case you want to change the name, you need to keep the .mml extension
# this will likely take a fair amount of time because of the amount of models that we're creating and testing
  
# save model
model_path = adls_xformed_path + "/lvl1/models/rxe-model-v1/saved-models/" + rf_model_name
model_path = adls_xformed_path + "/lvl1/models/medr-rxe-model-v1/saved-models/" + rf_model_name

mapd_classifier.write().overwrite().save(model_path)



# COMMAND ----------

model_name = "mdr-rxe-mapd-model.mml"
# model_adls_path = adls_xformed_path + "/lvl1/models/rxe-model-v1/saved-models/mdr_rxe_mapd_model.mml/"
model_adls_path = adls_xformed_path + "/lvl1/models/medr-rxe-model-v1/saved-models/mdr_rxe_mapd_model.mml/"

tag_dict = {"model_type" : "Binary Classification", 
            "model_algorithm": "RandomForestClassifier", 
            "model_source" : "SparkML", 
            "modeler" : "Kevin Huang",
            "department" : "Consumer Data Science",
            "score_date_type": "Calendar Based",
            "primary_business_area": "Member Engagement MArketing",
            "primary_business_user": "Brian Voelker", 
            "scoring_type": "Batch",
            "LOB" : "Medicare (MAPD-PDP)"}
desc = "Prioritize lead base of members who are more likely to convert to HP in next 45 days"

registered_model = register_spark_ml_model(ws, model_adls_path, model_name, tag_dict, desc)

print("Registered the Model.")
print("Name: " + registered_model[0])
print("Version: " + str(registered_model[1]))
                        

# COMMAND ----------

rf_model_name = "mdr_rxe_pdp_model.mml" # in case you want to change the name, you need to keep the .mml extension
# this will likely take a fair amount of time because of the amount of models that we're creating and testing
  
# save model
# model_path = adls_xformed_path + "/lvl1/models/rxe-model-v1/saved-models/" + rf_model_name
model_path = adls_xformed_path + "/lvl1/models/medr-rxe-model-v1/saved-models/" + rf_model_name

pdp_classifier.write().overwrite().save(model_path)

# COMMAND ----------

model_name = "mdr-rxe-pdp-model.mml"
# model_adls_path = adls_xformed_path + "/lvl1/models/rxe-model-v1/saved-models/mdr_rxe_pdp_model.mml/"
model_adls_path = adls_xformed_path + "/lvl1/models/medr-rxe-model-v1/saved-models/mdr_rxe_pdp_model.mml/"

tag_dict = {"model_type" : "Binary Classification", 
            "model_algorithm": "RandomForestClassifier", 
            "model_source" : "SparkML", 
            "modeler" : "Kevin Huang",
            "department" : "Consumer Data Science",
            "score_date_type": "Calendar Based",
            "primary_business_area": "Member Engagement MArketing",
            "primary_business_user": "Brian Voelker", 
            "scoring_type": "Batch",
            "LOB" : "Medicare (MAPD-PDP)"}
desc = "Prioritize lead base of members who are more likely to convert to HP in next 45 days"

registered_model = register_spark_ml_model(ws, model_adls_path, model_name, tag_dict, desc)

print("Registered the Model.")
print("Name: " + registered_model[0])
print("Version: " + str(registered_model[1]))

# COMMAND ----------

# MAGIC %md 
# MAGIC ===================================================================================================

# COMMAND ----------

# # now delete the serialized model from local folder since it is already uploaded to run history 
# shutil.rmtree(lr_model_dbfs)
# shutil.rmtree(rf_model_dbfs)

# # Declare run completed
# root_run.complete()
# root_run_id = root_run.id
# print ("run id:", root_run.id)
