# System Environment
import sys; print(sys.executable); print(sys.version)

# Libraries
import pandas as pd ; print("Pandas Version:",pd.__version__)
import numpy as np ; print("NumPy Version:",np.__version__)
import pyreadstat
import pickle
from datetime import date


# Import dataset to be scored
path = ''
filename = 'scoring_data.csv'
filepath = f'{path}{filename}'
prod_data1 = pd.read_csv(filepath, header=0)

# Change all Columns to uppercase
prod_data1.columns = prod_data1.columns.str.upper()
##################################################################################
# Quick & Dirty Collapse data for duplications
prod_data1 = prod_data1.sort_values(by=['IND_MAPD','IND_PDP'],ascending=False)
prod_data1 = prod_data1.groupby('MBR_PERS_GEN_KEY', as_index=False).first()
prod_data1.MBR_PERS_GEN_KEY.value_counts()
###################################################################################
# Features from SAS Dataset
prod_features = ['MBR_PERS_GEN_KEY','IND_MAPD','IND_PDP',
                  'NTWPERYR', 'CHVA',
                  'RXNUM','RXBRAND','RXSOWRX','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE',
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAIL_ORDER_6M',
                  'RX_CNT_MAINT_DRUG_6M','RX_CNT_RHTSRCE_6M','RX_CNT_RX_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'MABH_SEG','PDPBH_SEG'
                 ]
df = prod_data1[prod_features]
##################################################################################
# Clean Where MAPD & PDP == 1
df['IND_PDP'] = df.IND_PDP.mask(((df.IND_MAPD == 1) & (df.IND_PDP == 1)), 0)


# Numerical Features
number_features = ['MBR_PERS_GEN_KEY'
                         ,'IND_MAPD'
                         ,'IND_PDP'
                         ,'NTWPERYR'
                         ,'CHVA'
                         ,'RXNUM'
                         ,'RXBRAND'
                         ,'RXSOWRX'
                         ,'HWRXLOYL'
                         ,'TENURE_MBR_COV'
                         ,'HUM_AGE'
                         ,'RX_ALLOWED_AMT_6M'
                         ,'RX_CNT_MAIL_ORDER_6M'
                         ,'RX_CNT_MAINT_DRUG_6M'
                         ,'RX_CNT_RHTSRCE_6M'
                         ,'RX_CNT_RX_6M'
                         ,'RX_CNT_TIER1_6M'
                         ,'RX_CNT_TIER2_6M'
                         ,'RX_MBR_RESP_AMT_6M'
                         ,'RX_PAID_AMT_6M'
                         ,'TS_LAST_LOGIN'
                         ,'TS_LAST_CALL'
                  ]

num_var = df[number_features].copy()
####################################################################################
# Categorical Features for dataset
# Split the df to numbers & categorical for quick exploration of features
# member_data.select_dtypes(include=[object]).head() # df.loc[:, df.dtypes == np.float64]

category_features = ['MBR_PERS_GEN_KEY'
                        ,'MABH_SEG'
                        ,'PDPBH_SEG'
                    ]
cat_var = df[category_features].copy()
####################################################################################
#############################
# Clean Categorical Variables
#############################
# Create the Dummy Variables: If doing logistic, be sure to n-1 for dummy variables
# MAPD & PDP BEHAVIORAL SEGMENTATION
# Replaces None/Nan with Other and Nulls
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['C1'], 'Support-Seeking Participators')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['C3','H3'], 'Health Services Maximizers')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H1','C2'], 'Self-Engaged Optimists')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H6','H7','C6'], 'Skeptical Control-Seekers')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H2','C4'], 'Auto-pilot Participators')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H5','C5'], 'Simplicity-Seeking Followers')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H8','C7'], 'Overwhelmed and Reluctant Reactors')
cat_var['MABH_SEG'] = cat_var.loc[:,'MABH_SEG'].replace(['H4'], 'Healthy Self-Sustainers')

cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P1'], 'Proactive Maximizer')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P2'], 'Reactive Engager')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P3'], 'Frugal Participator')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P4'], 'Complacent Follower')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P5'], 'Healthy Independent')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P6'], 'Overwhelmed & Detached')
cat_var['PDPBH_SEG'] = cat_var.loc[:,'PDPBH_SEG'].replace(['P7'], 'Agreeably Disengaged')

cat_var['MABH_SEG'] = cat_var.MABH_SEG.fillna('NO RECORD')
cat_var['PDPBH_SEG'] = cat_var.PDPBH_SEG.fillna('NO RECORD')

# MAPD beh seg
mapd_bseg_cat = pd.get_dummies(cat_var[['MABH_SEG']])
mapd_bseg_cat['MBR_PERS_GEN_KEY'] = cat_var.loc[:,'MBR_PERS_GEN_KEY']

# PDP beh seg
pdp_bseg_cat = pd.get_dummies(cat_var[['PDPBH_SEG']])
pdp_bseg_cat['MBR_PERS_GEN_KEY'] = cat_var.loc[:,'MBR_PERS_GEN_KEY']

# Combine Categorical Features
cat_var_sel = ['MBR_PERS_GEN_KEY'
              ,'MABH_SEG'
              ,'PDPBH_SEG']
cat_var_subset = cat_var[cat_var_sel]
cat_var_subset = pd.merge(cat_var_subset,mapd_bseg_cat,how='left',on='MBR_PERS_GEN_KEY')
cat_var_subset = pd.merge(cat_var_subset,pdp_bseg_cat,how='left',on='MBR_PERS_GEN_KEY')
cat_var_subset.head()
################################################################################################
# Select final columns
cat_var_fin = [
    'MBR_PERS_GEN_KEY'
    ,'MABH_SEG_Auto-pilot Participators','MABH_SEG_Health Services Maximizers','MABH_SEG_Healthy Self-Sustainers','MABH_SEG_NO RECORD','MABH_SEG_Overwhelmed and Reluctant Reactors','MABH_SEG_Self-Engaged Optimists','MABH_SEG_Simplicity-Seeking Followers','MABH_SEG_Skeptical Control-Seekers','MABH_SEG_Support-Seeking Participators'
    ,'PDPBH_SEG_Agreeably Disengaged','PDPBH_SEG_Complacent Follower','PDPBH_SEG_Frugal Participator', 'PDPBH_SEG_Healthy Independent','PDPBH_SEG_NO RECORD','PDPBH_SEG_Overwhelmed & Detached','PDPBH_SEG_Proactive Maximizer', 'PDPBH_SEG_Reactive Engager'
]

cat_var = cat_var_subset[cat_var_fin]
####################################################################################
# Join Categorical & Numerical Variables
df = pd.merge(num_var,cat_var,how='left',on='MBR_PERS_GEN_KEY')
####################################################################################
mapd_train = df[df.IND_MAPD == 1].copy()
pdp_train = df[df.IND_PDP == 1].copy()
print(mapd_train.MBR_PERS_GEN_KEY.count())
print(pdp_train.MBR_PERS_GEN_KEY.count())


# Imputate CAT values
mapd_train['TENURE_MBR_COV'].fillna(mapd_train.TENURE_MBR_COV.mean(),inplace = True) # New Member
mapd_train['HUM_AGE'].fillna(mapd_train.HUM_AGE.mean(),inplace = True) # New Member

# Imputate AMLK values
mapd_train['NTWPERYR'].fillna(mapd_train.NTWPERYR.mean(),inplace = True) # Net Worth Per Year
mapd_train['CHVA'].fillna(mapd_train.CHVA.mean(),inplace = True) # Census Median Home Value AMLK
mapd_train['RXNUM'].fillna(mapd_train.RXNUM.mean(),inplace = True) # # of Meds (modeled)
mapd_train['HWRXLOYL'].fillna(mapd_train.HWRXLOYL.mean(),inplace = True) # Rx Pharmacy Loyalty

print('Number of Nulls: ',mapd_train.size - mapd_train.count().sum())
# Fill remaining with 0s
mapd_train = mapd_train.fillna(0)
print('Number of Nulls: ',mapd_train.size - mapd_train.count().sum())
#############################################################################################
# Number of Available scripts to Convert
mapd_train['RX_CNTRX_HPRX'] = mapd_train.RX_CNT_RX_6M - mapd_train.RX_CNT_RHTSRCE_6M
#############################################################################################
# Engaged Members
engaged_col = ['MABH_SEG_Support-Seeking Participators'
               ,'MABH_SEG_Health Services Maximizers'
               ,'MABH_SEG_Self-Engaged Optimists'
               ,'MABH_SEG_Auto-pilot Participators'
#                ,'PDPBH_SEG_Frugal Participator'
#                ,'PDPBH_SEG_Proactive Maximizer'
#                ,'PDPBH_SEG_Reactive Engager'
              ]
mapd_train['ENGAGED_MEMBERS'] = mapd_train[engaged_col].any(axis=1)
mapd_train['ENGAGED_MEMBERS'] = mapd_train.loc[:,'ENGAGED_MEMBERS'].replace([True], 1)
mapd_train['ENGAGED_MEMBERS'] = mapd_train.loc[:,'ENGAGED_MEMBERS'].replace([False], 0)

# Unengaged Members
unengaged_col = ['MABH_SEG_Healthy Self-Sustainers',
               'MABH_SEG_Overwhelmed and Reluctant Reactors',
               'MABH_SEG_Simplicity-Seeking Followers',
               'MABH_SEG_Skeptical Control-Seekers',
#                'PDPBH_SEG_Agreeably Disengaged',
#                'PDPBH_SEG_Complacent Follower',
#                'PDPBH_SEG_Healthy Independent',
#                'PDPBH_SEG_Overwhelmed & Detached'
                ]

mapd_train['UNENGAGED_MEMBERS'] = mapd_train[unengaged_col].any(axis=1)
mapd_train['UNENGAGED_MEMBERS'] = mapd_train.loc[:,'UNENGAGED_MEMBERS'].replace([True], 1)
mapd_train['UNENGAGED_MEMBERS'] = mapd_train.loc[:,'UNENGAGED_MEMBERS'].replace([False], 0)

# No Behavioral Segments
noseg_col = ['MABH_SEG_NO RECORD'
#              ,'PDPBH_SEG_NO RECORD'
            ]
mapd_train['NO_BEHSEG_MEMBERS'] = mapd_train[noseg_col].all(axis=1)
mapd_train['NO_BEHSEG_MEMBERS'] = mapd_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([True], 1)
mapd_train['NO_BEHSEG_MEMBERS'] = mapd_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([False], 0)
#####################################################################################################
mapd_train.loc[mapd_train.NTWPERYR < 0, 'NTWPERYR'] = 0
mapd_train.loc[mapd_train.TS_LAST_LOGIN < 0, 'TS_LAST_LOGIN'] = 0
mapd_train.loc[mapd_train.TS_LAST_CALL < 0, 'TS_LAST_CALL'] = 0



df = mapd_train.copy()
column_order = ['MBR_PERS_GEN_KEY',
                  'NTWPERYR', 'CHVA',
                  'RXNUM','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE',
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAINT_DRUG_6M','RX_CNT_RX_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'RX_CNTRX_HPRX',
                  'ENGAGED_MEMBERS','UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
                 ]
df = df[column_order]
##################################################################################
# Make PGK the index column
df.set_index('MBR_PERS_GEN_KEY', inplace=True)

# Create feature list
features_list = list(df.columns)
###################################################################################
# MAP RF
Decile_0 = 0.658
Decile_1 = 0.596
Decile_2 = 0.548
Decile_3 = 0.504
Decile_4 = 0.460
Decile_5 = 0.418
Decile_6 = 0.370
Decile_7 = 0.318
Decile_8 = 0.250
####################################################################################
# Import the model pickle
rxe_filename = 'rxe_rf_clf_mapd_random_sample.sav'
rxe_model = pickle.load(open(rxe_filename, 'rb'))

# Use the pickle model to score dataaset
y_probas = rxe_model.predict_proba(df) #df.values for XgBoost
y_score = pd.DataFrame(y_probas, columns=['prob_0', 'prob_1'])
y_score = y_score.drop(columns=['prob_0'],axis=1)
y_score.columns = ['rxe_resp_prob']

# Bring PGK back to the df & add scored probabilities
df.reset_index(inplace=True)
df_scored_mapd = pd.concat([df,y_score], axis=1)

# Add Deciles based on test data cutoffs
conditions = [
    (df_scored_mapd['rxe_resp_prob'] <= Decile_8),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_8) & (df_scored_mapd['rxe_resp_prob'] <= Decile_7)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_7) & (df_scored_mapd['rxe_resp_prob'] <= Decile_6)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_6) & (df_scored_mapd['rxe_resp_prob'] <= Decile_5)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_5) & (df_scored_mapd['rxe_resp_prob'] <= Decile_4)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_4) & (df_scored_mapd['rxe_resp_prob'] <= Decile_3)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_3) & (df_scored_mapd['rxe_resp_prob'] <= Decile_2)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_2) & (df_scored_mapd['rxe_resp_prob'] <= Decile_1)),
    ((df_scored_mapd['rxe_resp_prob'] > Decile_1) & (df_scored_mapd['rxe_resp_prob'] <= Decile_0)),
    (df_scored_mapd['rxe_resp_prob'] > Decile_0)]
deciles = [9,8,7,6,5,4,3,2,1,0]

# Add deciles to the scored rxe population
df_scored_mapd['rxe_resp_decile'] = np.select(conditions,deciles,default=np.nan)

# Add score date
SCORING_DATE = date.today()
df_scored_mapd['SCORE_DATE'] = SCORING_DATE.strftime('%Y%m%d')

# Rename Columns
df_scored_mapd.rename(columns={'rxe_resp_prob': 'MODEL_SCORE', 'rxe_resp_decile': 'DECILE'}, inplace=True)

# Change dtype of Decile
df_scored_mapd['DECILE'] = df_scored_mapd.DECILE.astype(int)

# Add MAPD indicator
df_scored_mapd['IND_MAPD'] = 1

# Subset to the list of columns for final scoring table
columns_final = ['MBR_PERS_GEN_KEY','IND_MAPD','MODEL_SCORE','DECILE','SCORE_DATE']
df_scored_mapd = df_scored_mapd[columns_final]

# Export to CSV
# May wish to choose path for CSV file by placing in front of file name
df_scored_mapd.to_csv('rxe_model_scored_mapd.csv', encoding='utf-8',index=False)



# Imputate CAT values
pdp_train['TENURE_MBR_COV'].fillna(pdp_train.TENURE_MBR_COV.mean(),inplace = True) # New Member
pdp_train['HUM_AGE'].fillna(pdp_train.HUM_AGE.mean(),inplace = True) # New Member

# Imputate AMLK values
pdp_train['NTWPERYR'].fillna(pdp_train.NTWPERYR.mean(),inplace = True) # Net Worth Per Year
pdp_train['CHVA'].fillna(pdp_train.CHVA.mean(),inplace = True) # Census Median Home Value AMLK
pdp_train['RXBRAND'].fillna(pdp_train.RXBRAND.mean(),inplace = True) # Prefer Brand Meds (0 more likely)
pdp_train['RXSOWRX'].fillna(pdp_train.RXSOWRX.mean(),inplace = True) # RX - Share of Wallet (0 loyal)
pdp_train['HWRXLOYL'].fillna(pdp_train.HWRXLOYL.mean(),inplace = True) # Rx Pharmacy Loyalty

print('Number of Nulls: ',pdp_train.size - pdp_train.count().sum())
# Fill remaining with 0s
pdp_train = pdp_train.fillna(0)
print('Number of Nulls: ',pdp_train.size - pdp_train.count().sum())
#############################################################################################
# Number of Available scripts to Convert
pdp_train['RX_CNTRX_HPRX'] = pdp_train.RX_CNT_RX_6M - pdp_train.RX_CNT_RHTSRCE_6M
#############################################################################################
# Engaged Members
engaged_col = ['PDPBH_SEG_Frugal Participator'
               ,'PDPBH_SEG_Proactive Maximizer'
               ,'PDPBH_SEG_Reactive Engager'
              ]
pdp_train['ENGAGED_MEMBERS'] = pdp_train[engaged_col].any(axis=1)
pdp_train['ENGAGED_MEMBERS'] = pdp_train.loc[:,'ENGAGED_MEMBERS'].replace([True], 1)
pdp_train['ENGAGED_MEMBERS'] = pdp_train.loc[:,'ENGAGED_MEMBERS'].replace([False], 0)

# Unengaged Members
unengaged_col = ['PDPBH_SEG_Agreeably Disengaged',
               'PDPBH_SEG_Complacent Follower',
               'PDPBH_SEG_Healthy Independent',
               'PDPBH_SEG_Overwhelmed & Detached'
                ]

pdp_train['UNENGAGED_MEMBERS'] = pdp_train[unengaged_col].any(axis=1)
pdp_train['UNENGAGED_MEMBERS'] = pdp_train.loc[:,'UNENGAGED_MEMBERS'].replace([True], 1)
pdp_train['UNENGAGED_MEMBERS'] = pdp_train.loc[:,'UNENGAGED_MEMBERS'].replace([False], 0)

# No Behavioral Segments
noseg_col = ['PDPBH_SEG_NO RECORD']
pdp_train['NO_BEHSEG_MEMBERS'] = pdp_train[noseg_col].all(axis=1)
pdp_train['NO_BEHSEG_MEMBERS'] = pdp_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([True], 1)
pdp_train['NO_BEHSEG_MEMBERS'] = pdp_train.loc[:,'NO_BEHSEG_MEMBERS'].replace([False], 0)
#####################################################################################################
pdp_train.loc[pdp_train.NTWPERYR < 0, 'NTWPERYR'] = 0
pdp_train.loc[pdp_train.TS_LAST_LOGIN < 0, 'TS_LAST_LOGIN'] = 0
pdp_train.loc[pdp_train.TS_LAST_CALL < 0, 'TS_LAST_CALL'] = 0



df = pdp_train.copy()
column_order = ['MBR_PERS_GEN_KEY',
                  'NTWPERYR', 'CHVA',
                  'RXBRAND','RXSOWRX','HWRXLOYL',
                  'TENURE_MBR_COV', 'HUM_AGE',
                  'RX_ALLOWED_AMT_6M',
                  'RX_CNT_MAIL_ORDER_6M', 'RX_CNT_MAINT_DRUG_6M',
                  'RX_CNT_TIER1_6M', 'RX_CNT_TIER2_6M',
                  'RX_MBR_RESP_AMT_6M','RX_PAID_AMT_6M',
                  'TS_LAST_LOGIN', 'TS_LAST_CALL',
                  'RX_CNTRX_HPRX',
                  'ENGAGED_MEMBERS','UNENGAGED_MEMBERS', 'NO_BEHSEG_MEMBERS',
                 ]
df = df[column_order]
##################################################################################
# Make PGK the index column
df.set_index('MBR_PERS_GEN_KEY', inplace=True)

# Create feature list
features_list = list(df.columns)
###################################################################################
# MAP RF
Decile_0 = 0.682
Decile_1 = 0.592
Decile_2 = 0.518
Decile_3 = 0.454
Decile_4 = 0.400
Decile_5 = 0.350
Decile_6 = 0.298
Decile_7 = 0.238
Decile_8 = 0.156
####################################################################################
# Import the model pickle
rxe_filename = 'rxe_rf_clf_pdp_random_sample.sav'
rxe_model = pickle.load(open(rxe_filename, 'rb'))

# Use the pickle model to score dataaset
y_probas = rxe_model.predict_proba(df) #df.values for XgBoost
y_score = pd.DataFrame(y_probas, columns=['prob_0', 'prob_1'])
y_score = y_score.drop(columns=['prob_0'],axis=1)
y_score.columns = ['rxe_resp_prob']

# Bring PGK back to the df & add scored probabilities
df.reset_index(inplace=True)
df_scored_pdp = pd.concat([df,y_score], axis=1)

# Add Deciles based on test data cutoffs
conditions = [
    (df_scored_pdp['rxe_resp_prob'] <= Decile_8),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_8) & (df_scored_pdp['rxe_resp_prob'] <= Decile_7)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_7) & (df_scored_pdp['rxe_resp_prob'] <= Decile_6)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_6) & (df_scored_pdp['rxe_resp_prob'] <= Decile_5)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_5) & (df_scored_pdp['rxe_resp_prob'] <= Decile_4)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_4) & (df_scored_pdp['rxe_resp_prob'] <= Decile_3)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_3) & (df_scored_pdp['rxe_resp_prob'] <= Decile_2)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_2) & (df_scored_pdp['rxe_resp_prob'] <= Decile_1)),
    ((df_scored_pdp['rxe_resp_prob'] > Decile_1) & (df_scored_pdp['rxe_resp_prob'] <= Decile_0)),
    (df_scored_pdp['rxe_resp_prob'] > Decile_0)]
deciles = [9,8,7,6,5,4,3,2,1,0]

# Add deciles to the scored rxe population
df_scored_pdp['rxe_resp_decile'] = np.select(conditions,deciles,default=np.nan)

# Add score date
SCORING_DATE = date.today()
df_scored_pdp['SCORE_DATE'] = SCORING_DATE.strftime('%Y%m%d')

# Rename Columns
df_scored_pdp.rename(columns={'rxe_resp_prob': 'MODEL_SCORE', 'rxe_resp_decile': 'DECILE'}, inplace=True)

# Change dtype of Decile
df_scored_pdp['DECILE'] = df_scored_pdp.DECILE.astype(int)

# Add MAPD indicator
df_scored_pdp['IND_MAPD'] = 0

# Subset to the list of columns for final scoring table
columns_final = ['MBR_PERS_GEN_KEY','IND_MAPD','MODEL_SCORE','DECILE','SCORE_DATE']
df_scored_pdp = df_scored_pdp[columns_final]

# Export to CSV
# May wish to choose path for CSV file by placing in front of file name
df_scored_pdp.to_csv('rxe_model_scored_pdp.csv', encoding='utf-8',index=False)


# Merge
frames = [df_scored_mapd, df_scored_pdp]
result = pd.concat(frames)
result.to_csv('rxe_model_scored_all.csv', encoding='utf-8',index=False)